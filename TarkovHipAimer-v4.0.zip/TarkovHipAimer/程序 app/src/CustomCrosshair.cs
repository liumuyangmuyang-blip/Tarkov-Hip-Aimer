// v4.0 自定义准星图片 (Windows: System.Drawing). Pictures live in 「准星样式 Crosshairs」 next to settings.json.
// The centre hole is NOT baked into the file: RingRaster cuts it on every render (radius = 中心留空, at least 3 px),
// so the game's own centre dot always shows whatever picture is used.
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;

namespace TarkovCrosshair
{
    public static class CustomCrosshair
    {
        /// <summary>Largest picture file accepted (bytes).</summary>
        public const long MaxFileBytes = 16L * 1024 * 1024;
        /// <summary>Largest picture side accepted (px).</summary>
        public const int MaxSide = 8192;
        /// <summary>Pictures are kept in memory at most this big (the crosshair is at most 300 px).</summary>
        public const int CacheSide = 512;

        private static readonly object gate = new object();
        private static readonly Dictionary<string, PngImage> cache = new Dictionary<string, PngImage>(StringComparer.OrdinalIgnoreCase);
        private static readonly HashSet<string> failed = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private static int loads;

        /// <summary>Makes RingRaster able to draw 自定义图片 (idempotent; call before rendering).</summary>
        public static void Install()
        {
            StyleShapes.PngProvider = Get;
        }

        public static string Folder()
        {
            return SettingsIO.CrosshairDir();
        }

        /// <summary>Creates the folder when missing. Returns false (with a message) when Windows refuses.</summary>
        public static bool EnsureFolder(out string error)
        {
            error = null;
            try { Directory.CreateDirectory(Folder()); return true; }
            catch (Exception ex) { error = ex.Message; return false; }
        }

        /// <summary>Decoded picture for a file name in the folder (cached), or null when it is missing or not a picture.</summary>
        public static PngImage Get(string fileName)
        {
            string name = StyleShapes.SafeFileName(fileName);
            if (name.Length == 0) return null;
            lock (gate)
            {
                PngImage img;
                if (cache.TryGetValue(name, out img)) return img;
                if (failed.Contains(name)) return null;
            }
            PngImage loaded = null;
            try
            {
                string path = Path.Combine(Folder(), name);
                if (File.Exists(path))
                {
                    FileInfo fi = new FileInfo(path);
                    if (fi.Length > 0 && fi.Length <= MaxFileBytes)
                    {
                        using (Bitmap b = LoadBitmap(path))
                            if (b != null) loaded = Decode(b, name + "|" + fi.LastWriteTimeUtc.Ticks + "|" + fi.Length + "|" + (++loads));
                    }
                }
            }
            catch (Exception) { loaded = null; }
            lock (gate)
            {
                if (loaded != null) cache[name] = loaded;
                else failed.Add(name);
            }
            return loaded;
        }

        /// <summary>Forget every cached picture (the folder may have changed).</summary>
        public static void Invalidate()
        {
            lock (gate) { cache.Clear(); failed.Clear(); }
        }

        /// <summary>Picture files in the folder (name only), sorted.</summary>
        public static List<string> List()
        {
            List<string> l = new List<string>();
            try
            {
                string dir = Folder();
                if (Directory.Exists(dir))
                    foreach (string f in Directory.GetFiles(dir, "*.png"))
                    {
                        string n = Path.GetFileName(f);
                        if (StyleShapes.SafeFileName(n) == n) l.Add(n);
                    }
            }
            catch (Exception) { }
            l.Sort(StringComparer.OrdinalIgnoreCase);
            return l;
        }

        /// <summary>
        /// 上传: checks the file is a readable PNG, copies it into the folder (a new name when one with that name already
        /// holds a different picture) and returns the stored file name, or null with a message for the user.
        /// </summary>
        public static string Import(string sourcePath, out string error)
        {
            error = null;
            try
            {
                if (string.IsNullOrEmpty(sourcePath) || !File.Exists(sourcePath)) { error = "找不到这个文件。"; return null; }
                if (!string.Equals(Path.GetExtension(sourcePath), ".png", StringComparison.OrdinalIgnoreCase))
                { error = "请选择 PNG 图片（.png）。"; return null; }
                FileInfo fi = new FileInfo(sourcePath);
                if (fi.Length <= 0) { error = "这个文件是空的。"; return null; }
                if (fi.Length > MaxFileBytes) { error = "图片太大（最多 16 MB）。"; return null; }
                using (Bitmap b = LoadBitmap(sourcePath))
                {
                    if (b == null) { error = "这个文件不是能打开的 PNG 图片。"; return null; }
                    if (b.Width < 1 || b.Height < 1 || b.Width > MaxSide || b.Height > MaxSide)
                    { error = "图片尺寸不支持（最大 " + MaxSide + "×" + MaxSide + "）。"; return null; }
                }
                string dirErr;
                if (!EnsureFolder(out dirErr)) { error = "无法创建文件夹「" + SettingsIO.CrosshairFolderName + "」：" + dirErr; return null; }
                string dir = Folder();
                string full = Path.GetFullPath(sourcePath);
                // Already inside the folder: use it as it is.
                if (string.Equals(Path.GetDirectoryName(full).TrimEnd('\\', '/'), Path.GetFullPath(dir).TrimEnd('\\', '/'), StringComparison.OrdinalIgnoreCase))
                {
                    string own = Path.GetFileName(full);
                    if (StyleShapes.SafeFileName(own) == own) { Forget(own); return own; }
                }
                string baseName = StyleShapes.SafeFileName(Path.GetFileNameWithoutExtension(sourcePath));
                if (baseName.Length == 0) baseName = "准星";
                if (baseName.Length > 60) baseName = baseName.Substring(0, 60);
                string name = baseName + ".png";
                for (int i = 2; File.Exists(Path.Combine(dir, name)); i++)
                {
                    if (SameBytes(Path.Combine(dir, name), sourcePath)) { Forget(name); return name; }
                    name = baseName + " (" + i + ").png";
                    if (i > 999) { error = "文件夹里同名图片太多了。"; return null; }
                }
                File.Copy(sourcePath, Path.Combine(dir, name), false);
                Forget(name);
                if (Get(name) == null) { error = "图片复制好了，但读取失败。"; return null; }
                return name;
            }
            catch (Exception ex)
            {
                error = "上传失败：" + ex.Message;
                return null;
            }
        }

        private static void Forget(string name)
        {
            lock (gate) { cache.Remove(name); failed.Remove(name); }
        }

        private static bool SameBytes(string a, string b)
        {
            try
            {
                FileInfo fa = new FileInfo(a), fb = new FileInfo(b);
                if (fa.Length != fb.Length) return false;
                byte[] x = File.ReadAllBytes(a), y = File.ReadAllBytes(b);
                for (int i = 0; i < x.Length; i++) if (x[i] != y[i]) return false;
                return true;
            }
            catch (Exception) { return false; }
        }

        /// <summary>Loads without locking the file (the user may delete / replace it later).</summary>
        private static Bitmap LoadBitmap(string path)
        {
            try
            {
                byte[] bytes = File.ReadAllBytes(path);
                using (MemoryStream ms = new MemoryStream(bytes))
                using (Image img = Image.FromStream(ms, false, true))
                {
                    if (!ImageFormat.Png.Equals(img.RawFormat)) return null;
                    return new Bitmap(img); // a copy that does not need the stream
                }
            }
            catch (Exception) { return null; }
        }

        /// <summary>Premultiplied ARGB copy, shrunk (high quality) so the longer side is at most CacheSide.</summary>
        private static PngImage Decode(Bitmap b, string id)
        {
            int w = b.Width, h = b.Height;
            double f = Math.Min(1.0, CacheSide / (double)Math.Max(w, h));
            int W = Math.Max(1, (int)Math.Round(w * f)), H = Math.Max(1, (int)Math.Round(h * f));
            using (Bitmap dst = new Bitmap(W, H, PixelFormat.Format32bppPArgb))
            {
                using (Graphics g = Graphics.FromImage(dst))
                {
                    g.Clear(Color.Transparent);
                    g.CompositingMode = CompositingMode.SourceCopy;
                    g.InterpolationMode = f < 1 ? InterpolationMode.HighQualityBicubic : InterpolationMode.NearestNeighbor;
                    g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                    using (ImageAttributes ia = new ImageAttributes())
                    {
                        ia.SetWrapMode(WrapMode.TileFlipXY); // no dark fringe at the edges
                        g.DrawImage(b, new Rectangle(0, 0, W, H), 0, 0, w, h, GraphicsUnit.Pixel, ia);
                    }
                }
                int[] pix = new int[W * H];
                BitmapData d = dst.LockBits(new Rectangle(0, 0, W, H), ImageLockMode.ReadOnly, PixelFormat.Format32bppPArgb);
                try
                {
                    for (int y = 0; y < H; y++)
                        Marshal.Copy(new IntPtr(d.Scan0.ToInt64() + (long)y * d.Stride), pix, y * W, W);
                }
                finally { dst.UnlockBits(d); }
                return new PngImage(pix, W, H, id);
            }
        }

        /// <summary>Premultiplied 0xAARRGGBB pixels -> a new 32bppPArgb bitmap (caller disposes).</summary>
        public static Bitmap ToBitmap(int[] pix, int w, int h)
        {
            Bitmap bmp = new Bitmap(Math.Max(1, w), Math.Max(1, h), PixelFormat.Format32bppPArgb);
            BitmapData d = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.WriteOnly, PixelFormat.Format32bppPArgb);
            try
            {
                for (int y = 0; y < h; y++)
                    Marshal.Copy(pix, y * w, new IntPtr(d.Scan0.ToInt64() + (long)y * d.Stride), w);
            }
            finally { bmp.UnlockBits(d); }
            return bmp;
        }
    }
}
