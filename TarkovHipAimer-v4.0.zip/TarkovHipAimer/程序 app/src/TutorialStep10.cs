﻿// TutorialStep10.cs -- 首次设置教程 script step 10 (跳跃与拉枪, the last page). System.Drawing only (no WinForms), C# 5,
// no per-frame allocation. Owner: step worker 10. Registered by TutorialStepsB.AddSteps (reflection: TutorialStep10.Add).
// The pure maths (TutorialStep10Math, TutorialStep10Flow) compiles on its own: tests-v4 defines STEP10_PURE_ONLY and
// compiles only that part (tests in tests-v4/TestsV4Step10.cs).
//
// Demo A 「跳跃」 (示意): first-person, wall fixed at 10 m. The bullets follow the developer's preset jump path (Leo's default
// profile); the ring uses the user's own 跳跃 values. The path is drawn as a trail on the scene and as an offset / time
// plot (预设路线 · 示意 vs 你的数值). A small side view shows the character jumping. Live: press the jump key and fire.
// Demo B 「拉枪」 (示意): first-person peek from behind cover: right hand D+E -> 换手 Q+A (mirrored) -> the enemy's view
// doing the same to our fixed target. Camera sideways motion = PeekModel (strafe + lean), a top-down mini map shows the
// line of sight, a bar chart compares 只按 D / 只按 E / D+E (time until the target is visible, 示意).
using System;
using System.Collections.Generic;
#if !STEP10_PURE_ONLY
using System.Drawing;
using System.Drawing.Drawing2D;
#endif

namespace TarkovCrosshair
{
    /// <summary>
    /// Pure maths of the 跳跃与拉枪 step (System only, unit-tested). Every number here is 示意 (demo timing / layout),
    /// not measured game data.
    /// </summary>
    public static class TutorialStep10Math
    {
        // ---------------- demo A: jump ----------------
        /// <summary>Scripted jump loop (ms): jump pressed at JumpAt, fire held FireFrom..FireTo.</summary>
        public const int JumpLoopMs = 2600, JumpAt = 350, FireFrom = 300, FireTo = 1300;
        /// <summary>Wall distance of the jump demo (示意).</summary>
        public const double DistanceM = 10;
        /// <summary>Live: shots fired while a jump runs before the jump task counts as done.</summary>
        public const int JumpShotsNeeded = 2;
        /// <summary>Trail samples kept for one jump (60 fps x 2 s).</summary>
        public const int TrailMax = 128;
        /// <summary>Trail fade after the jump ended (ms).</summary>
        public const double TrailFadeMs = 1400;

        // ---------------- demo B: peek ----------------
        /// <summary>Length of one peek scene (ms) and the number of scenes (右手 D+E, 换手 Q+A, 敌人视角).</summary>
        public const int PeekSceneMs = 3800, PeekScenes = 3;
        public const int PeekTotalMs = PeekSceneMs * PeekScenes;
        /// <summary>Keys go down at KeysAt (ms into the scene); the scene fades in / out over FadeMs.</summary>
        public const int KeysAt = 600, FadeMs = 260;
        /// <summary>First shot ReactMs after the target became visible; shots every ShotGapMs for ShotsPerPeek shots.</summary>
        public const int ReactMs = 140, ShotGapMs = 95, ShotsPerPeek = 7;
        /// <summary>Camera stops moving sideways at this shift (m, 示意).</summary>
        public const double MaxCamM = 0.55;
        /// <summary>Peek geometry (m, 示意): the cover edge is EdgeX to the side at CoverZ ahead; the target stands TargetX
        /// to the side at TargetZ.</summary>
        public const double EdgeX = 0.35, CoverZ = 1.0, TargetX = 0.6, TargetZ = 9.0;
        /// <summary>Height of the target (m, 示意) and of the aim point above its feet (chest).</summary>
        public const double TargetH = 1.75, AimH = 1.3;

        /// <summary>Camera sideways shift (m) at which the target appears past the cover edge (pinhole camera looking
        /// straight ahead): (EdgeX * TargetZ - TargetX * CoverZ) / (TargetZ - CoverZ).</summary>
        public static double RevealCamX(double edgeX, double coverZ, double targetX, double targetZ)
        {
            double d = targetZ - coverZ;
            if (!(d > 0)) return 0;
            double c = (edgeX * targetZ - targetX * coverZ) / d;
            return c < 0 ? 0 : c;
        }

        public static double RevealCamX() { return RevealCamX(EdgeX, CoverZ, TargetX, TargetZ); }

        /// <summary>Screen offset (px from the centre, toward the peek side +) of a point X to the side at Z ahead, camera
        /// shifted camX, focal f (px at 1 m). Z &lt;= 0 gives 0.</summary>
        public static double ScreenX(double x, double z, double camX, double focal)
        {
            if (!(z > 0)) return 0;
            return (x - camX) * focal / z;
        }

        /// <summary>The target is visible when it is beyond the cover edge on screen.</summary>
        public static bool TargetVisible(double camX)
        {
            return ScreenX(TargetX, TargetZ, camX, 1) > ScreenX(EdgeX, CoverZ, camX, 1);
        }

        /// <summary>Camera shift (m) tau seconds after the keys went down: strafe and/or lean (PeekModel), capped at MaxCamM.</summary>
        public static double CamX(bool strafe, bool lean, double tauS)
        {
            double x = PeekModel.CameraX(strafe, lean, tauS);
            if (double.IsNaN(x) || x < 0) x = 0;
            return x > MaxCamM ? MaxCamM : x;
        }

        /// <summary>Lean amount 0..1 tau seconds after the lean key went down (PeekModel lean shape).</summary>
        public static double Lean01(double tauS)
        {
            if (!(tauS > 0)) return 0;
            return TutorialGeometry.Smooth(tauS / PeekModel.LeanS);
        }

        /// <summary>Time (s) until the target is visible: strafe only, lean only, both (∞ = never within 3 s).</summary>
        public static double ClearTime(bool strafe, bool lean)
        {
            return PeekModel.TimeToClear(strafe, lean, RevealCamX(), 3.0);
        }

        /// <summary>Peek scene index 0..2 at time t (ms into demo B, clamped) and the ms into that scene.</summary>
        public static int PeekScene(double tMs, out double localMs)
        {
            if (double.IsNaN(tMs) || tMs < 0) tMs = 0;
            if (tMs >= PeekTotalMs) tMs = PeekTotalMs - 0.001;
            int i = (int)(tMs / PeekSceneMs);
            if (i < 0) i = 0;
            if (i >= PeekScenes) i = PeekScenes - 1;
            localMs = tMs - i * PeekSceneMs;
            return i;
        }

        /// <summary>Scene fade 0 (black) .. 1 (fully shown) at localMs.</summary>
        public static double SceneFade(double localMs)
        {
            if (double.IsNaN(localMs)) return 0;
            double a = localMs / FadeMs, b = (PeekSceneMs - localMs) / FadeMs;
            double v = Math.Min(a, b);
            if (v < 0) v = 0;
            return v > 1 ? 1 : v;
        }

        /// <summary>Shots fired up to localMs in a D+E peek scene (0 before the first one).</summary>
        public static int ShotsAt(double localMs)
        {
            double first = KeysAt + ClearTime(true, true) * 1000.0 + ReactMs;
            if (double.IsInfinity(first) || double.IsNaN(localMs) || localMs < first) return 0;
            int n = 1 + (int)((localMs - first) / ShotGapMs);
            return n > ShotsPerPeek ? ShotsPerPeek : n;
        }

        /// <summary>ms since the last shot at localMs (∞ when none yet).</summary>
        public static double SinceShot(double localMs)
        {
            int n = ShotsAt(localMs);
            if (n <= 0) return double.PositiveInfinity;
            double first = KeysAt + ClearTime(true, true) * 1000.0 + ReactMs;
            return localMs - (first + (n - 1) * ShotGapMs);
        }

        /// <summary>Wall height (m) whose top edge sits halfPx above the centre at zoom zk (scene px per UI px) and distM;
        /// at least 1 m.</summary>
        public static double WallHeightM(double halfPx, double zk, double distM)
        {
            if (!(zk > 0) || !(distM > 0) || !(halfPx > 0)) return 1;
            double m = 2 * halfPx / zk * distM / TutorialGeometry.FocalPx;
            return m < 1 ? 1 : m;
        }

        /// <summary>Airborne height 0..1 of the side-view figure tMs into a jump of totalMs (half sine, 示意).</summary>
        public static double AirHeight01(double tMs, double totalMs)
        {
            if (!(totalMs > 0) || !(tMs > 0) || tMs >= totalMs) return 0;
            return Math.Sin(Math.PI * tMs / totalMs);
        }

        /// <summary>Largest |end px| of the first two jump phases of two paths (disabled paths count 0) plus margin,
        /// at least minExtent. NaN / infinity count as 0.</summary>
        public static double JumpExtent(bool aOn, double a0, double a1, bool bOn, double b0, double b1, double margin, double minExtent)
        {
            double m = 0;
            if (aOn) { m = Math.Max(m, Fin(Math.Abs(a0))); m = Math.Max(m, Fin(Math.Abs(a1))); }
            if (bOn) { m = Math.Max(m, Fin(Math.Abs(b0))); m = Math.Max(m, Fin(Math.Abs(b1))); }
            m += Fin(margin);
            return m < minExtent ? minExtent : m;
        }

        /// <summary>Scene px per UI px so that extentUi fills 'fill' of halfPx; k = DPI scale. Clamped 0.05 .. 40.</summary>
        public static double FitZoom(double halfPx, double k, double extentUi, double fill)
        {
            if (!(k > 0)) k = 1;
            if (!(halfPx > 0)) return 0.05;
            if (!(fill > 0)) fill = 1;
            double e = Fin(Math.Abs(extentUi));
            if (!(e > 0)) e = 1;
            double z = halfPx * fill / (e * k);
            if (z < 0.05) z = 0.05;
            if (z > 40) z = 40;
            return z;
        }

        /// <summary>Plot y (px, y down) of value in [lo, hi] inside [top, top + height]; clamped to the box.</summary>
        public static float PlotY(double value, double lo, double hi, float top, float height)
        {
            if (!(hi > lo)) { hi = lo + 1; }
            double u = (Fin(value) - lo) / (hi - lo);
            if (u < 0) u = 0;
            if (u > 1) u = 1;
            return (float)(top + height - u * height);
        }

        private static double Fin(double v) { return (double.IsNaN(v) || double.IsInfinity(v)) ? 0 : v; }

        /// <summary>「≈0.16 s」 (two decimals, 示意); 「—」 for never / NaN. Allocates: call once, not per frame.</summary>
        public static string SecondsText(double s)
        {
            if (double.IsNaN(s) || double.IsInfinity(s) || s < 0) return "—";
            return "≈" + s.ToString("0.00", System.Globalization.CultureInfo.InvariantCulture) + " s";
        }
    }

    /// <summary>
    /// Page flow of step 10 (pure): demo A (jump) until the user did the jump task and paused, or after JumpIdleMs without
    /// live input; then demo B (peek) once through; then back to A, and so on. Prompts 0 → 1 (demo B started) → 2 (demo B
    /// watched once; the step is Done). Live jump / fire during demo B switches back to demo A.
    /// </summary>
    public sealed class TutorialStep10Flow
    {
        public const int ModeJump = 0, ModePeek = 1;
        /// <summary>Demo A without live input for this long (ms) -> demo B.</summary>
        public const double JumpIdleMs = 5200;
        /// <summary>After the live jump task: this long without live input (ms) -> demo B.</summary>
        public const double AfterTaskMs = 1200;

        public int Mode;
        public double ModeMs, PeekMs, IdleMs;
        public int Prompt;
        public bool Done, JumpTaskDone, PeekWatched;
        public int LiveJumpShots;
        /// <summary>True on the tick demo B finished for the first time (the step pushes its terminal line then).</summary>
        public bool JustWatched;
        /// <summary>True on the tick the mode changed (the step clears its demo state).</summary>
        public bool ModeChanged;

        public void Reset()
        {
            Mode = ModeJump; ModeMs = 0; PeekMs = 0; IdleMs = 0; Prompt = 0;
            Done = false; JumpTaskDone = false; PeekWatched = false; LiveJumpShots = 0; JustWatched = false; ModeChanged = false;
        }

        /// <summary>Manual pick (chip).</summary>
        public void Select(int mode)
        {
            if (mode != ModeJump && mode != ModePeek) return;
            SetMode(mode);
            if (mode == ModePeek && Prompt < 1) Prompt = 1;
        }

        private void SetMode(int m)
        {
            Mode = m; ModeMs = 0; PeekMs = 0; IdleMs = 0; ModeChanged = true;
        }

        /// <summary>One frame. live = any live key / click this frame; jumpShots = shots fired this frame while a jump
        /// runs (live only); wantJump = live jump key or fire this frame.</summary>
        public void Tick(double dtMs, bool live, int jumpShots, bool wantJump)
        {
            JustWatched = false; ModeChanged = false;
            if (double.IsNaN(dtMs) || dtMs < 0) dtMs = 0;
            if (dtMs > 100) dtMs = 100;
            ModeMs += dtMs;
            if (live) IdleMs = 0; else IdleMs += dtMs;
            if (Mode == ModeJump)
            {
                if (live && jumpShots > 0) LiveJumpShots += jumpShots;
                if (!JumpTaskDone && LiveJumpShots >= TutorialStep10Math.JumpShotsNeeded) JumpTaskDone = true;
                bool go = IdleMs >= JumpIdleMs || (JumpTaskDone && IdleMs >= AfterTaskMs && LiveJumpShots > 0 && ModeMs >= AfterTaskMs);
                if (go)
                {
                    SetMode(ModePeek);
                    if (Prompt < 1) Prompt = 1;
                }
                return;
            }
            // demo B
            if (wantJump) { SetMode(ModeJump); return; }
            PeekMs += dtMs;
            if (PeekMs >= TutorialStep10Math.PeekTotalMs)
            {
                if (!PeekWatched) JustWatched = true;
                PeekWatched = true; Done = true; Prompt = 2;
                SetMode(ModeJump);
            }
        }
    }

#if !STEP10_PURE_ONLY
    public static class TutorialStep10
    {
        /// <summary>Appends this script step's page(s) to the wizard, in order (the last page of the tutorial).</summary>
        public static void Add(List<TutorialStep> steps)
        {
            steps.Add(new TutorialStep10Page());
        }
    }

    /// <summary>Script step 10 「跳跃与拉枪」 (last page: the frame's primary button is 「完成，去精调」).</summary>
    internal sealed class TutorialStep10Page : TutorialStep
    {
        private static readonly TutorialScript Script = new TutorialScript(TutorialStep10Math.JumpLoopMs,
            new ScriptSeg(TutorialStep10Math.JumpAt, TutorialStep10Math.JumpAt + 200, TKey.Jump),
            new ScriptSeg(TutorialStep10Math.FireFrom, TutorialStep10Math.FireTo, TKey.Fire));

        private static bool JumpOk(Profile p)
        {
            return p != null && p.Jump != null && p.Jump.Phases != null && p.Jump.Phases.Count >= JumpSettings.PhaseCount;
        }

        private static readonly TutorialField[] JumpFields = MakeFields();

        private static TutorialField[] MakeFields()
        {
            TutorialField on = TutorialField.Check("跳跃时准星跟着动", "可选",
                delegate(Profile p) { return p != null && p.Jump != null && p.Jump.Enabled; },
                delegate(Profile p, bool v) { if (p == null) return; if (p.Jump == null) p.Jump = new JumpSettings(); p.Jump.Enabled = v; });
            Func<Profile, bool> enabled = delegate(Profile p) { return JumpOk(p) && p.Jump.Enabled; };
            TutorialField down = TutorialField.Number("1. 起跳后先往下移多少", "可选", true, -JumpSettings.LimitPx, JumpSettings.LimitPx, "px",
                delegate(Profile p) { return JumpOk(p) ? p.Jump.Phases[0].EndPx : 0; },
                delegate(Profile p, double v) { if (JumpOk(p)) p.Jump.Phases[0].EndPx = v; });
            down.Enabled = enabled; down.Decimals = 0; down.Increment = 1; // integers: widest value "-500" fits the box
            TutorialField up = TutorialField.Number("2. 然后往上移到多少", "可选", false, -JumpSettings.LimitPx, JumpSettings.LimitPx, "px",
                delegate(Profile p) { return JumpOk(p) ? p.Jump.Phases[1].EndPx : 0; },
                delegate(Profile p, double v) { if (JumpOk(p)) p.Jump.Phases[1].EndPx = v; });
            up.Enabled = enabled; up.Optional = true; up.Decimals = 0; up.Increment = 1;
            TutorialField total = TutorialField.Number("总时长", "可选", false, JumpSettings.MinTotalMs, JumpSettings.MaxTotalMs, "ms",
                delegate(Profile p) { return JumpOk(p) ? p.Jump.TotalMs : 700; },
                delegate(Profile p, double v) { if (JumpOk(p)) JumpSplit.SetTotal(p.Jump, (int)Math.Round(v)); });
            total.Enabled = enabled; total.Optional = true; total.Increment = 10; total.Decimals = 0;
            return new TutorialField[] { on, down, up, total };
        }

        // HUD text (constants: no per-frame strings)
        private const string WallLabel = "10 米 · 示意";
        private const string TagPreset = "预设路线 · 示意";
        private const string TagYours = "准星：你的数值";
        private const string TagYoursOff = "你的跳跃偏移：已关闭";
        private const string TagJumpNow = "起跳 …";
        private const string TagRight = "右手 D+E";
        private const string TagHand = "换手 Q+A";
        private const string TagEnemy = "虚拟敌人 · 示意";
        private const string TagEnemyView = "敌人视角 · 示意";
        private const string TagOurTarget = "我们的固定靶子";
        private const string TagVisible = "露出";
        private const string ChipJump = "A · 跳跃", ChipPeek = "B · 拉枪";
        private const string PlotTitle = "跳跃偏移 / 时间 · 示意";
        private const string PlotRef = "预设", PlotYou = "你的";
        private static readonly string[] LegendBoth = new string[] { PlotRef, PlotYou };
        private static readonly string[] LegendRef = new string[] { PlotRef };
        private Color[] legendColors;
        private const string MapTitle = "俯视 · 示意";
        private const string BarsTitle = "露出时间 · 示意";
        private const string SideTitle = "侧视 · 示意";
        private const string TermJump = "> 跳跃  预设路线 ……ok";
        private const string TermDone = "> 设置完成  返回精调";
        private static readonly string[] PhaseShort = new string[] { "先往下", "再往上", "回到起点" };
        private static readonly string[] SceneCaption = new string[] { TagRight, TagHand, TagEnemyView };
        private static readonly string[] BarLabelsR = new string[] { "只按 D", "只按 E", "D + E" };
        private static readonly string[] BarLabelsL = new string[] { "只按 A", "只按 Q", "Q + A" };
        private static readonly double[] BarTimes = new double[]
        {
            TutorialStep10Math.ClearTime(true, false), TutorialStep10Math.ClearTime(false, true), TutorialStep10Math.ClearTime(true, true)
        };
        /// <summary>Bar values as rounded seconds (示意, not exact-looking ms), built once.</summary>
        private static readonly string[] BarText = new string[]
        {
            TutorialStep10Math.SecondsText(BarTimes[0]), TutorialStep10Math.SecondsText(BarTimes[1]), TutorialStep10Math.SecondsText(BarTimes[2])
        };

        private readonly TutorialStep10Flow flow = new TutorialStep10Flow();
        private readonly FpRig rig = new FpRig();
        private Profile truthRef;
        private double prevT = -1;
        private bool prevJumping;
        private double sinceJumpEnd = 1e9;
        private bool termPushed;
        private string jumpName = "空格";
        private Color[] kindColors;

        // jump trail (UI px)
        private readonly float[] trRingY = new float[TutorialStep10Math.TrailMax];
        private readonly float[] trAimY = new float[TutorialStep10Math.TrailMax];
        private int trN;

        // cached labels (rebuilt only when the value changes)
        private double cachedMin = double.NaN;
        private string cachedMinStr = "";

        // peek: deterministic hit jitter (UI-free, metres on the target)
        private readonly float[] hitDX = new float[TutorialStep10Math.ShotsPerPeek];
        private readonly float[] hitDY = new float[TutorialStep10Math.ShotsPerPeek];

        public TutorialStep10Page()
        {
            Id = "jump";
            Chapter = "收尾";
            Title = "跳跃与拉枪";
            Body = "跳起来，同时开枪。\n准星会按预设路线移动。\n觉得不准，可以调几个数值。";
            DevNote = "最好的拉枪方式有两种：右手持枪按 D+E，这样相对速度最快；或者换手后按 Q+A，同样好用。战术手电推荐 WMX200，PVP 最优选：平时开 IR，接敌时开手电，它是我实测光遮蔽效果最大的手电。教程到这里就结束了，接下来回到每一页设置，再按自己的手感慢慢精调。";
            Prompts = new string[] { "按{跳跃键}跳起来，同时开枪", "看拉枪演示", "点「完成，去精调」" };
            Hint = Prompts[0];
            Terminal = new string[] { TermJump };
            FieldNote = NoteBase;
            SettingsPage = TutorialPages.Jump;
            Fields = JumpFields;
            KeysShown = TKey.Jump | TKey.Fire;
            ClickFires = true;
            TutorialRng r = new TutorialRng(4242);
            for (int i = 0; i < hitDX.Length; i++) { hitDX[i] = (float)(r.Spread() * 0.09); hitDY[i] = (float)(r.Spread() * 0.11); }
        }

        private const string NoteBase = "+ 是往上，− 是往下。画面里的路线是示意，\n真实数值以游戏里的弹孔为准。";

        /// <summary>FieldNote with the profile's current jump values (built on enter / field edit only, never per frame).</summary>
        private void RefreshFieldNote(TutorialContext c)
        {
            Profile p = c.P;
            string cur = "";
            if (JumpOk(p))
                cur = !p.Jump.Enabled ? "当前：跳跃偏移已关闭\n"
                    : "当前：先往下 " + TutorialNum.Signed(p.Jump.Phases[0].EndPx) + " px，再往上到 " + TutorialNum.Signed(p.Jump.Phases[1].EndPx)
                      + " px，总时长 " + TutorialNum.Int(p.Jump.TotalMs) + " ms\n";
            FieldNote = cur + NoteBase;
        }

        public override void Enter(TutorialContext c)
        {
            RefreshFieldNote(c);
            truthRef = Profile.CreateLeoDefault("示意");
            rig.TargetDistanceM = TutorialStep10Math.DistanceM;
            rig.Setup(c, truthRef, c.P == null ? truthRef : c.P, false);
            Profile t = rig.TruthP, r = rig.RingP;
            // only the jump shows: no recoil (示意)
            t.RecoilMaxPx = 0; t.RecoilClickKickPx = 0; t.RecoilDriftX = 0;
            r.RecoilMaxPx = 0; r.RecoilClickKickPx = 0; r.RecoilDriftX = 0;
            if (t.Jump == null) t.Jump = new JumpSettings();
            t.Jump.Enabled = true;
            if (r.Jump == null) r.Jump = new JumpSettings();
            rig.SetDistanceNow(TutorialStep10Math.DistanceM);
            rig.WallLabel = WallLabel;
            rig.UseParallax = false;
            rig.ShowRing = true; rig.ShowAim = false; rig.ShowCentre = true;
            rig.WallWm = 3.4; rig.WallHm = 6.0;
            rig.SpreadPx = 3.0;
            flow.Reset();
            prevT = -1; prevJumping = false; sinceJumpEnd = 1e9; trN = 0; termPushed = false;
            jumpName = c.PromptKey(KeyBindings.ActionJump);
            if (string.IsNullOrEmpty(jumpName)) jumpName = "?";
            PromptIndex = 0; Done = false;
            KeysShown = TKey.Jump | TKey.Fire;
        }

        public override void OnFieldChanged(TutorialContext c)
        {
            RefreshFieldNote(c);
            Profile p = c.P, r = rig.RingP;
            if (p == null || r == null) return;
            r.Jump = p.Jump == null ? new JumpSettings() : p.Jump.Clone();
            r.Diameter = p.Diameter; r.Thickness = p.Thickness; r.Color = p.Color; r.Color2 = p.Color2;
        }

        public override void OnChip(TutorialContext c, int id)
        {
            if (id == 1) flow.Select(TutorialStep10Flow.ModeJump);
            else if (id == 2) flow.Select(TutorialStep10Flow.ModePeek);
            if (flow.ModeChanged) ResetJumpDemo();
            PromptIndex = flow.Prompt;
        }

        private void ResetJumpDemo()
        {
            rig.ClearHoles();
            trN = 0; prevJumping = false; sinceJumpEnd = 1e9; prevT = -1;
            rig.Truth.Reset(); rig.Ring.Reset();
        }

        public override void Update(TutorialContext c, double dtMs)
        {
            bool live = !c.Scripted && (c.LiveMask != 0 || c.LiveFire);
            bool liveNow = c.LiveMask != 0 || c.LiveFire;
            int jumpShots = 0;
            if (flow.Mode == TutorialStep10Flow.ModeJump)
            {
                bool fire; int lit;
                InputState i = c.Input(Script, out fire, out lit);
                // this step is about the jump: lean and hand keys do not move the demo
                i.LeanL = false; i.LeanR = false; i.HandSwitch = false;
                LitKeys = lit & (TKey.Jump | TKey.Fire);
                if (c.Scripted)
                {
                    double t = Script.Wrap(c.Arbiter.ScriptMs);
                    if (t < prevT || c.Arbiter.Resumed) { rig.ClearHoles(); }
                    prevT = t;
                }
                else prevT = -1;
                rig.Update(dtMs, i, fire);
                if (!c.Scripted && rig.Truth.Jumping) jumpShots = rig.ShotsThisFrame;

                // trail of the current jump
                bool jumping = rig.Truth.Jumping || rig.Ring.Jumping;
                if (jumping && !prevJumping) trN = 0;
                if (jumping)
                {
                    sinceJumpEnd = 0;
                    if (trN < TutorialStep10Math.TrailMax) { trRingY[trN] = (float)rig.RingY; trAimY[trN] = (float)rig.AimY; trN++; }
                }
                else sinceJumpEnd += dtMs;
                if (sinceJumpEnd > 1e9) sinceJumpEnd = 1e9;
                prevJumping = jumping;
            }
            else
            {
                LitKeys = c.LiveMask & (TKey.Jump | TKey.Fire);
            }
            bool wantJump = liveNow && (c.Live.Jump || c.LiveFire || (c.LiveMask & (TKey.Jump | TKey.Fire)) != 0);
            flow.Tick(dtMs, live || liveNow, jumpShots, wantJump);
            if (flow.ModeChanged) ResetJumpDemo();
            KeysShown = flow.Mode == TutorialStep10Flow.ModeJump ? (TKey.Jump | TKey.Fire) : (TKey.D | TKey.E | TKey.Q | TKey.A);
            PromptIndex = flow.Prompt;
            if (flow.Done) Done = true;
            if (flow.JustWatched && !termPushed) { termPushed = true; c.Term.Push(TermDone); }
        }

        // =============================================================================================== drawing
        public override void Draw(TutorialGfx gx, TutorialContext c, RectangleF scene)
        {
            if (flow.Mode == TutorialStep10Flow.ModePeek) DrawPeek(gx, c, scene);
            else DrawJump(gx, c, scene);
            // chips (top centre) on top of either demo
            Graphics g = gx.G;
            g.SetClip(scene);
            Font cf = gx.F.Button;
            float cw = Math.Max(gx.S(86), Math.Max(gx.Measure(ChipJump, cf).Width, gx.Measure(ChipPeek, cf).Width) + gx.S(20));
            float ch = Math.Max(gx.S(24), cf.GetHeight(g) + gx.S(8)), gap = gx.S(8);
            float x0 = scene.Left + scene.Width / 2f - cw - gap / 2f, y0 = scene.Top + gx.S(10);
            gx.Chip(1, new RectangleF(x0, y0, cw, ch), ChipJump, flow.Mode == TutorialStep10Flow.ModeJump);
            gx.Chip(2, new RectangleF(x0 + cw + gap, y0, cw, ch), ChipPeek, flow.Mode == TutorialStep10Flow.ModePeek);
            g.ResetClip();
        }

        // ---------------------------------------------------------------- demo A: jump
        private void DrawJump(TutorialGfx gx, TutorialContext c, RectangleF scene)
        {
            TutorialPalette pal = gx.Pal;
            if (kindColors == null) kindColors = new Color[] { pal.Hot };
            rig.KindColors = kindColors;
            JumpSettings tj = rig.TruthP.Jump, rj = rig.RingP.Jump;
            bool ringOn = rj != null && rj.Enabled && rj.Phases != null && rj.Phases.Count >= 3;
            bool truthOn = tj != null && tj.Phases != null && tj.Phases.Count >= 3;
            double ext = TutorialStep10Math.JumpExtent(truthOn, truthOn ? tj.Phases[0].EndPx : 0, truthOn ? tj.Phases[1].EndPx : 0,
                ringOn, ringOn ? rj.Phases[0].EndPx : 0, ringOn ? rj.Phases[1].EndPx : 0, 24, 60);
            rig.Zoom = TutorialStep10Math.FitZoom(scene.Height / 2f, gx.K, ext, 0.74);
            // wall: top edge just below the chips so its label stays readable (示意 size)
            double zk = rig.Zoom * gx.K;
            if (zk > 0) rig.WallHm = TutorialStep10Math.WallHeightM(scene.Height / 2f - gx.S(14) - Math.Max(gx.S(24), gx.F.Button.GetHeight(gx.G) + gx.S(8)) - gx.S(8), zk, TutorialStep10Math.DistanceM);
            rig.Draw(gx, scene);

            Graphics g = gx.G;
            g.SetClip(scene);
            float cx = scene.Left + scene.Width / 2f, cy = scene.Top + scene.Height / 2f;
            float z = (float)(rig.Zoom * gx.K);
            float pad = gx.S(10);

            // trail of the last jump: bullets (hot, dashed guide) and ring (neon dots)
            double fade = 1 - sinceJumpEnd / TutorialStep10Math.TrailFadeMs;
            if (fade > 0 && trN > 1)
            {
                float xr = (float)(cx + rig.RingX * z), xa = (float)(cx + rig.AimX * z);
                for (int i = 1; i < trN; i++)
                {
                    double a = fade * (0.35 + 0.65 * i / (double)trN);
                    float y0 = cy - trAimY[i - 1] * z, y1 = cy - trAimY[i] * z;
                    g.DrawLine(gx.P(TutorialGfx.A(pal.Hot, a * 0.55), 3.5f), xa, y0, xa, y1);
                    g.DrawLine(gx.P(TutorialGfx.A(pal.Hot, a), 1.2f), xa, y0, xa, y1);
                }
                for (int i = 0; i < trN; i += 3)
                {
                    double a = fade * (0.3 + 0.7 * i / (double)trN);
                    gx.Dot(TutorialGfx.A(pal.Neon, a), xr + gx.S(8), cy - trRingY[i] * z, gx.S(1.6f));
                }
            }

            // depth bracket of the preset path (lowest point of the first phase)
            if (truthOn)
            {
                double low = Math.Min(0, Math.Min(tj.Phases[0].EndPx, tj.Phases[1].EndPx));
                if (low < -0.5)
                {
                    if (low != cachedMin) { cachedMin = low; cachedMinStr = TutorialNum.Signed(low) + " px"; }
                    float bx = cx - gx.S(44);
                    float yb = (float)(cy - low * z);
                    g.DrawLine(gx.Dashed(TutorialGfx.A(pal.Hot, 140), 1f), bx - gx.S(4), yb, cx + gx.S(20), yb);
                    gx.Bracket(bx, cy, yb, TutorialGfx.A(pal.Hot, 220), null);
                    float lh1 = gx.F.Mono.GetHeight(g), lh2 = gx.F.Tag.GetHeight(g);
                    float ly = (cy + yb) / 2f - (lh1 + lh2) / 2f;
                    gx.Text(cachedMinStr, gx.F.Mono, pal.Hot, bx - gx.S(10), ly, 2);
                    if (!c.Compact) gx.Text(TagPreset, gx.F.Tag, pal.Hot, bx - gx.S(10), ly + lh1, 2);
                }
            }

            // HUD tags (top-left)
            RectangleF t1 = gx.Tag(TagPreset, scene.Left + pad, scene.Top + pad, pal.Hot, 0);
            float capBottom = DrawJumpKeys(gx, scene);
            if (!c.Compact)
            {
                RectangleF t2 = gx.Tag(ringOn ? TagYours : TagYoursOff, scene.Left + pad, t1.Bottom + gx.S(5), ringOn ? pal.Neon : pal.Hot, 0);
                if (rig.Truth.Jumping) gx.Tag(TagJumpNow, scene.Left + pad, t2.Bottom + gx.S(5), pal.Accent, 0);
                // offset / time plot (right, under the key caps) and side view (bottom-left)
                DrawJumpPlot(gx, scene, capBottom + gx.S(8), tj, truthOn, rj, ringOn);
                DrawSideView(gx, scene, tj);
            }
            g.ResetClip();
        }

        private float DrawJumpKeys(TutorialGfx gx, RectangleF scene)
        {
            TutorialPalette pal = gx.Pal;
            bool jumpLit = (LitKeys & TKey.Jump) != 0 || rig.Truth.Jumping;
            bool fireLit = (LitKeys & TKey.Fire) != 0;
            float h = gx.S(28);
            float tw = gx.Measure(jumpName, gx.F.Key).Width;
            float w = Math.Max(gx.S(64), tw + gx.S(18));
            float mw = gx.S(18), mh = gx.S(27);
            float right = scene.Right - gx.S(10);
            float mx = right - mw, my = scene.Top + gx.S(10);
            RectangleF k = new RectangleF(mx - gx.S(10) - w, scene.Top + gx.S(10), w, h);
            if (jumpLit) gx.G.FillRectangle(gx.B(TutorialGfx.A(pal.Neon, 60)), k.X - gx.S(2), k.Y - gx.S(2), k.Width + gx.S(4), k.Height + gx.S(4));
            gx.G.FillRectangle(gx.B(jumpLit ? TutorialGfx.A(pal.Neon, 150) : TutorialGfx.A(pal.Surface, 235)), k);
            gx.G.DrawRectangle(gx.P(jumpLit ? pal.Neon : pal.Accent, jumpLit ? 1.6f : 1.1f), k.X, k.Y, k.Width, k.Height);
            gx.TextIn(jumpName, gx.F.Key, jumpLit ? Color.Black : pal.Text, k, gx.CenterMid);
            // mouse (left button = 开枪)
            gx.G.FillEllipse(gx.B(TutorialGfx.A(pal.Surface, 235)), mx, my, mw, mh);
            gx.G.DrawEllipse(gx.P(fireLit ? pal.Hot : pal.Border, 1.1f), mx, my, mw, mh);
            gx.G.FillPie(gx.B(fireLit ? pal.Hot : TutorialGfx.A(pal.Border, 160)), mx, my, mw, mw, 180, 90);
            if (fireLit) gx.Dot(TutorialGfx.A(pal.Hot, 60), mx + mw / 2, my + mh / 2, mw);
            return Math.Max(k.Bottom, my + mh);
        }

        private void DrawJumpPlot(TutorialGfx gx, RectangleF scene, float top, JumpSettings tj, bool truthOn, JumpSettings rj, bool ringOn)
        {
            TutorialPalette pal = gx.Pal;
            float w = Math.Min(gx.S(270), scene.Width * 0.34f), h = Math.Min(gx.S(160), scene.Height * 0.36f);
            if (w < gx.S(150) || h < gx.S(90)) return;
            RectangleF box = new RectangleF(scene.Right - w - gx.S(10), top, w, h);
            if (legendColors == null) legendColors = new Color[] { pal.Hot, pal.Neon };
            RectangleF inr = gx.PlotFrame(box, PlotTitle, ringOn ? LegendBoth : LegendRef, legendColors);
            float phaseH = gx.F.MonoSmall.GetHeight(gx.G);
            inr = new RectangleF(inr.Left, inr.Top, inr.Width, inr.Height - phaseH - gx.S(2));
            if (inr.Height < gx.S(24)) return;
            double total = 1;
            if (truthOn) total = Math.Max(total, tj.TotalMs);
            if (ringOn) total = Math.Max(total, rj.TotalMs);
            double lo = 0, hi = 0;
            for (int i = 0; i < 2; i++)
            {
                if (truthOn) { lo = Math.Min(lo, tj.Phases[i].EndPx); hi = Math.Max(hi, tj.Phases[i].EndPx); }
                if (ringOn) { lo = Math.Min(lo, rj.Phases[i].EndPx); hi = Math.Max(hi, rj.Phases[i].EndPx); }
            }
            double span = Math.Max(20, hi - lo);
            lo -= span * 0.12; hi += span * 0.12;
            Graphics g = gx.G;
            float y0 = TutorialStep10Math.PlotY(0, lo, hi, inr.Top, inr.Height);
            g.DrawLine(gx.P(TutorialGfx.A(pal.Border, 220), 1f), inr.Left, y0, inr.Right, y0);
            // phase boundaries of the preset
            if (truthOn)
            {
                double b = 0;
                for (int i = 0; i < 3; i++)
                {
                    double e = b + tj.Phases[i].Ms;
                    float xa = (float)(inr.Left + inr.Width * b / total), xb = (float)(inr.Left + inr.Width * e / total);
                    if (i > 0) g.DrawLine(gx.Dashed(TutorialGfx.A(pal.Muted, 90), 1f), xa, inr.Top, xa, inr.Bottom);
                    if (xb - xa > gx.Measure(PhaseShort[i], gx.F.MonoSmall).Width + gx.S(2))
                        gx.Text(PhaseShort[i], gx.F.MonoSmall, pal.Muted, (xa + xb) / 2f, inr.Bottom + gx.S(1), 1);
                    b = e;
                }
            }
            const int N = 64;
            if (ringOn) PlotCurve(gx, inr, rj, total, lo, hi, N, TutorialGfx.A(pal.Neon, 220), 1.3f, false);
            if (truthOn) PlotCurve(gx, inr, tj, total, lo, hi, N, pal.Hot, 1.4f, true);
            // cursor (current jump time)
            if (rig.Truth.Jumping && truthOn)
            {
                double t = rig.Truth.JumpMs;
                float x = (float)(inr.Left + inr.Width * Math.Min(1, t / total));
                g.DrawLine(gx.P(TutorialGfx.A(pal.Text, 90), 1f), x, inr.Top, x, inr.Bottom);
                gx.GlowDot(pal.Hot, x, TutorialStep10Math.PlotY(JumpPath.Offset(tj, t), lo, hi, inr.Top, inr.Height), gx.S(2.2f));
                if (ringOn && rig.Ring.Jumping)
                    gx.GlowDot(pal.Neon, x, TutorialStep10Math.PlotY(JumpPath.Offset(rj, rig.Ring.JumpMs), lo, hi, inr.Top, inr.Height), gx.S(1.8f));
            }
        }

        private static void PlotCurve(TutorialGfx gx, RectangleF inr, JumpSettings j, double total, double lo, double hi, int n,
            Color col, float w, bool glow)
        {
            Graphics g = gx.G;
            float px = inr.Left, py = TutorialStep10Math.PlotY(0, lo, hi, inr.Top, inr.Height);
            for (int i = 1; i <= n; i++)
            {
                double t = total * i / n;
                float x = (float)(inr.Left + inr.Width * i / n);
                float y = TutorialStep10Math.PlotY(t >= j.TotalMs ? 0 : JumpPath.Offset(j, t), lo, hi, inr.Top, inr.Height);
                if (glow) g.DrawLine(gx.P(TutorialGfx.A(col, 60), w * 3.2f), px, py, x, y);
                g.DrawLine(gx.P(col, w), px, py, x, y);
                px = x; py = y;
            }
        }

        private void DrawSideView(TutorialGfx gx, RectangleF scene, JumpSettings tj)
        {
            TutorialPalette pal = gx.Pal;
            float w = gx.S(132), h = gx.S(92);
            if (scene.Width < gx.S(420) || scene.Height < gx.S(260)) return;
            RectangleF box = new RectangleF(scene.Left + gx.S(10), scene.Bottom - h - gx.S(10), w, h);
            RectangleF inr = gx.PlotFrame(box, SideTitle);
            Graphics g = gx.G;
            float ground = inr.Bottom - gx.S(4);
            g.DrawLine(gx.P(TutorialGfx.A(pal.Neon, 120), 1f), inr.Left, ground, inr.Right, ground);
            for (float x = inr.Left + gx.S(6); x < inr.Right; x += gx.S(10)) g.DrawLine(gx.P(TutorialGfx.A(pal.Neon, 50), 1f), x, ground, x - gx.S(5), ground + gx.S(4));
            double air = rig.Truth.Jumping && tj != null ? TutorialStep10Math.AirHeight01(rig.Truth.JumpMs, tj.TotalMs) : 0;
            float lift = (float)(air * gx.S(24));
            float fx = inr.Left + inr.Width * 0.42f, feet = ground - lift;
            float bodyH = gx.S(30);
            // shadow
            gx.G.FillEllipse(gx.B(TutorialGfx.A(Color.Black, 120 - (int)(60 * air))), fx - gx.S(9) * (float)(1 - 0.3 * air), ground - gx.S(2), gx.S(18) * (float)(1 - 0.3 * air), gx.S(4));
            Color col = pal.Cyan;
            float hip = feet - bodyH * 0.45f, neck = feet - bodyH * 0.85f;
            float knee = (float)(air * gx.S(4));
            g.DrawLine(gx.P(col, 1.6f), fx, hip, fx - gx.S(4) - knee, feet);
            g.DrawLine(gx.P(col, 1.6f), fx, hip, fx + gx.S(4) + knee, feet);
            g.DrawLine(gx.P(col, 1.8f), fx, hip, fx, neck);
            gx.GlowCircle(col, 1.4f, fx, neck - gx.S(5), gx.S(4.5f));
            // rifle toward the wall (right)
            float gy = neck + gx.S(5);
            g.DrawLine(gx.P(TutorialGfx.A(pal.Text, 220), 1.6f), fx - gx.S(2), gy + gx.S(2), fx + gx.S(18), gy);
            // tracer to the wall when firing
            float wallX = inr.Right - gx.S(6);
            g.DrawLine(gx.P(TutorialGfx.A(pal.Accent, 160), 2f), wallX, inr.Top + gx.S(2), wallX, ground);
            if (rig.Firing) g.DrawLine(gx.P(TutorialGfx.A(pal.Hot, 170), 1f), fx + gx.S(18), gy, wallX, gy + (float)(-rig.AimY * 0.02 * gx.K));
            if (air > 0.02) gx.Arrow(TutorialGfx.A(pal.Neon, 200), 1.2f, fx - gx.S(16), ground - gx.S(4), fx - gx.S(16), ground - gx.S(6) - lift);
        }

        // ---------------------------------------------------------------- demo B: peek
        private void DrawPeek(TutorialGfx gx, TutorialContext c, RectangleF scene)
        {
            TutorialPalette pal = gx.Pal;
            Graphics g = gx.G;
            double local;
            int sc = TutorialStep10Math.PeekScene(flow.PeekMs, out local);
            float sgn = sc == 1 ? -1f : 1f;                     // 换手 Q+A peeks to the left
            bool enemyView = sc == 2;
            double tau = Math.Max(0, (local - TutorialStep10Math.KeysAt) / 1000.0);
            double cam = TutorialStep10Math.CamX(true, true, tau);
            double lean01 = TutorialStep10Math.Lean01(tau);
            bool visible = TutorialStep10Math.TargetVisible(cam);
            int shots = TutorialStep10Math.ShotsAt(local);
            double since = TutorialStep10Math.SinceShot(local);
            double roll = sgn * lean01 * 6.0 * Math.PI / 180.0;

            g.SetClip(scene);
            gx.SceneBackground(scene);
            float cx = scene.Left + scene.Width / 2f, cy = scene.Top + scene.Height / 2f;
            float f = scene.Width * 0.9f;                       // px per m at 1 m (示意)
            Color coverEdge = enemyView ? pal.Red : pal.Accent;
            Color targetCol = enemyView ? pal.Cyan : pal.Red;
            gx.Floor(scene, cx, cy, roll, enemyView ? pal.Red : pal.Neon);

            gx.BeginRoll(cx, cy, roll);
            // far wall (backdrop) at the target distance
            float horizon = cy;
            float tx = (float)(cx + sgn * TutorialStep10Math.ScreenX(TutorialStep10Math.TargetX, TutorialStep10Math.TargetZ, cam, f));
            float feet = (float)(horizon + TutorialStep10Math.AimH * f / TutorialStep10Math.TargetZ);
            float head = (float)(feet - TutorialStep10Math.TargetH * f / TutorialStep10Math.TargetZ);
            float aimY = horizon;
            // target silhouette (enemy, or our fixed target in the enemy's view)
            DrawTarget(gx, tx, feet, head, targetCol, enemyView, shots, since);
            // cover (near, occludes): from the edge to beyond the scene on the cover side
            float ex = (float)(cx + sgn * TutorialStep10Math.ScreenX(TutorialStep10Math.EdgeX, TutorialStep10Math.CoverZ, cam, f));
            float far = sgn > 0 ? scene.Left - scene.Width : scene.Right + scene.Width;
            float yTop = scene.Top - scene.Height, yBot = scene.Bottom + scene.Height;
            float l = Math.Min(far, ex), r = Math.Max(far, ex);
            g.FillRectangle(gx.B(Color.FromArgb(252, 18, 20, 23)), l, yTop, r - l, yBot - yTop);
            // cover texture: vertical panel lines + edge glow
            Pen pl = gx.P(TutorialGfx.A(coverEdge, 22), 1f);
            for (int i = 1; i < 7; i++) { float xx = ex - sgn * gx.S(28) * i; g.DrawLine(pl, xx, yTop, xx, yBot); }
            gx.GlowLine(TutorialGfx.A(coverEdge, 230), 1.4f, ex, yTop, ex, yBot);
            gx.EndRoll();

            // ring on the aim point (follows the target) and the shots
            float rx = tx, ry = aimY;
            PointF muzzle = gx.Gun(scene, (float)(-sgn * Math.Min(1, tau * 3) * gx.S(10) * (1 - lean01 * 0.5)), 0f,
                (float)(since < 60 ? (1 - since / 60.0) * gx.S(6) : 0), sc == 1 ? 1.0 : 0.0);
            if (visible && shots > 0 && since < 70)
            {
                PointF hit = new PointF(rx + hitDX[(shots - 1) % hitDX.Length] * f / (float)TutorialStep10Math.TargetZ,
                    ry + hitDY[(shots - 1) % hitDY.Length] * f / (float)TutorialStep10Math.TargetZ);
                double life = 1 - since / 70.0;
                g.DrawLine(gx.P(TutorialGfx.A(pal.Hot, life * 0.9), 1.6f), muzzle, hit);
                gx.Flash(muzzle, life);
            }
            Color ringCol = c.P != null ? FpRig.ParseColor(c.P.Color, pal.Neon) : pal.Neon;
            gx.Ring(rx, ry, gx.S(16), ringCol, Color.Black, 1.8f);

            // labels
            float pad = gx.S(10);
            RectangleF t1 = gx.Tag(SceneCaption[sc], scene.Left + pad, scene.Top + pad, enemyView ? pal.Red : pal.Neon, 0);
            if (visible)
            {
                string lbl = enemyView ? TagOurTarget : TagEnemy;
                gx.Tag(lbl, tx, head - gx.S(24), targetCol, 1);
            }
            float keysBottom = DrawPeekKeys(gx, scene, sc, local);
            float side = Math.Min(gx.S(220), scene.Width * 0.28f);
            if (!c.Compact)
            {
                DrawMap(gx, new RectangleF(scene.Left + pad, t1.Bottom + gx.S(8), side, side * 0.66f), sgn, cam, visible, enemyView);
                DrawBars(gx, new RectangleF(scene.Right - side - pad, keysBottom + gx.S(8), side, side * 0.62f), sc == 1);
            }

            // big caption at the start of each scene
            double capA = local < 1100 ? Math.Min(1, (1100 - local) / 400.0) : 0;
            if (capA > 0)
            {
                Color cc = enemyView ? pal.Red : pal.Neon;
                gx.TextMid(SceneCaption[sc], gx.F.Huge, TutorialGfx.A(cc, capA), cx, cy - scene.Height * 0.22f, 1);
            }
            // scene fade
            double fade = TutorialStep10Math.SceneFade(local);
            if (fade < 1) g.FillRectangle(gx.B(TutorialGfx.A(pal.SceneBg, 1 - fade)), scene);
            // progress ticks (3 scenes)
            float pw = gx.S(18), pg = gx.S(5), px0 = cx - (3 * pw + 2 * pg) / 2f, py = scene.Bottom - gx.S(10);
            for (int i = 0; i < 3; i++)
            {
                Color pc = i == sc ? (i == 2 ? pal.Red : pal.Neon) : (i < sc ? TutorialGfx.A(pal.Neon, 120) : TutorialGfx.A(pal.Border, 200));
                g.FillRectangle(gx.B(pc), px0 + i * (pw + pg), py, pw, gx.S(3));
            }
            g.ResetClip();
        }

        private void DrawTarget(TutorialGfx gx, float x, float feet, float head, Color col, bool board, int shots, double since)
        {
            Graphics g = gx.G;
            float h = feet - head;
            if (h < 2) return;
            float hr = h * 0.075f;
            float shW = h * 0.17f, hipW = h * 0.11f;
            float neckY = head + hr * 2.1f, hipY = head + h * 0.52f;
            if (board)
            {
                // our fixed target: a standing board with rings
                RectangleF b = new RectangleF(x - h * 0.22f, head, h * 0.44f, h * 0.78f);
                g.FillRectangle(gx.B(TutorialGfx.A(gx.Pal.Surface, 240)), b);
                g.DrawRectangle(gx.P(TutorialGfx.A(col, 220), 1.2f), b.X, b.Y, b.Width, b.Height);
                float bcx = x, bcy = head + h * 0.42f;
                for (int i = 1; i <= 3; i++) { float rr = h * 0.06f * i; g.DrawEllipse(gx.P(TutorialGfx.A(col, 150), 1f), bcx - rr, bcy - rr, 2 * rr, 2 * rr); }
                g.DrawLine(gx.P(TutorialGfx.A(col, 160), 1.4f), x - h * 0.1f, b.Bottom, x - h * 0.16f, feet);
                g.DrawLine(gx.P(TutorialGfx.A(col, 160), 1.4f), x + h * 0.1f, b.Bottom, x + h * 0.16f, feet);
            }
            else
            {
                PointF[] body = gx.Pts(8);
                body[0] = new PointF(x - shW * 0.5f, neckY);
                body[1] = new PointF(x + shW * 0.5f, neckY);
                body[2] = new PointF(x + shW * 0.62f, neckY + h * 0.12f);
                body[3] = new PointF(x + hipW * 0.5f, hipY);
                body[4] = new PointF(x + hipW * 0.55f, feet);
                body[5] = new PointF(x - hipW * 0.55f, feet);
                body[6] = new PointF(x - hipW * 0.5f, hipY);
                body[7] = new PointF(x - shW * 0.62f, neckY + h * 0.12f);
                g.FillPolygon(gx.B(TutorialGfx.A(col, 70)), body);
                g.DrawPolygon(gx.P(TutorialGfx.A(col, 60), 4f), body);
                g.DrawPolygon(gx.P(col, 1.3f), body);
                gx.G.FillEllipse(gx.B(TutorialGfx.A(col, 70)), x - hr, head, 2 * hr, 2 * hr);
                gx.GlowCircle(col, 1.2f, x, head + hr, hr);
            }
            // hits so far (fixed jitter, metres -> px)
            float s = h / (float)TutorialStep10Math.TargetH;
            int n = Math.Min(shots, hitDX.Length);
            for (int i = 0; i < n; i++)
            {
                float hx = x + hitDX[i] * s, hy = feet - (float)TutorialStep10Math.AimH * s + hitDY[i] * s;
                double fresh = (i == n - 1 && since < 300) ? 1 - since / 300.0 : 0;
                gx.Hole(hx, hy, gx.S(1.8f), fresh, 1, gx.Pal.Hot);
            }
        }

        private float DrawPeekKeys(TutorialGfx gx, RectangleF scene, int sc, double local)
        {
            TutorialPalette pal = gx.Pal;
            bool down = local >= TutorialStep10Math.KeysAt;
            float cap = gx.S(26), gap = gx.S(4);
            float x = scene.Right - gx.S(10) - 2 * cap - gap, y = scene.Top + gx.S(10);
            string k1 = sc == 1 ? "Q" : "E", k2 = sc == 1 ? "A" : "D";
            // lean key on the row above the move key, like the keyboard
            gx.KeyCap(x + (sc == 1 ? 0 : cap + gap), y, cap, k1, down, true);
            gx.KeyCap(x + (sc == 1 ? 0 : cap + gap), y + cap + gap, cap, k2, down, true);
            return y + 2 * cap + gap;
        }

        private void DrawMap(TutorialGfx gx, RectangleF box, float sgn, double cam, bool visible, bool enemyView)
        {
            TutorialPalette pal = gx.Pal;
            if (box.Width < gx.S(110) || box.Height < gx.S(60)) return;
            RectangleF inr = gx.PlotFrame(box, MapTitle);
            Graphics g = gx.G;
            // world: x sideways (peek side +) -0.9 .. 1.1 m, z ahead 0 .. 13 m (compressed)
            float mx0 = inr.Left + inr.Width * 0.5f, scaleX = inr.Width / 2.2f;
            float zTop = inr.Top, zBot = inr.Bottom;
            float camX = mx0 + sgn * (float)(cam * scaleX);
            float camY = zBot - gx.S(2);
            float coverY = zBot - (zBot - zTop) * 0.22f;
            float edgeX = mx0 + sgn * (float)(TutorialStep10Math.EdgeX * scaleX);
            float coverFar = sgn > 0 ? inr.Left : inr.Right;
            float tX = mx0 + sgn * (float)(TutorialStep10Math.TargetX * scaleX);
            float tY = zTop + gx.S(4);
            // cover block
            float cl = Math.Min(coverFar, edgeX), cr = Math.Max(coverFar, edgeX);
            g.FillRectangle(gx.B(TutorialGfx.A(enemyView ? pal.Red : pal.Accent, 70)), cl, coverY - gx.S(4), cr - cl, gx.S(8));
            g.DrawLine(gx.P(enemyView ? pal.Red : pal.Accent, 1.4f), edgeX, coverY - gx.S(4), edgeX, coverY + gx.S(4));
            // sight line camera -> target
            if (visible) gx.GlowLine(TutorialGfx.A(pal.Neon, 220), 1f, camX, camY, tX, tY);
            else g.DrawLine(gx.Dashed(TutorialGfx.A(pal.Muted, 150), 1f), camX, camY, tX, tY);
            // camera path from start
            g.DrawLine(gx.P(TutorialGfx.A(pal.Cyan, 160), 2f), mx0, camY, camX, camY);
            gx.GlowDot(enemyView ? pal.Red : pal.Cyan, camX, camY, gx.S(2.6f));
            gx.GlowDot(enemyView ? pal.Cyan : pal.Red, tX, tY, gx.S(2.6f));
            if (visible) gx.Text(TagVisible, gx.F.MonoSmall, pal.Neon, (camX + tX) / 2f + sgn * gx.S(6), (camY + tY) / 2f, sgn > 0 ? 0 : 2);
        }

        private void DrawBars(TutorialGfx gx, RectangleF box, bool left)
        {
            TutorialPalette pal = gx.Pal;
            if (box.Width < gx.S(150) || box.Height < gx.S(70)) return;
            RectangleF inr = gx.PlotFrame(box, BarsTitle);
            Graphics g = gx.G;
            Font f = gx.F.MonoSmall;
            string[] labels = left ? BarLabelsL : BarLabelsR;
            double max = 0;
            for (int i = 0; i < 3; i++) if (!double.IsInfinity(BarTimes[i])) max = Math.Max(max, BarTimes[i]);
            if (!(max > 0)) max = 1;
            // columns measured, so label, bar and value never overlap: [label] [bar ......] [≈0.16 s]
            float lw = 0, vw = 0;
            for (int i = 0; i < 3; i++) { lw = Math.Max(lw, gx.Measure(labels[i], f).Width); vw = Math.Max(vw, gx.Measure(BarText[i], f).Width); }
            float gap = gx.S(6);
            float bx = inr.Left + lw + gap, bw = inr.Right - vw - gap - bx;
            if (bw < gx.S(16)) return;
            float rowH = inr.Height / 3f;
            for (int i = 0; i < 3; i++)
            {
                float y = inr.Top + i * rowH, my = y + rowH / 2f;
                bool best = i == 2;
                Color col = best ? pal.Neon : pal.Muted;
                gx.TextMid(labels[i], f, best ? pal.Neon : pal.Text, inr.Left, my, 0);
                double t = BarTimes[i];
                float len = double.IsInfinity(t) ? bw : (float)(bw * t / max);
                RectangleF bar = new RectangleF(bx, y + rowH * 0.3f, Math.Max(gx.S(2), len), rowH * 0.4f);
                g.FillRectangle(gx.B(TutorialGfx.A(col, best ? 170 : 110)), bar);
                if (best) g.DrawRectangle(gx.P(TutorialGfx.A(pal.Neon, 80), 3f), bar.X, bar.Y, bar.Width, bar.Height);
                gx.TextMid(BarText[i], f, best ? pal.Neon : pal.Text, inr.Right, my, 2);
            }
        }
    }
#endif
}
