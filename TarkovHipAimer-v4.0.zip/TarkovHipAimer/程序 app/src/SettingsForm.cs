﻿using System;
#if !UI_PURE_CHECK
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
#endif

// UI_PURE_CHECK: when defined, only the pure logic (KeyCapture, UiPages) is compiled -- for the Linux tests.

namespace TarkovCrosshair
{
    /// <summary>
    /// The 按键 page's capture state machine (pure, no WinForms). Key down of a normal key finishes with the held
    /// modifiers (Ctrl+D); a modifier key waits and shows "Ctrl+…"; releasing a modifier that was pressed on its own
    /// binds the modifier itself (e.g. 强化 = Shift); Esc without modifiers cancels.
    /// </summary>
    internal sealed class KeyCapture
    {
        public const string Prompt = "请按键…（Esc 取消）";
        public const int VkEscape = 0x1B;
        public enum Result { Ignored, Waiting, Cancelled, Done }

        private int modKey; // the generic modifier pressed alone: 0 none, -1 several held
        public int Vk, Mods;
        public string Shown = Prompt;

        public void Start() { modKey = 0; Vk = 0; Mods = 0; Shown = Prompt; }

        /// <summary>Generic VK_SHIFT / VK_CONTROL / VK_MENU for any (left/right) modifier key, else vk.</summary>
        public static int GenericModifier(int vk)
        {
            switch (vk)
            {
                case 0xA0: case 0xA1: return 0x10;
                case 0xA2: case 0xA3: return 0x11;
                case 0xA4: case 0xA5: return 0x12;
                default: return vk;
            }
        }

        public static string PendingText(int mods)
        {
            string s = "";
            if ((mods & KeyBindings.ModCtrl) != 0) s += "Ctrl+";
            if ((mods & KeyBindings.ModShift) != 0) s += "Shift+";
            if ((mods & KeyBindings.ModAlt) != 0) s += "Alt+";
            return s.Length == 0 ? Prompt : s + "…";
        }

        /// <summary>mods = the Ctrl/Shift/Alt flags Windows reports with this key (they include the key's own flag).</summary>
        public Result KeyDown(int vk, int mods)
        {
            mods &= KeyBindings.ModMask;
            if (vk == VkEscape && mods == 0) return Result.Cancelled;
            if (vk <= 0 || vk > 254) return Result.Waiting;
            if (KeyBindings.IsModifierVk(vk))
            {
                int self = GenericModifier(vk);
                int bit = KeyBindings.ModBitOf(self);
                modKey = (mods & ~bit) == 0 ? self : -1;
                Shown = PendingText(mods | bit);
                return Result.Waiting;
            }
            Vk = vk;
            Mods = KeyBindings.NormalizeMods(vk, mods);
            return Result.Done;
        }

        /// <summary>heldMods = modifiers still down after this release (the released one may still be reported).</summary>
        public Result KeyUp(int vk, int heldMods)
        {
            vk = GenericModifier(vk);
            if (!KeyBindings.IsModifierVk(vk)) return Result.Ignored;
            if (modKey > 0 && vk == modKey) { Vk = vk; Mods = 0; return Result.Done; }
            modKey = 0;
            Shown = PendingText(heldMods & KeyBindings.ModMask & ~KeyBindings.ModBitOf(vk));
            return Result.Waiting;
        }

        /// <summary>Mouse button 1/2/4/5/6 with the modifiers held at the click.</summary>
        public Result Mouse(int vk, int mods)
        {
            if (vk <= 0) return Result.Ignored;
            Vk = vk;
            Mods = KeyBindings.NormalizeMods(vk, mods & KeyBindings.ModMask);
            return Result.Done;
        }
    }

    /// <summary>
    /// A captured key that another action already uses (pure). Answering 是 MOVES the key: the capturing action gets it
    /// and the other action takes the capturing action's old key, so no key ever ends up on two actions. W/A/S/D are
    /// fixed movement keys and cannot move: the question says so and 是 only binds the capturing action.
    /// </summary>
    internal static class KeyConflict
    {
        /// <summary>The action that already has vk+mods, other than 'action': a rebindable one first (that is the one
        /// that must move), else a fixed W/A/S/D action, else -1.</summary>
        public static int Find(KeyBindings k, int vk, int mods, int action)
        {
            int m = KeyBindings.NormalizeMods(vk, mods), movement = -1;
            for (int a = 0; a < KeyBindings.ActionCount; a++)
            {
                if (a == action || k.Get(a) != vk || k.GetMods(a) != m) continue;
                if (!KeyBindings.IsMovementAction(a)) return a;
                if (movement < 0) movement = a;
            }
            return movement;
        }

        public static string Question(KeyBindings k, int action, int vk, int mods, int other)
        {
            string key = KeyBindings.ComboName(vk, mods), name = KeyBindings.ActionNames[other];
            if (KeyBindings.IsMovementAction(other))
                return "「" + key + "」是固定的「" + name + "」键（W A S D 不能改）。还要用它当「" + KeyBindings.ActionNames[action]
                    + "」吗？按它会同时移动。";
            return "「" + key + "」现在是「" + name + "」。换过来吗？（「" + name + "」会改成 " + k.ComboOf(action) + "）";
        }

        /// <summary>Binds vk+mods to action; a non-movement 'other' (>= 0) gets action's previous combo. Returns the text
        /// for the status line.</summary>
        public static string Apply(KeyBindings k, int action, int vk, int mods, int other)
        {
            int oldVk = k.Get(action), oldMods = k.GetMods(action);
            k.SetCombo(action, vk, mods);
            string s = "已设置：" + KeyBindings.ActionNames[action] + " = " + k.ComboOf(action);
            if (other >= 0 && other != action && !KeyBindings.IsMovementAction(other))
            {
                k.SetCombo(other, oldVk, oldMods);
                s += "；" + KeyBindings.ActionNames[other] + " = " + k.ComboOf(other);
            }
            return s;
        }
    }

    /// <summary>Settings pages: ids for TutorialForm's jumpToPage, titles, lookup (pure).</summary>
    internal static class UiPages
    {
        /// <summary>Order = navigation order (SPEC v4).</summary>
        public static readonly string[] Ids = { "dashboard", "keys", "general", "recoil", "movement", "lean", "hand", "jump", "style", "guide", "feedback" };
        public static readonly string[] Titles = { "首页", "按键", "分辨率 · 常规", "后坐力", "移动", "侧身", "换手", "跳跃", "外观", "指南", "反馈" };
        /// <summary>Other names a page answers to (TutorialPages uses the short 「常规」).</summary>
        public static readonly string[] Aliases = { "仪表盘", "按键映射", "常规|分辨率", "", "", "", "", "", "准星样式", "说明|README|使用说明", "" };
        public static readonly string[] Codes = { "SYS.LIVE", "INPUT.MAP", "DISPLAY.CFG", "RECOIL.CFG", "MOTION.CFG", "LEAN.CFG", "HAND.CFG", "JUMP.CFG", "STYLE.CFG", "README.TXT", "CONTACT" };

        /// <summary>Index of a page by id ("keys", any case), Chinese title ("按键") or alias ("常规"); -1 if unknown.</summary>
        public static int IndexOf(string idOrTitle)
        {
            string s = (idOrTitle ?? "").Trim();
            if (s.Length == 0) return -1;
            for (int i = 0; i < Ids.Length; i++)
            {
                if (string.Equals(Ids[i], s, StringComparison.OrdinalIgnoreCase) || Titles[i] == s) return i;
                foreach (string a in Aliases[i].Split('|')) if (a.Length > 0 && a == s) return i;
            }
            return -1;
        }
    }

#if !UI_PURE_CHECK
    /// <summary>Button that captures a key, mouse button or combo (Ctrl/Shift/Alt + key) for one action of the 按键 page.</summary>
    internal sealed class KeyButton : Button
    {
        public int Action; // KeyBindings action index
    }

    /// <summary>
    /// Settings window (v4.0): header, one-line top bar, left navigation, one page at a time.
    /// Page order (SPEC v4): 首页 dashboard, 按键, 常规, 后坐力, 移动, 侧身, 换手, 跳跃, 外观, 指南, 反馈. Always live: no preview modes.
    /// Layout rules (from v3.0): every grid is a TableLayoutPanel, every fixed pixel size goes through S()
    /// (system DPI / 96, AutoScaleMode None), fonts are in points, pages scroll, minimum size keeps the bars on one line.
    /// </summary>
    internal sealed partial class SettingsForm : Form
    {
        /// <summary>Layout scale (system DPI / 96). Settable before construction for layout tests only.</summary>
        internal static float ScaleOverride = 0f;

        public const string GitHubUrl = "https://github.com/liumuyangmuyang-blip/Tarkov-Hip-Aimer";
        public const string Email = "liumuyangmuyang@gmail.com";
        public const string Douyin = "Muuslati";
        /// <summary>The 反馈 page sentence, word for word (SPEC v4 item 12).</summary>
        public const string FeedbackText = "功能建议 / 反馈创意 / Bug 反馈：GitHub、邮箱 liumuyangmuyang@gmail.com、抖音号 Muuslati（主页有交流群）。更新会发布在 GitHub 和抖音群内。";


        private sealed class Page
        {
            public string Id, Title;
            public Panel Host;       // what is shown / hidden
            public Panel Scroller;   // the scrolling body (null for the dashboard)
            public Control Content;  // measured for the window size (null = fills)
            public PageTitle Heading;
            public NavItem Nav;
        }

        private readonly App app;
        private readonly float k;
        private Font monoFont;
        private bool loading;
        private readonly List<Action> refreshers = new List<Action>();
        private readonly List<NumericUpDown> nums = new List<NumericUpDown>();
        /// <summary>Controls shown only while 「高级设置」 is on (UiPrefs).</summary>
        private readonly List<Control> advOnly = new List<Control>();
        /// <summary>Every 「可选：…」 fold: opened when 高级设置 turns on (no second gate), closed again when it turns off.</summary>
        private readonly List<FoldHeader> folds = new List<FoldHeader>();
        private int advState = -1; // last applied 高级设置: -1 never, 0 off, 1 on
        private CheckBox chkAdvanced;
        /// <summary>Dynamic text size (SPEC v4): UiScale of the client size; fonts = base pt x uiScale.</summary>
        private double uiScale = 1.0;
        private readonly List<Action> fontFixups = new List<Action>();
        private readonly Timer scaleTimer = new Timer();
        private readonly ToolTip tips = new ToolTip();
        private readonly List<Page> pages = new List<Page>();
        private int current = -1;

        private ComboBox cbProfile;
        private CheckBox chkEnabled;
        private CheckBox chkAutostart;
        private ComboBox cbMonitor;
        private ContextMenuStrip profileMenu;
        private ContextMenuStrip restoreMenu;
        private ContextMenuStrip windowMenu;
        private ToolStripMenuItem restoreSaved;
        private Label lblSave;
        private GlowButton btnTutorial;
        private TableLayoutPanel root;
        private Control header;
        private TableLayoutPanel topBar;
        private TableLayoutPanel navBar;
        private Panel navHost;       // scrolls the navigation when the window is very short
        private TableLayoutPanel body;
        private bool fittingNav;
        private Panel pageHost;
        private Control dashboard;
        private Control stylePanel;
        private Form tutorial;
        private readonly MotionEngine dashEngine = new MotionEngine();
        private readonly Timer saveFlash = new Timer();

        private KeyButton capturing;
        private readonly KeyCapture capture = new KeyCapture();
        private bool suppressNextClick;
        public bool AllowClose;

        private GlobalSettings G { get { return app.Settings; } }
        private Profile Cur { get { return app.Settings.Active; } }

        public SettingsForm(App app)
        {
            this.app = app;
            k = ScaleOverride > 0 ? ScaleOverride : SystemScale();
            SuspendLayout();
            AutoScaleMode = AutoScaleMode.None; // every pixel size is scaled explicitly by S()
            Font = Theme.Ui(BaseUiPt);     // SPEC v4 readability: body / labels / buttons >= 11 pt
            monoFont = Theme.Mono(BaseMonoPt); // numbers / data >= 11 pt
            scaleTimer.Interval = 100;         // resize debounce
            scaleTimer.Tick += delegate { scaleTimer.Stop(); UpdateUiScale(); };
            Text = Program.ProductName + "  " + Program.Version;
            if (app.RingIcon != null) Icon = app.RingIcon;
            KeyPreview = true;
            StartPosition = FormStartPosition.CenterScreen;
            ShowInTaskbar = true;
            TopMost = G.SettingsTopMost;
            tips.AutoPopDelay = 15000;
            tips.InitialDelay = 400;
            Theme.StyleToolTip(tips, delegate { return Font; }); // 11 pt x uiScale, dark (stock tooltips are ~9 pt)

            root = new TableLayoutPanel();
            root.Dock = DockStyle.Fill;
            root.ColumnCount = 1;
            root.RowCount = 3;
            root.Margin = new Padding(0);
            root.Padding = new Padding(0);
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));       // header
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));       // top bar
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));  // nav + page
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            Controls.Add(root);

            header = Theme.Header(Program.ShortName, Program.ChineseName + " · by Leo", Program.Version);
            header.Dock = DockStyle.Top;
            header.Margin = new Padding(0);
            root.Controls.Add(header, 0, 0);
            BuildTopBar();

            body = new TableLayoutPanel();
            body.Dock = DockStyle.Fill;
            body.Margin = new Padding(0);
            body.Padding = new Padding(0);
            body.ColumnCount = 3;
            body.RowCount = 1;
            body.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, NavWidth));
            body.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 1));     // divider
            body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            body.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            root.Controls.Add(body, 0, 2);

            navHost = new Panel();
            navHost.Dock = DockStyle.Fill;
            navHost.Margin = new Padding(0);
            navHost.AutoScroll = true;
            navHost.BackColor = Theme.ColBackground;
            body.Controls.Add(navHost, 0, 0);
            navBar = new TableLayoutPanel();
            navBar.Dock = DockStyle.None;
            navBar.Location = new Point(0, 0);
            navBar.Margin = new Padding(0);
            navBar.Padding = P(0, 10, 0, 10);
            navBar.ColumnCount = 1;
            navBar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            navBar.BackColor = Theme.ColBackground;
            navHost.Controls.Add(navBar);
            Panel divider = new Panel();
            divider.Dock = DockStyle.Fill;
            divider.Margin = new Padding(0);
            divider.BackColor = Theme.ColBorder;
            divider.Tag = "theme:keep-divider";
            body.Controls.Add(divider, 1, 0);

            pageHost = new Panel();
            pageHost.Dock = DockStyle.Fill;
            pageHost.Margin = new Padding(0);
            pageHost.BackColor = Theme.ColSurface;
            body.Controls.Add(pageHost, 2, 0);
            pageHost.Resize += delegate { FitWrapping(); };

            AddPage(0, BuildDashboard(), false);
            AddPage(1, BuildKeys(), true);
            AddPage(2, BuildGeneral(), true);
            AddPage(3, BuildRecoil(), true);
            AddPage(4, BuildMovement(), true);
            AddPage(5, BuildLean(), true);
            AddPage(6, BuildHand(), true);
            AddPage(7, BuildJump(), true);
            AddPage(8, BuildStyle(), false);
            AddPage(9, BuildGuide(), false);
            AddPage(10, BuildFeedback(), true);
            BuildNavFooter();
            Theme.StyleToolTips(stylePanel, delegate { return Font; }); // 外观 tips: same readable look as the rest

            saveFlash.Interval = 2500;
            saveFlash.Tick += delegate { saveFlash.Stop(); if (lblSave.ForeColor != Theme.ColWarn) lblSave.ForeColor = Theme.ColMuted; };
            app.SaveStatusChanged += delegate { SetStatus(app.SaveStatus, app.SaveStatus.StartsWith("保存失败")); };

            RefreshAll();
            ResumeLayout(false);
            PerformLayout();
            Theme.Apply(this);
            PaintHandRows(); // after the theme, so 自动 rows are grey
            ShowPage(0);
            ActiveControl = pages[0].Nav; // no highlighted text box on open
        }

        /// <summary>Navigation width: 188 px (100 %), 132 px when the window is narrower than 940 px logical (tiny screen at high scaling).</summary>
        private int NavWidth { get { return ClientSize.Width > 0 && ClientSize.Width < S(940) ? F(164) : F(204); } }

        private const float BaseUiPt = 11f, BaseMonoPt = 11f;

        /// <summary>Scales a 96-DPI length that belongs to text (box widths, wrap widths, nav rows): DPI x uiScale.</summary>
        private int F(int px) { return (int)Math.Round(px * k * uiScale); }

        /// <summary>Runs a size-from-font rule now and again after every text-size change.</summary>
        private void FixUp(Action a) { fontFixups.Add(a); a(); }

        private bool topBarTwoRows;

        /// <summary>Very narrow window (e.g. 1280x720 at 200 %): the two switches and the status move to a second line, so
        /// nothing in the top bar is ever cut off. One line again as soon as it fits (24 px hysteresis).</summary>
        private void FitTopBar()
        {
            if (topBar == null || chkEnabled == null || chkAdvanced == null || lblSave == null) return;
            int oneRow = 0;
            foreach (Control c in new Control[] { topBar.GetControlFromPosition(0, 0), cbProfile, topBar.GetControlFromPosition(2, 0),
                topBar.GetControlFromPosition(3, 0), topBar.GetControlFromPosition(4, 0), chkAdvanced, chkEnabled })
                if (c != null) oneRow += c.GetPreferredSize(Size.Empty).Width + c.Margin.Horizontal;
            oneRow += topBar.Padding.Horizontal + F(40); // + a little room for the status text
            int avail = ClientSize.Width;
            bool two = topBarTwoRows ? oneRow > avail - S(24) : oneRow > avail;
            if (two == topBarTwoRows) return;
            topBarTwoRows = two;
            topBar.SuspendLayout();
            if (two)
            {
                topBar.SetCellPosition(chkAdvanced, new TableLayoutPanelCellPosition(0, 1));
                topBar.SetColumnSpan(chkAdvanced, 2);
                topBar.SetCellPosition(chkEnabled, new TableLayoutPanelCellPosition(2, 1));
                topBar.SetColumnSpan(chkEnabled, 2);
                topBar.SetCellPosition(lblSave, new TableLayoutPanelCellPosition(4, 1));
                topBar.SetColumnSpan(lblSave, 2);
                chkAdvanced.Anchor = AnchorStyles.Left;
                chkEnabled.Anchor = AnchorStyles.Left;
            }
            else
            {
                topBar.SetColumnSpan(chkAdvanced, 1);
                topBar.SetColumnSpan(chkEnabled, 1);
                topBar.SetColumnSpan(lblSave, 1);
                topBar.SetCellPosition(lblSave, new TableLayoutPanelCellPosition(5, 0));
                topBar.SetCellPosition(chkAdvanced, new TableLayoutPanelCellPosition(6, 0));
                topBar.SetCellPosition(chkEnabled, new TableLayoutPanelCellPosition(7, 0));
                chkAdvanced.Anchor = AnchorStyles.Right;
                chkEnabled.Anchor = AnchorStyles.Right;
            }
            topBar.ResumeLayout(true);
        }

        private void UpdateUiScale()
        {
            if (IsDisposed || WindowState == FormWindowState.Minimized) return;
            double s = UiScale.For(ClientSize.Width, ClientSize.Height, k * 96f);
            if (Math.Abs(s - uiScale) > 0.001) ApplyUiScale(s);
        }

        /// <summary>New text size for the whole window (not DashboardPanel / StylePanel, which scale themselves):
        /// new fonts, explicit fonts swapped, size rules re-run, old fonts disposed.</summary>
        private void ApplyUiScale(double s)
        {
            Font oldUi = Font, oldMono = monoFont;
            Font newUi = Theme.Ui(UiScale.Pt(BaseUiPt, s, BaseUiPt));
            Font newMono = Theme.Mono(UiScale.Pt(BaseMonoPt, s, BaseMonoPt));
            SuspendLayout();
            try
            {
                uiScale = s;
                monoFont = newMono;
                Font = newUi;
                SwapFonts(this, oldUi, newUi, oldMono, newMono);
                foreach (ContextMenuStrip m in new ContextMenuStrip[] { profileMenu, restoreMenu, windowMenu })
                    if (m != null) m.Font = newUi;
                Theme.SetHeaderScale(header, s);
                if (navBar != null && navBar.RowStyles.Count >= pages.Count + 2) navBar.RowStyles[pages.Count + 1].Height = F(56);
                foreach (Action a in fontFixups) { try { a(); } catch (Exception) { } }
                if (body != null && body.ColumnStyles.Count > 0) body.ColumnStyles[0].Width = NavWidth;
            }
            finally { ResumeLayout(true); }
            FitWrapping();
            FitNav();
            FitTopBar();
            Invalidate(true);
            if (oldUi != null && oldUi != newUi) oldUi.Dispose();
            if (oldMono != null && oldMono != newMono) oldMono.Dispose();
        }

        private void SwapFonts(Control parent, Font oldUi, Font newUi, Font oldMono, Font newMono)
        {
            foreach (Control c in parent.Controls)
            {
                if (c == dashboard || c == stylePanel) continue; // they own their fonts
                if (c.Font == oldUi) c.Font = newUi;
                else if (c.Font == oldMono) c.Font = newMono;
                SwapFonts(c, oldUi, newUi, oldMono, newMono);
            }
        }

        protected override void OnClientSizeChanged(EventArgs e)
        {
            base.OnClientSizeChanged(e);
            if (body == null || body.ColumnStyles.Count == 0) return;
            int nw = NavWidth;
            if ((int)body.ColumnStyles[0].Width != nw) body.ColumnStyles[0].Width = nw;
            FitTopBar();
            if (IsHandleCreated) { scaleTimer.Stop(); scaleTimer.Start(); } // text size follows the window (debounced)
            if (btnTutorial != null)
            {
                Padding m = nw < F(204) ? P(8, 6, 8, 6) : P(14, 6, 14, 6);
                if (btnTutorial.Margin != m) btnTutorial.Margin = m;
            }
        }

        private static float SystemScale()
        {
            try
            {
                using (Graphics g = Graphics.FromHwnd(IntPtr.Zero))
                {
                    float s = g.DpiX / 96f;
                    if (s >= 0.5f && s <= 5f) return s;
                }
            }
            catch (Exception) { }
            return 1f;
        }

        // ---------------- layout helpers ----------------

        /// <summary>Scales a 96-DPI pixel length.</summary>
        private int S(int px) { return (int)Math.Round(px * k); }
        private Size Sz(int w, int h) { return new Size(S(w), S(h)); }
        private Padding P(int l, int t, int r, int b) { return new Padding(S(l), S(t), S(r), S(b)); }

        private TableLayoutPanel Grid(int cols)
        {
            TableLayoutPanel t = new TableLayoutPanel();
            t.ColumnCount = cols;
            t.AutoSize = true;
            t.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            t.Margin = new Padding(0);
            t.Padding = new Padding(0);
            for (int i = 0; i < cols; i++) t.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            return t;
        }

        /// <summary>One row of controls side by side (a 1-row grid: never wraps).</summary>
        private TableLayoutPanel Line(params Control[] items)
        {
            TableLayoutPanel t = Grid(items.Length);
            t.RowCount = 1;
            t.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            t.Anchor = AnchorStyles.Left;
            for (int i = 0; i < items.Length; i++) t.Controls.Add(items[i], i, 0);
            return t;
        }

        /// <summary>Vertical stack of blocks (1-column grid).</summary>
        private TableLayoutPanel Stack(params Control[] items)
        {
            TableLayoutPanel t = Grid(1);
            foreach (Control c in items)
            {
                c.Anchor = AnchorStyles.Top | AnchorStyles.Left;
                t.Controls.Add(c);
            }
            return t;
        }

        private Label Lbl(string text)
        {
            Label l = new Label();
            l.Text = text;
            l.AutoSize = true;
            l.Anchor = AnchorStyles.Left;
            l.Margin = P(3, 3, 6, 3);
            return l;
        }

        /// <summary>Empty, zero-width cell filler (a plain new Label() would be 100 px wide).</summary>
        private static Label Blank()
        {
            // zero-size: a row whose only visible items are hidden collapses instead of leaving an empty line
            Label l = new Label();
            l.AutoSize = false;
            l.Size = Size.Empty;
            l.Text = "";
            l.Margin = new Padding(0);
            return l;
        }

        private Label Unit(string text)
        {
            Label l = Lbl(text);
            l.Margin = P(0, 3, 6, 3);
            l.ForeColor = SystemColors.GrayText;
            return l;
        }

        /// <summary>Muted note that wraps at maxWidth (96-DPI px).</summary>
        /// <summary>Wrapping labels and their preferred width (96-DPI px); narrowed to the page when the window is small.</summary>
        private readonly List<KeyValuePair<Label, int>> wrapping = new List<KeyValuePair<Label, int>>();

        /// <summary>Wrap width = min(preferred, what the visible page can show), so long notes never run off the page.</summary>
        private void FitWrapping()
        {
            if (pageHost == null) return;
            int avail = pageHost.ClientSize.Width - S(22 + 10) - SystemInformation.VerticalScrollBarWidth - S(60);
            if (avail < S(160)) avail = S(160);
            foreach (KeyValuePair<Label, int> kv in wrapping)
            {
                int w = Math.Min(F(kv.Value), avail);
                if (kv.Key.MaximumSize.Width != w) kv.Key.MaximumSize = new Size(w, 0);
            }
        }

        private Label Note(string text, int maxWidth)
        {
            Label l = Lbl(text);
            wrapping.Add(new KeyValuePair<Label, int>(l, maxWidth));
            l.ForeColor = SystemColors.GrayText;
            l.MaximumSize = new Size(S(maxWidth), 0);
            l.Margin = P(3, 6, 6, 6);
            return l;
        }

        /// <summary>Small coloured tag ("推荐") drawn as plain text in the accent colour.</summary>
        private Label TagLabel(string text, Color c)
        {
            Label l = Lbl(text);
            l.ForeColor = c;
            l.Font = monoFont;
            l.Tag = "theme:keep-tag";
            l.BackColor = Color.Transparent;
            return l;
        }

        private void Tip(Control c, string text) { tips.SetToolTip(c, text); }

        private static void Row(TableLayoutPanel g, Control label, params Control[] cells)
        {
            g.Controls.Add(label);
            foreach (Control c in cells)
            {
                if (c.Anchor == (AnchorStyles.Top | AnchorStyles.Left)) c.Anchor = AnchorStyles.Left;
                g.Controls.Add(c);
            }
        }

        private void Row(TableLayoutPanel g, string label, params Control[] cells) { Row(g, Lbl(label), cells); }

        private Section Group(string title, Control content)
        {
            Section sec = new Section(title, content, k);
            sec.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            return sec;
        }

        /// <summary>"▸ title" header + content that is hidden until the header is clicked.</summary>
        private Control Fold(string title, Control content)
        {
            FoldHeader h = new FoldHeader(title, k);
            h.Font = Font;
            h.Margin = P(0, 4, 0, 4);
            FixUp(delegate { h.Size = h.GetPreferredSize(Size.Empty); });
            content.Visible = false;
            content.Margin = P(14, 0, 0, 6);
            h.Toggled += delegate { content.Visible = h.Open; };
            folds.Add(h);
            TableLayoutPanel t = Stack(h, content);
            t.Margin = P(0, 4, 0, 0);
            return t;
        }

        private static decimal ToDec(double v, NumericUpDown n)
        {
            if (double.IsNaN(v) || double.IsInfinity(v)) v = 0;
            decimal d = (decimal)Math.Round(v, n.DecimalPlaces);
            if (d < n.Minimum) d = n.Minimum;
            if (d > n.Maximum) d = n.Maximum;
            return d;
        }

        /// <summary>Yes / no question in the window's own look and text size (CX2: the stock MessageBox is ~9 pt).</summary>
        private bool Ask(string question)
        {
            return ThemedDialog.Show(this, question, true);
        }

        /// <summary>Information / error message with one 「知道了」 button, same look as Ask.</summary>
        private void Say(string message)
        {
            ThemedDialog.Show(this, message, false);
        }

        /// <summary>Width that fits the widest value of a number box at the mono font and DPI.</summary>
        private int NumWidth(double min, double max, int dec)
        {
            string wide = (min < 0 ? "-" : "") + new string('8', Math.Max(1, ((long)Math.Max(Math.Abs(min), Math.Abs(max))).ToString().Length))
                + (dec > 0 ? "." + new string('8', dec) : "");
            return TextRenderer.MeasureText(wide, monoFont).Width + SystemInformation.VerticalScrollBarWidth + S(16);
        }

        /// <summary>The mouse wheel scrolls the page, never the value of a box that happens to have focus.</summary>
        private void WheelScrollsPage(Control c)
        {
            c.MouseWheel += delegate(object s, MouseEventArgs e)
            {
                ComboBox cb = s as ComboBox;
                if (cb != null && cb.DroppedDown) return;
                HandledMouseEventArgs he = e as HandledMouseEventArgs;
                if (he != null) he.Handled = true;
                ScrollCurrentPage(e.Delta);
            };
        }

        private void ScrollCurrentPage(int delta)
        {
            if (current < 0 || pages[current].Scroller == null) return;
            Panel p = pages[current].Scroller;
            Point cur = p.AutoScrollPosition; // negative
            int step = Math.Max(S(40), SystemInformation.MouseWheelScrollLines * Font.Height);
            int y = Math.Max(0, -cur.Y - Math.Sign(delta) * step);
            p.AutoScrollPosition = new Point(-cur.X, y);
        }

        /// <summary>NumericUpDown bound to a model value. ValueChanged writes the model, publishes and schedules a save.</summary>
        private NumericUpDown Num(double min, double max, double inc, int dec, Func<double> get, Action<double> set)
        {
            NumericUpDown n = new NumericUpDown();
            n.Minimum = (decimal)min;
            n.Maximum = (decimal)max;
            n.Increment = (decimal)inc;
            n.DecimalPlaces = dec;
            n.Font = monoFont;
            FixUp(delegate { n.Width = NumWidth(min, max, dec); });
            n.Margin = P(3, 3, 3, 3);
            n.Anchor = AnchorStyles.Left;
            n.TextAlign = HorizontalAlignment.Left;
            n.ValueChanged += delegate
            {
                if (loading) return;
                set((double)n.Value);
                app.Changed();
            };
            WheelScrollsPage(n);
            refreshers.Add(delegate { n.Value = ToDec(get(), n); });
            nums.Add(n);
            return n;
        }

        private ComboBox Choice(string[] labels, string[] values, Func<string> get, Action<string> set)
        {
            ComboBox c = new ComboBox();
            c.DropDownStyle = ComboBoxStyle.DropDownList;
            c.Items.AddRange(labels);
            FixUp(delegate
            {
                int w = F(70);
                foreach (string l in labels) w = Math.Max(w, TextRenderer.MeasureText(l, Font).Width + SystemInformation.VerticalScrollBarWidth + S(16));
                c.Width = w;
            });
            c.Margin = P(3, 3, 3, 3);
            c.Anchor = AnchorStyles.Left;
            c.SelectedIndexChanged += delegate
            {
                if (loading || c.SelectedIndex < 0) return;
                set(values[c.SelectedIndex]);
                app.Changed();
            };
            WheelScrollsPage(c);
            refreshers.Add(delegate
            {
                int idx = Array.IndexOf(values, get());
                c.SelectedIndex = idx < 0 ? 0 : idx;
            });
            return c;
        }

        private CheckBox Check(string text, Func<bool> get, Action<bool> set)
        {
            CheckBox c = new CheckBox();
            c.Text = text;
            c.AutoSize = true;
            c.Anchor = AnchorStyles.Left;
            c.Margin = P(3, 3, 8, 3);
            c.CheckedChanged += delegate
            {
                if (loading) return;
                set(c.Checked);
                app.Changed();
            };
            refreshers.Add(delegate { c.Checked = get(); });
            return c;
        }

        private Button Btn(string text, EventHandler onClick)
        {
            Button b = new Button();
            b.Text = text;
            b.AutoSize = true;
            b.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            b.Anchor = AnchorStyles.Left;
            b.Margin = P(3, 2, 3, 2);
            b.Padding = P(6, 1, 6, 1);
            b.Click += onClick;
            return b;
        }

        /// <summary>Primary (neon) button.</summary>
        private Button AccentBtn(string text, EventHandler onClick)
        {
            Button b = Btn(text, onClick);
            b.Tag = "theme:accent";
            return b;
        }

        /// <summary>Enables a set of controls while cond() holds (refreshed with the values and on demand).</summary>
        private Action EnableWhen(Func<bool> cond, params Control[] targets)
        {
            Action a = delegate { bool on = cond(); foreach (Control c in targets) c.Enabled = on; };
            refreshers.Add(a);
            return a;
        }

        private void SetStatus(string text, bool warn)
        {
            if (lblSave == null) return;
            lblSave.Text = text ?? "";
            Tip(lblSave, text ?? "");
            lblSave.ForeColor = warn ? Theme.ColWarn : Theme.ColAccent;
            saveFlash.Stop();
            if (!warn) saveFlash.Start(); // fades back to muted
        }

        /// <summary>
        /// Commits text typed into a number box that still has focus (NumericUpDown only parses its text on leave;
        /// reading Value parses it). Called before anything that could overwrite or lose it: page switch, profile switch,
        /// tutorial, hiding the window, 退出.
        /// </summary>
        public void CommitEdits()
        {
            foreach (NumericUpDown n in nums)
            {
                try { if (!n.IsDisposed) { decimal unused = n.Value; } }
                catch (Exception) { }
            }
        }

        /// <summary>「高级设置」 on: every page also shows its non-essential options.</summary>
        private bool Advanced { get { return UiPrefs.Advanced(G); } }

        /// <summary>Registers controls that are visible only in 「高级设置」; returns the first.</summary>
        private Control AdvOnly(params Control[] cs)
        {
            foreach (Control c in cs) advOnly.Add(c);
            return cs.Length > 0 ? cs[0] : null;
        }

        /// <summary>A grid row (label + cells) that exists only in 「高级设置」.</summary>
        private void AdvRow(TableLayoutPanel g, Control label, params Control[] cells)
        {
            AdvOnly(label);
            AdvOnly(cells);
            Row(g, label, cells);
        }

        private void AdvRow(TableLayoutPanel g, string label, params Control[] cells) { AdvRow(g, Lbl(label), cells); }

        private void RefreshAdvanced()
        {
            bool on = Advanced;
            foreach (Control c in advOnly) c.Visible = on;
            int state = on ? 1 : 0;
            if (state != advState)
            {
                // CX2 B9/B10: with 高级设置 on the extra options are shown at once (the fold headers stay, so a section
                // can still be closed); off -> every fold closes again (fewest options).
                if (advState >= 0 || on) foreach (FoldHeader f in folds) f.Open = on;
                advState = state;
            }
            StylePanel sp = stylePanel as StylePanel;
            if (sp != null) sp.Advanced = on;
        }

        // ---------------- pages & navigation ----------------

        private void AddPage(int index, Control content, bool scroll)
        {
            Page pg = new Page();
            pg.Id = UiPages.Ids[index];
            pg.Title = UiPages.Titles[index];
            pg.Host = new Panel();
            pg.Host.Dock = DockStyle.Fill;
            pg.Host.Visible = false;
            pg.Host.Padding = P(22, 12, 10, 0);
            pg.Host.BackColor = Theme.ColSurface;
            pg.Heading = new PageTitle(pg.Title, UiPages.Codes[index], k);
            pg.Heading.Font = Font;
            pg.Heading.Dock = DockStyle.Top;
            PageTitle heading = pg.Heading;
            FixUp(delegate { heading.Height = heading.GetPreferredSize(Size.Empty).Height; });
            if (scroll)
            {
                pg.Scroller = new Panel();
                pg.Scroller.Dock = DockStyle.Fill;
                pg.Scroller.AutoScroll = true;
                pg.Scroller.Padding = P(0, 10, 0, 12);
                content.Location = new Point(0, S(12));
                pg.Scroller.Controls.Add(content);
                pg.Content = content;
                pg.Host.Controls.Add(pg.Heading);
                pg.Host.Controls.Add(pg.Scroller);
                pg.Scroller.BringToFront(); // docked last -> fills below the heading
            }
            else if (index == 0)
            {
                // the dashboard brings its own title bar: no page heading above it
                content.Dock = DockStyle.Fill;
                pg.Host.Padding = P(12, 10, 10, 10);
                pg.Host.Controls.Add(content);
            }
            else
            {
                // a control that fills and scrolls by itself (外观 = StylePanel): heading + content, no outer scroller
                content.Dock = DockStyle.Fill;
                pg.Host.Padding = P(22, 12, 10, 8);
                pg.Host.Controls.Add(pg.Heading);
                pg.Host.Controls.Add(content);
                content.BringToFront();
            }
            pageHost.Controls.Add(pg.Host);

            pg.Nav = new NavItem((index + 1).ToString("00"), pg.Title, k);
            pg.Nav.Font = Font;
            pg.Nav.Dock = DockStyle.Fill;
            pg.Nav.Margin = new Padding(0);
            int idx = index;
            Tip(pg.Nav, "Ctrl+Tab 切换页面，↑ ↓ 选择");
            pg.Nav.Click += delegate { ShowPage(idx); };
            pg.Nav.Navigate += delegate(int d)
            {
                int n = pages.Count, to = ((idx + d) % n + n) % n;
                ShowPage(to);
                pages[to].Nav.Focus();
            };
            navBar.RowStyles.Add(new RowStyle(SizeType.Absolute, pg.Nav.Height));
            navBar.Controls.Add(pg.Nav, 0, index);
            pages.Add(pg);
        }

        private void BuildNavFooter()
        {
            int row = pages.Count;
            navBar.RowStyles.Add(new RowStyle(SizeType.Percent, 100F)); // spacer
            navBar.Controls.Add(Blank(), 0, row);

            btnTutorial = new GlowButton("", k);
            btnTutorial.Font = Font;
            btnTutorial.Dock = DockStyle.Fill;
            btnTutorial.Margin = P(14, 6, 14, 6);
            btnTutorial.Click += delegate { OpenTutorial(); };
            navBar.RowStyles.Add(new RowStyle(SizeType.Absolute, F(56)));
            navBar.Controls.Add(btnTutorial, 0, row + 1);
            navBar.RowCount = row + 2;
            navHost.ClientSizeChanged += delegate { FitNav(); };
            navHost.Resize += delegate { FitNav(); };
            RefreshTutorialButton();
        }

        /// <summary>
        /// Fits the navigation into its column: rows shrink from 36 to 26 px (100 %) on short windows; if even that does not
        /// fit, the navigation scrolls (navHost) instead of hiding the tutorial button.
        /// </summary>
        private void FitNav()
        {
            if (fittingNav || pages.Count == 0 || navBar.RowStyles.Count < pages.Count + 2) return;
            fittingNav = true;
            try
            {
                int pad = navBar.Padding.Vertical + S(4);
                int availH = Math.Max(0, navHost.Height);
                // the tutorial button gets shorter before the navigation has to scroll
                int tut = availH >= pages.Count * F(26) + F(56) + pad ? F(56) : F(44);
                if ((int)navBar.RowStyles[pages.Count + 1].Height != tut) navBar.RowStyles[pages.Count + 1].Height = tut;
                int h = Math.Max(F(26), Math.Min(F(40), (availH - pad - tut) / pages.Count));
                int needed = pages.Count * h + tut + pad;
                bool scroll = needed > availH;
                // width = the column minus the vertical scroll bar when one is needed, so no horizontal bar ever appears
                int w = Math.Max(0, navHost.Width - (scroll ? SystemInformation.VerticalScrollBarWidth : 0));
                navBar.SuspendLayout();
                for (int i = 0; i < pages.Count; i++)
                    if ((int)navBar.RowStyles[i].Height != h) navBar.RowStyles[i].Height = h;
                Size want = new Size(w, scroll ? needed : availH);
                if (navBar.Size != want) navBar.Size = want;
                navBar.ResumeLayout(true);
                navHost.HorizontalScroll.Value = 0;
            }
            finally { fittingNav = false; }
        }

        private void RefreshTutorialButton()
        {
            if (btnTutorial == null) return;
            bool first = !G.TutorialDone;
            btnTutorial.Text = first ? "▶  首次设置教程" : "设置教程";
            btnTutorial.Highlight = first;
            Tip(btnTutorial, first ? "一步一步带你设置好，随时可以退出" : "随时可以再看一遍");
        }

        private void ShowPage(int index)
        {
            if (index < 0 || index >= pages.Count) return;
            if (index == current) return;
            CommitEdits();
            CancelCapture();
            Page next = pages[index];
            next.Host.Visible = true;
            next.Host.BringToFront();
            if (current >= 0)
            {
                pages[current].Host.Visible = false;
                pages[current].Nav.Selected = false;
            }
            current = index;
            next.Nav.Selected = true;
            if (next.Heading.Parent != null) next.Heading.Restart();
            if (next.Id == "hand")
            {
                // the 自动 rows follow the normal hand, which other pages may have changed
                bool was = loading;
                loading = true;
                try { foreach (Action r in handRefreshers) r(); }
                finally { loading = was; }
                PaintHandRows();
            }
        }

        /// <summary>For TutorialForm: show a page by id or title, with fresh values.</summary>
        public void JumpToPage(string idOrTitle)
        {
            if (InvokeRequired) { try { BeginInvoke((Action<string>)JumpToPage, idOrTitle); } catch (Exception) { } return; }
            CommitEdits();
            RefreshValues();
            app.UpdateTray();
            app.Changed();
            int i = UiPages.IndexOf(idOrTitle);
            if (i < 0) return;
            if (!Visible) app.ShowSettings();
            if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
            ShowPage(i);
        }

        // ---------------- other workers' controls (DashboardPanel, StylePanel, TutorialForm) ----------------

        private Control Missing(string what)
        {
            Label l = Note(what + "没有加载成功，详细信息在 crash.log。", 460);
            return l;
        }

        /// <summary>
        /// 「首次设置教程」 (v4-requests/TUTORIAL.md): modal TutorialForm; ValuesChanged -> app.Changed() (overlay + save while the
        /// user tests in game); afterwards the pages re-read the profile and the button highlight follows G.TutorialDone.
        /// The tutorial's jumpToPage keys (首页 按键 常规 后坐力 移动 侧身 换手 跳跃 外观 指南 反馈) map through UiPages.IndexOf.
        /// </summary>
        private void OpenTutorial()
        {
            if (tutorial != null && !tutorial.IsDisposed) { tutorial.Activate(); return; }
            CommitEdits();
            CancelCapture();
            TutorialForm t = null;
            try { t = new TutorialForm(G, delegate(string page) { JumpToPage(page); }); }
            catch (Exception ex) { Program.Log("UI: TutorialForm: " + ex); t = null; }
            if (t == null)
            {
                Say("教程打不开，详细信息在 crash.log。");
                return;
            }
            try
            {
                tutorial = t;
                t.ValuesChanged += delegate { if (!IsDisposed) app.Changed(); };
                t.TopMost = TopMost;
                t.ShowDialog(this);
            }
            catch (Exception ex) { Program.Log("UI: tutorial: " + ex); }
            finally
            {
                tutorial = null;
                t.Dispose();
            }
            if (IsDisposed) return;
            RefreshValues();          // the tutorial edited the active profile
            PaintHandRows();
            RefreshTutorialButton();  // highlight off once G.TutorialDone
            app.UpdateTray();
            app.Changed();
        }

        // ---------------- key capture (single key, mouse button or Ctrl/Shift/Alt combo) ----------------

        private static int ModsOf(Keys keyData)
        {
            int m = 0;
            if ((keyData & Keys.Control) == Keys.Control) m |= KeyBindings.ModCtrl;
            if ((keyData & Keys.Shift) == Keys.Shift) m |= KeyBindings.ModShift;
            if ((keyData & Keys.Alt) == Keys.Alt) m |= KeyBindings.ModAlt;
            return m;
        }

        private KeyButton KeyBtn(int action)
        {
            KeyButton b = new KeyButton();
            b.Action = action;
            b.AutoSize = true;
            b.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            FixUp(delegate { b.MinimumSize = new Size(Math.Max(F(150), TextRenderer.MeasureText("鼠标侧键1（XButton1）", Font).Width + S(18)), Font.Height + S(10)); });
            b.Anchor = AnchorStyles.Left;
            b.Margin = P(3, 3, 8, 3);
            b.Click += delegate
            {
                if (suppressNextClick) { suppressNextClick = false; return; }
                if (capturing != null && capturing != b) CancelCapture();
                capturing = b;
                capture.Start();
                b.Text = capture.Shown;
                b.ForeColor = Theme.ColAccent;
            };
            b.MouseDown += delegate(object s, MouseEventArgs e)
            {
                if (capturing != b) return;
                int vk = 0;
                if (e.Button == MouseButtons.Left) vk = 1;
                else if (e.Button == MouseButtons.Right) vk = 2;
                else if (e.Button == MouseButtons.Middle) vk = 4;
                else if (e.Button == MouseButtons.XButton1) vk = 5;
                else if (e.Button == MouseButtons.XButton2) vk = 6;
                if (vk == 0) return;
                if (e.Button == MouseButtons.Left) suppressNextClick = true;
                if (capture.Mouse(vk, ModsOf(Control.ModifierKeys)) == KeyCapture.Result.Done) FinishCapture();
            };
            b.Leave += delegate { if (capturing == b) CancelCapture(); };
            refreshers.Add(delegate { if (capturing != b) b.Text = G.Keys.ComboOf(b.Action); });
            return b;
        }

        private void CancelCapture()
        {
            KeyButton b = capturing;
            capturing = null;
            if (b != null)
            {
                b.Text = G.Keys.ComboOf(b.Action);
                b.ForeColor = Theme.ColText;
            }
        }

        /// <summary>Applies capture.Vk / capture.Mods to the capturing button's action (asks first if another action has it).</summary>
        private void FinishCapture()
        {
            KeyButton b = capturing;
            capturing = null;
            if (b == null) return;
            b.ForeColor = Theme.ColText;
            int vk = capture.Vk, mods = capture.Mods;
            int other = KeyConflict.Find(G.Keys, vk, mods, b.Action);
            if (other >= 0)
            {
                bool yes = Ask(KeyConflict.Question(G.Keys, b.Action, vk, mods, other));
                suppressNextClick = false; // the button never sees the click that started this capture once a dialog was up
                if (!yes)
                {
                    b.Text = G.Keys.ComboOf(b.Action);
                    return;
                }
            }
            // 是 moves the key: the other action takes this action's old key (never two actions on one key)
            string done = KeyConflict.Apply(G.Keys, b.Action, vk, mods, other);
            RefreshValues(); // the other action's key button (and pages that show key names) follow
            app.UpdateTray();
            app.Changed();
            SetStatus(done, false);
        }

        private bool TryCaptureKey(Keys keyData)
        {
            if (capturing == null) return false;
            KeyCapture.Result r = capture.KeyDown((int)(keyData & Keys.KeyCode), ModsOf(keyData));
            if (r == KeyCapture.Result.Cancelled) CancelCapture();
            else if (r == KeyCapture.Result.Done) FinishCapture();
            else if (capturing != null) capturing.Text = capture.Shown;
            return true;
        }

        private const int WmKeyUp = 0x0101, WmSysKeyUp = 0x0105;

        /// <summary>Key up while capturing: a modifier pressed and released on its own binds that modifier.</summary>
        protected override bool ProcessKeyPreview(ref Message m)
        {
            if (capturing != null && (m.Msg == WmKeyUp || m.Msg == WmSysKeyUp))
            {
                int vk = (int)(m.WParam.ToInt64() & 0xFF);
                KeyCapture.Result r = capture.KeyUp(vk, KeyBindings.ModsDown(Native.IsDown));
                if (r == KeyCapture.Result.Done) { FinishCapture(); return true; }
                if (r == KeyCapture.Result.Waiting) { capturing.Text = capture.Shown; return true; }
            }
            return base.ProcessKeyPreview(ref m);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (TryCaptureKey(keyData)) return true;
            Keys code = keyData & Keys.KeyCode;
            bool ctrl = (keyData & Keys.Control) == Keys.Control, shift = (keyData & Keys.Shift) == Keys.Shift;
            if (ctrl && (code == Keys.Tab || code == Keys.PageDown || code == Keys.PageUp))
            {
                bool back = code == Keys.PageUp || (code == Keys.Tab && shift);
                int n = pages.Count;
                ShowPage(((current < 0 ? 0 : current) + (back ? n - 1 : 1)) % n);
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (TryCaptureKey(e.KeyData)) { e.Handled = true; e.SuppressKeyPress = true; return; }
            base.OnKeyDown(e);
        }

        // ---------------- top bar (one line) ----------------

        private void BuildTopBar()
        {
            topBar = new TableLayoutPanel();
            topBar.Dock = DockStyle.Fill;
            topBar.AutoSize = true;
            topBar.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            topBar.Margin = new Padding(0);
            topBar.Padding = P(12, 8, 12, 8);
            topBar.RowCount = 1;
            topBar.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            topBar.ColumnCount = 8;
            for (int i = 0; i < 5; i++) topBar.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            topBar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F)); // spacer
            topBar.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            topBar.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));

            Label lp = Lbl("配置");
            Tip(lp, "每把枪可以存一套配置（一般一套就够）");
            cbProfile = new ComboBox();
            cbProfile.DropDownStyle = ComboBoxStyle.DropDownList;
            FixUp(delegate { cbProfile.Width = F(190); cbProfile.DropDownWidth = F(280); });
            cbProfile.Anchor = AnchorStyles.Left;
            cbProfile.Margin = P(0, 3, 3, 3);
            WheelScrollsPage(cbProfile); // a stray wheel never switches the profile
            cbProfile.SelectedIndexChanged += delegate
            {
                if (loading || cbProfile.SelectedItem == null) return;
                CommitEdits(); // a typed value belongs to the profile it was typed into
                G.ActiveProfile = (string)cbProfile.SelectedItem;
                RefreshAll();
                app.Changed();
            };

            profileMenu = new ContextMenuStrip();
            AddItem(profileMenu, "新建…", delegate { NewProfile(); });
            AddItem(profileMenu, "复制…", delegate { CopyProfile(); });
            AddItem(profileMenu, "重命名…", delegate { RenameProfile(); });
            AddItem(profileMenu, "删除", delegate { DeleteProfile(); });
            profileMenu.Items.Add(new ToolStripSeparator());
            AddItem(profileMenu, "导入…", delegate { ImportProfiles(); });
            AddItem(profileMenu, "导入旧版设置…", delegate { ImportLegacy(); });
            AddItem(profileMenu, "导出当前配置…", delegate { ExportProfile(); });
            StyleMenu(profileMenu);
            Button manage = null;
            manage = Btn("管理 ▾", delegate { profileMenu.Show(manage, new Point(0, manage.Height)); });
            Tip(manage, "新建 / 复制 / 重命名 / 删除 / 导入 / 导入旧版设置 / 导出");

            Button save = Btn("存为我的默认", delegate { SaveAsDefault(); });
            Tip(save, "把当前配置现在的数值存下来，以后点「恢复 ▾」就能回到这里");
            Button restore = null;
            restore = Btn("恢复 ▾", delegate { ShowRestoreMenu(restore); });
            Tip(restore, "恢复到你存的默认，或恢复到 Leo 推荐的数值");

            lblSave = new Label();
            lblSave.AutoSize = false;          // fills the spacer column: a long message is cut with … (full text in the tooltip)
            lblSave.Dock = DockStyle.Fill;
            lblSave.TextAlign = ContentAlignment.MiddleRight;
            lblSave.AutoEllipsis = true;
            lblSave.Margin = P(12, 3, 3, 3);
            lblSave.ForeColor = SystemColors.GrayText;

            chkAdvanced = new CheckBox();
            chkAdvanced.Text = "高级设置";
            chkAdvanced.AutoSize = true;
            chkAdvanced.Anchor = AnchorStyles.Right;
            chkAdvanced.Margin = P(12, 3, 3, 3);
            Tip(chkAdvanced, "打开后每一页会多出更细的选项（曲线、渐变、样式细调等）。一般不用开");
            chkAdvanced.CheckedChanged += delegate
            {
                if (loading) return;
                CommitEdits();
                UiPrefs.SetAdvanced(G, chkAdvanced.Checked);
                RefreshValues();
                if (UiPrefs.InSettings) app.Changed();
                SetStatus(chkAdvanced.Checked ? "已显示高级设置" : "已隐藏高级设置（数值不变）", false);
            };

            chkEnabled = new CheckBox();
            chkEnabled.Text = "启用准星";
            chkEnabled.AutoSize = true;
            chkEnabled.Anchor = AnchorStyles.Right;
            chkEnabled.Margin = P(12, 3, 3, 3);
            chkEnabled.CheckedChanged += delegate
            {
                if (loading) return;
                app.SetEnabled(chkEnabled.Checked);
            };

            topBar.Controls.Add(lp, 0, 0);
            topBar.Controls.Add(cbProfile, 1, 0);
            topBar.Controls.Add(manage, 2, 0);
            topBar.Controls.Add(save, 3, 0);
            topBar.Controls.Add(restore, 4, 0);
            topBar.Controls.Add(lblSave, 5, 0);
            topBar.Controls.Add(chkAdvanced, 6, 0);
            topBar.Controls.Add(chkEnabled, 7, 0);
            topBar.RowStyles.Add(new RowStyle(SizeType.AutoSize)); // row 1: used only by the two-line layout
            root.Controls.Add(topBar, 0, 1);
        }

        /// <summary>Dark drop-down menus to match the window.</summary>
        private void StyleMenu(ContextMenuStrip m)
        {
            try
            {
                m.Font = Font; // readable size (11 pt x uiScale), swapped again by ApplyUiScale
                m.RenderMode = ToolStripRenderMode.System;
                m.BackColor = Theme.ColInput;
                m.ForeColor = Theme.ColText;
                m.ShowImageMargin = false;
            }
            catch (Exception) { }
        }

        private static void AddItem(ContextMenuStrip menu, string text, EventHandler onClick)
        {
            ToolStripMenuItem it = new ToolStripMenuItem(text);
            it.Click += onClick;
            menu.Items.Add(it);
        }

        private void RefreshProfileList()
        {
            cbProfile.Items.Clear();
            foreach (Profile p in G.Profiles) cbProfile.Items.Add(p.Name);
            cbProfile.SelectedItem = Cur.Name;
        }

        public void RefreshEnabled()
        {
            bool was = loading;
            loading = true;
            chkEnabled.Checked = G.Enabled;
            loading = was;
        }

        private void NewProfile()
        {
            string n = NameDialog.Ask(this, "新建配置", "");
            if (n == null) return;
            Profile p = Profile.CreateBlank(G.UniqueName(n, null));
            G.Profiles.Add(p);
            G.ActiveProfile = p.Name;
            RefreshAll();
            app.Changed();
        }

        private void CopyProfile()
        {
            string n = NameDialog.Ask(this, "复制配置", Cur.Name);
            if (n == null) return;
            Profile p = Cur.Clone(); // keeps the saved-default snapshot
            p.Name = G.UniqueName(n, null);
            G.Profiles.Add(p);
            G.ActiveProfile = p.Name;
            RefreshAll();
            app.Changed();
        }

        private void RenameProfile()
        {
            Profile cur = Cur;
            string n = NameDialog.Ask(this, "重命名配置", cur.Name);
            if (n == null) return;
            cur.Name = G.UniqueName(n, cur);
            G.ActiveProfile = cur.Name;
            RefreshAll();
            app.Changed();
        }

        private void DeleteProfile()
        {
            if (G.Profiles.Count <= 1)
            {
                Say("至少要保留一个配置。");
                return;
            }
            Profile cur = Cur;
            if (!Ask("确定删除配置「" + cur.Name + "」？")) return;
            int idx = G.Profiles.IndexOf(cur);
            G.Profiles.Remove(cur);
            G.ActiveProfile = G.Profiles[Math.Max(0, Math.Min(idx, G.Profiles.Count - 1))].Name;
            RefreshAll();
            app.Changed();
        }

        private static string SafeFileName(string name)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char c in name) sb.Append(Array.IndexOf(Path.GetInvalidFileNameChars(), c) >= 0 ? '_' : c);
            string r = sb.ToString().Trim();
            return r.Length == 0 ? "配置" : r;
        }

        private void ExportProfile()
        {
            using (SaveFileDialog d = new SaveFileDialog())
            {
                d.Title = "导出配置";
                d.Filter = "准星配置 (*.json)|*.json";
                d.FileName = SafeFileName(Cur.Name) + ".json";
                d.OverwritePrompt = true;
                if (d.ShowDialog(this) != DialogResult.OK) return;
                try
                {
                    File.WriteAllText(d.FileName, SettingsIO.ExportProfile(Cur), new UTF8Encoding(false));
                    SetStatus("已导出：" + Path.GetFileName(d.FileName), false);
                }
                catch (Exception ex)
                {
                    Say("导出失败：" + ex.Message);
                }
            }
        }

        private void ImportProfiles()
        {
            using (OpenFileDialog d = new OpenFileDialog())
            {
                d.Title = "导入配置（单个配置文件或整个 settings.json）";
                d.Filter = "准星配置 (*.json)|*.json|所有文件 (*.*)|*.*";
                if (d.ShowDialog(this) != DialogResult.OK) return;
                string text, err;
                List<Profile> list;
                try { text = File.ReadAllText(d.FileName, Encoding.UTF8); }
                catch (Exception ex) { Say("读取失败：" + ex.Message); return; }
                if (!SettingsIO.TryParseImport(text, out list, out err))
                {
                    Say("这个文件不能导入：" + err);
                    return;
                }
                G.AddImported(list);
                RefreshAll();
                app.Changed();
                SetStatus("已导入 " + list.Count + " 个配置", false);
            }
        }

        /// <summary>First start (no settings.json before): 「用过旧版吗？」 welcome; 「选择旧的 settings.json」 opens the import.</summary>
        public void OfferLegacyImport()
        {
            if (IsDisposed) return;
            if (!Visible) app.ShowSettings();
            if (ThemedDialog.Show(this, "欢迎使用 v4.0！\n\n用过旧版吗？可以导入你以前调好的设置（所有配置、按键和常规设置）。「Leo默认」会保留。",
                    "选择旧的 settings.json", "跳过"))
                ImportLegacy();
        }

        /// <summary>
        /// 「导入旧版设置…」: pick an old settings.json (or the old app folder); every old profile, the keys and the global
        /// settings come over (SettingsIO.ImportLegacy: tolerant load + migration, current file backed up first).
        /// </summary>
        private void ImportLegacy()
        {
            CommitEdits();
            CancelCapture();
            string picked = null;
            using (OpenFileDialog d = new OpenFileDialog())
            {
                d.Title = "选择旧版的 settings.json（在旧版的程序文件夹里）";
                d.Filter = "旧版设置 settings.json|settings.json;*.json|所有文件 (*.*)|*.*";
                d.CheckFileExists = true;
                if (d.ShowDialog(this) == DialogResult.OK) picked = d.FileName;
            }
            if (picked == null)
            {
                // the user may want to pick the whole old folder instead
                using (FolderBrowserDialog f = new FolderBrowserDialog())
                {
                    f.Description = "或者选旧版的整个文件夹（里面有 settings.json）";
                    f.ShowNewFolderButton = false;
                    if (!Ask("没选文件。要改成选旧版的整个文件夹吗？")) return;
                    if (f.ShowDialog(this) != DialogResult.OK) return;
                    picked = f.SelectedPath;
                }
            }
            int n; string err;
            GlobalSettings merged = SettingsIO.ImportLegacy(G, picked, app.SettingsPath, out n, out err);
            if (merged == null) { Say(err ?? "导入失败。"); return; }
            G.CopyFrom(merged); // the same object stays (dashboard, 外观 and the overlay keep their reference)
            RefreshAll();
            PaintHandRows();
            app.UpdateTray();
            app.Changed();
            app.SaveNow();
            SetStatus("已导入 " + n + " 套配置", false);
            Say("已导入 " + n + " 套配置，现在用的是「" + G.ActiveProfile + "」。\n原来的设置已备份在设置文件夹（settings.before-import-….json）。");
        }

        private void SaveAsDefault()
        {
            Profile cur = Cur;
            if (!Ask("把配置“" + cur.Name + "”现在的全部数值存成你的默认？以后点「恢复 ▾」就能回到这里（会覆盖上一次存的）。")) return;
            cur.SaveAsDefault(DateTime.Now.ToString("yyyy-MM-dd HH:mm", System.Globalization.CultureInfo.InvariantCulture));
            app.Publish();
            app.SaveNow(); // at once, not debounced
            SetStatus("已存为我的默认：" + cur.Name + "（" + cur.SavedDefaultAt + "）", false);
        }

        private void ShowRestoreMenu(Button anchor)
        {
            Profile cur = Cur;
            if (restoreMenu == null)
            {
                restoreMenu = new ContextMenuStrip();
                restoreSaved = new ToolStripMenuItem();
                restoreSaved.Click += delegate { RestoreSaved(); };
                ToolStripMenuItem builtIn = new ToolStripMenuItem("恢复到 Leo 推荐");
                builtIn.Click += delegate { RestoreBuiltIn(); };
                restoreMenu.Items.Add(restoreSaved);
                restoreMenu.Items.Add(builtIn);
                StyleMenu(restoreMenu);
            }
            bool has = cur.SavedDefault != null;
            restoreSaved.Text = has ? "恢复到我存的（" + cur.SavedDefaultAt + "）" : "恢复到我存的（还没存过）";
            restoreSaved.Enabled = has;
            restoreMenu.Show(anchor, new Point(0, anchor.Height));
        }

        private void RestoreSaved()
        {
            Profile cur = Cur;
            if (cur.SavedDefault == null) return;
            if (!Ask("把配置“" + cur.Name + "”的数值恢复成你存的默认（" + cur.SavedDefaultAt + "）？名字、按键和全局设置不变。")) return;
            G.RestoreSaved(cur);
            RefreshAll();
            app.Changed();
            SetStatus("已恢复到你存的：" + cur.Name, false);
        }

        /// <summary>Values = Profile.CreateLeoDefault; the name, the 「存为我的默认」 snapshot and 外观 (Style / Boost / 换手颜色) are kept, globals untouched.</summary>
        private void RestoreBuiltIn()
        {
            Profile cur = Cur;
            if (!Ask("把配置“" + cur.Name + "”的数值恢复成 Leo 推荐的数值？名字、按键、外观和全局设置不变。")) return;
            int idx = G.Profiles.IndexOf(cur);
            Profile n = Profile.CreateLeoDefault(cur.Name).CloneValues();
            n.Name = cur.Name;
            n.SavedDefault = cur.SavedDefault == null ? null : cur.SavedDefault.CloneValues();
            n.SavedDefaultAt = cur.SavedDefaultAt;
            // 外观 is the player's own choice: the crosshair look, 强化准星 and 换手颜色 stay as they are
            n.Style = cur.Style == null ? null : cur.Style.Clone();
            n.Boost = cur.Boost == null ? null : cur.Boost.Clone();
            n.HandColorOn = cur.HandColorOn;
            n.HandColor = cur.HandColor;
            n.HandColor2 = cur.HandColor2;
            n.Validate();
            if (idx >= 0) G.Profiles[idx] = n;
            G.ActiveProfile = n.Name;
            RefreshAll();
            app.Changed();
            SetStatus("已恢复到 Leo 推荐：" + cur.Name, false);
        }

        // ---------------- pages ----------------

        /// <summary>首页: the live dashboard (DashboardPanel, another worker's control) on its own MotionEngine.</summary>
        private Control BuildDashboard()
        {
            try { dashboard = new DashboardPanel(dashEngine, G); }
            catch (Exception ex) { Program.Log("UI: DashboardPanel: " + ex); dashboard = null; }
            return dashboard ?? Missing("首页面板");
        }

        /// <summary>侧身方式 (按住 / 点一下切换); shown on 按键 and 侧身 -- both stay in sync through RefreshValues.</summary>
        private ComboBox LeanModeChoice()
        {
            return Choice(new string[] { "按住", "点一下切换" }, new string[] { "hold", "toggle" },
                delegate { return G.LeanMode; }, delegate(string v) { G.LeanMode = v; RefreshValues(); });
        }

        /// <summary>「冲刺取消侧身」: only visible in 点一下切换 lean mode (SPEC v4).</summary>
        private CheckBox LeanSprintCheck()
        {
            CheckBox c = Check("冲刺（Shift+W）取消侧身", delegate { return G.LeanCancelSprint; },
                delegate(bool v) { G.LeanCancelSprint = v; RefreshValues(); });
            Tip(c, "侧身方式为「点一下切换」时：按住前进再按 Shift 冲刺，侧身自动回正。只按 Shift（屏息）不算");
            refreshers.Add(delegate { c.Visible = G.LeanMode == "toggle"; });
            return c;
        }

        // ---------------- refresh / sizing / closing ----------------

        /// <summary>Re-reads every field from the model, without rebuilding the profile list.</summary>
        public void RefreshValues()
        {
            bool was = loading;
            loading = true;
            try
            {
                foreach (Action r in refreshers) r();
                StylePanel sp = stylePanel as StylePanel;
                if (sp != null) sp.RefreshValues();
                RefreshAdvanced();
            }
            finally { loading = was; }
            RefreshTutorialButton();
        }

        public void RefreshAll()
        {
            bool was = loading;
            loading = true;
            try
            {
                RefreshProfileList();
                foreach (Action r in refreshers) r();
                StylePanel sp = stylePanel as StylePanel;
                if (sp != null) sp.RefreshValues();
                chkEnabled.Checked = G.Enabled;
                if (chkAdvanced != null) chkAdvanced.Checked = Advanced;
                TopMost = G.SettingsTopMost;
                RefreshAdvanced();
            }
            finally { loading = was; }
            PaintHandRows();
            RefreshTutorialButton();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            // Content-driven size: the widest / tallest scrolling page, the top bar on one line; at least room for the
            // dashboard; capped to the work area.
            int pw = 0, ph = 0;
            foreach (Page pg in pages)
            {
                if (pg.Content == null) continue;
                Size ps = pg.Content.GetPreferredSize(Size.Empty);
                pw = Math.Max(pw, ps.Width + pg.Content.Left);
                ph = Math.Max(ph, ps.Height + pg.Content.Top);
            }
            int scroll = SystemInformation.VerticalScrollBarWidth;
            Page any = pages[1];
            int pagePadW = any.Host.Padding.Horizontal + any.Scroller.Padding.Horizontal + scroll + S(8);
            int pagePadH = any.Host.Padding.Vertical + any.Scroller.Padding.Vertical + any.Heading.Height + S(8);
            int barsW = topBar.GetPreferredSize(Size.Empty).Width;
            int width = Math.Max(Math.Max(barsW, S(188) + 1 + pw + pagePadW), S(1100));
            int fixedH = header.Height + topBar.GetPreferredSize(new Size(width, 0)).Height;
            int navH = pages.Count * S(36) + (int)navBar.RowStyles[pages.Count + 1].Height + navBar.Padding.Vertical + S(20);
            int height = Math.Max(Math.Max(fixedH + ph + pagePadH, fixedH + navH), S(740));
            Rectangle wa = Screen.FromControl(this).WorkingArea;
            Size frame = Size - ClientSize;
            int maxW = wa.Width - frame.Width, maxH = wa.Height - frame.Height;
            ClientSize = new Size(Math.Min(width, maxW), Math.Min(height, maxH));
            // Never narrower than the top bar (no clipped buttons) and never shorter than the navigation; pages scroll.
            // SPEC v4: minimum window 960 x 640 logical (capped to the screen); below that everything scrolls, nothing is cut.
            Size minClient = new Size(Math.Min(Math.Max(barsW + S(8), S(960)), maxW), Math.Min(S(640), maxH));
            MinimumSize = minClient + frame;
            CenterToScreen();
            UpdateUiScale(); // a window that opens big (maximised / big screen) starts with bigger text
        }

        protected override void OnVisibleChanged(EventArgs e)
        {
            base.OnVisibleChanged(e);
            if (!Visible) { CommitEdits(); CancelCapture(); }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (!AllowClose && e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                CommitEdits();
                CancelCapture();
                Hide();
                app.OnFormHidden();
                return;
            }
            if (!AllowClose)
            {
                // Windows shutdown, task manager, etc.: clean up without re-closing this form.
                AllowClose = true;
                app.ExitApp(false);
            }
            base.OnFormClosing(e);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                saveFlash.Dispose();
                scaleTimer.Dispose();
                tips.Dispose();
                if (restoreMenu != null) restoreMenu.Dispose();
                if (profileMenu != null) profileMenu.Dispose();
                if (windowMenu != null) windowMenu.Dispose();
                if (tutorial != null && !tutorial.IsDisposed) tutorial.Dispose();
                foreach (Page pg in pages) if (pg.Heading.Parent == null) pg.Heading.Dispose(); // the dashboard's unused heading
            }
            base.Dispose(disposing);
            if (disposing) { monoFont.Dispose(); if (guideBold != null) guideBold.Dispose(); } // after the controls that use them
        }
    }

    /// <summary>
    /// v4.0 question / message box in the settings window's look: the owner's font (11 pt x uiScale), dark theme,
    /// text wrapped at about 26 characters, 「是」 / 「否」 or one 「知道了」. Enter = 是 / 知道了, Esc = 否 / close.
    /// </summary>
    internal sealed class ThemedDialog : Form
    {
        private ThemedDialog(Form owner, string message, bool question) : this(owner, message, question, null, null) { }

        private ThemedDialog(Form owner, string message, bool question, string yesText, string noText)
        {
            AutoScaleMode = AutoScaleMode.None;
            Font font = owner != null ? owner.Font : Theme.Ui(11f);
            Font = font;
            Text = owner != null ? owner.Text : Program.ProductName;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false; MinimizeBox = false; ShowInTaskbar = false;
            StartPosition = owner != null ? FormStartPosition.CenterParent : FormStartPosition.CenterScreen;
            TopMost = owner != null && owner.TopMost;
            AutoSize = true;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            int u = Math.Max(8, font.Height); // one text line: every spacing follows the text size

            TableLayoutPanel t = new TableLayoutPanel();
            t.ColumnCount = 1;
            t.AutoSize = true;
            t.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            t.Padding = new Padding(u, u, u, u * 2 / 3);
            Label l = new Label();
            l.Text = message ?? "";
            l.AutoSize = true;
            l.MaximumSize = new Size(u * 26, 0);
            l.Margin = new Padding(0, 0, 0, u);
            t.Controls.Add(l);
            FlowLayoutPanel b = new FlowLayoutPanel();
            b.AutoSize = true;
            b.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            b.FlowDirection = FlowDirection.RightToLeft;
            b.WrapContents = false;
            b.Anchor = AnchorStyles.Right;
            b.Margin = new Padding(0);
            Button ok = new Button();
            ok.Text = yesText ?? (question ? "是" : "知道了");
            ok.DialogResult = DialogResult.Yes;
            ok.AutoSize = true;
            ok.MinimumSize = new Size(u * 5, u + u / 2);
            ok.Tag = "theme:accent";
            b.Controls.Add(ok);
            Button no = null;
            if (question)
            {
                no = new Button();
                no.Text = noText ?? "否";
                no.DialogResult = DialogResult.No;
                no.AutoSize = true;
                no.MinimumSize = ok.MinimumSize;
                b.Controls.Add(no);
            }
            t.Controls.Add(b);
            Controls.Add(t);
            AcceptButton = ok;
            CancelButton = no ?? ok;
            Theme.Apply(this);
        }

        /// <summary>Question with own button texts (e.g. 「选择旧的 settings.json」 / 「跳过」); true = the first button.</summary>
        public static bool Show(Form owner, string message, string yesText, string noText)
        {
            try
            {
                using (ThemedDialog d = new ThemedDialog(owner, message, true, yesText, noText))
                    return d.ShowDialog(owner) == DialogResult.Yes;
            }
            catch (Exception ex) { Program.Log("UI: dialog: " + ex); return false; }
        }

        /// <summary>question: true = 是 / 否 (returns true for 是); false = one 「知道了」 button (returns true).</summary>
        public static bool Show(Form owner, string message, bool question)
        {
            try
            {
                using (ThemedDialog d = new ThemedDialog(owner, message, question))
                    return d.ShowDialog(owner) == DialogResult.Yes;
            }
            catch (Exception ex)
            {
                Program.Log("UI: dialog: " + ex);
                return MessageBox.Show(owner, message, owner != null ? owner.Text : Program.ProductName,
                    question ? MessageBoxButtons.YesNo : MessageBoxButtons.OK) == (question ? DialogResult.Yes : DialogResult.OK);
            }
        }
    }

    /// <summary>Profile name dialog (新建 / 复制 / 重命名), built like ThemedDialog: owner font, spacing from the text
    /// height, framed text box, 确定 (accent) / 取消 on the right.</summary>
    internal sealed class NameDialog : Form
    {
        private readonly TextBox box;

        private NameDialog(string title, string initial, Font font, bool topMost)
        {
            AutoScaleMode = AutoScaleMode.None;
            Font = font;
            Text = title;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false; MinimizeBox = false; ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            AutoSize = true;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            TopMost = topMost;
            int u = Math.Max(8, font.Height);

            TableLayoutPanel t = new TableLayoutPanel();
            t.ColumnCount = 1; t.AutoSize = true; t.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            t.Padding = new Padding(u, u, u, u * 2 / 3);
            Label l = new Label(); l.Text = "名字："; l.AutoSize = true; l.Margin = new Padding(0, 0, 0, u / 4);
            t.Controls.Add(l);
            Label hint = new Label(); hint.Text = "给这套偏移起个名字，例如 M4 / AK"; hint.AutoSize = true;
            hint.ForeColor = SystemColors.GrayText; // Theme maps it to the readable muted colour
            hint.Margin = new Padding(0, 0, 0, u / 2);
            t.Controls.Add(hint);
            box = new TextBox();
            box.Width = u * 20;
            box.BorderStyle = BorderStyle.None;
            box.Margin = new Padding(0);
            box.Text = initial ?? "";
            Panel frame = new Panel(); // 1 px border frame: the box stays visible on the dark background
            frame.Padding = new Padding(1);
            frame.Margin = new Padding(0, 0, 0, u);
            frame.BackColor = Theme.ColBorder;
            frame.Tag = "theme:keep-frame";
            frame.Size = new Size(box.Width + 2, box.PreferredHeight + 2);
            box.Dock = DockStyle.Fill;
            frame.Controls.Add(box);
            t.Controls.Add(frame);
            FlowLayoutPanel b = new FlowLayoutPanel();
            b.AutoSize = true; b.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            b.FlowDirection = FlowDirection.RightToLeft; b.WrapContents = false;
            b.Anchor = AnchorStyles.Right; b.Margin = new Padding(0);
            Button ok = new Button(); ok.Text = "确定"; ok.DialogResult = DialogResult.OK; ok.AutoSize = true;
            ok.MinimumSize = new Size(u * 5, u + u / 2); ok.Tag = "theme:accent";
            Button cancel = new Button(); cancel.Text = "取消"; cancel.DialogResult = DialogResult.Cancel; cancel.AutoSize = true;
            cancel.MinimumSize = ok.MinimumSize;
            b.Controls.Add(ok); b.Controls.Add(cancel);
            t.Controls.Add(b);
            Controls.Add(t);
            AcceptButton = ok; CancelButton = cancel;
            Theme.Apply(this);
            box.BorderStyle = BorderStyle.None; // the frame panel draws the border
            box.BackColor = Theme.ColInput; box.ForeColor = Theme.ColText;
        }

        /// <summary>Returns the trimmed name, or null if cancelled/empty. Uniqueness is applied by the caller.</summary>
        public static string Ask(Form owner, string title, string initial)
        {
            using (NameDialog d = new NameDialog(title, initial, owner.Font, owner.TopMost))
            {
                if (d.ShowDialog(owner) != DialogResult.OK) return null;
                string n = (d.box.Text ?? "").Trim();
                return n.Length == 0 ? null : n;
            }
        }
    }
#endif
}
