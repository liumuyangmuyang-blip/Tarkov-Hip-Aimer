﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

// 侧身 + 换手 pages (PAGE-C). Part of the settings window: partial class SettingsForm (shell, shared helpers, 高级设置 switch: SettingsForm.cs).
// Page rule: use the shell helpers (Grid / Line / Stack / Row / AdvRow / AdvOnly / Lbl / Note / Unit / Num / Choice / Check /
// Btn / Group / Fold / FixUp / F / S / P / Tip / EnableWhen) and read `Advanced`; never change another page's file.

#if !UI_PURE_CHECK
namespace TarkovCrosshair
{
    internal sealed partial class SettingsForm
    {
        /// <summary>「去「按键」页改 →」: jumps to the 按键 page (key bindings + 侧身方式 / 换手方式 live there).</summary>
        private Button KeysPageLink(string text)
        {
            Button b = Btn(text, delegate
            {
                int i = Array.IndexOf(UiPages.Ids, "keys");
                if (i >= 0) ShowPage(i);
            });
            return b;
        }

        /// <summary>A label whose text (and colour) a refresher rewrites; starts in the accent colour.</summary>
        private Label StatusLbl()
        {
            Label l = Lbl("");
            l.ForeColor = Theme.ColAccent;
            return l;
        }

        // ---------------- 侧身 page ----------------

        private Control BuildLean()
        {
            // --- 侧身方式: read-only summary (the setting itself is on the 按键 page, one place to change it)
            Label mode = StatusLbl();
            Label sprint = Lbl("");
            refreshers.Add(delegate
            {
                bool toggle = G.LeanMode == "toggle";
                mode.Text = toggle ? "点一下切换（按一下侧身，再按一下回正）" : "按住（按住侧身，松开回正）";
                sprint.Text = "冲刺（Shift+W）取消侧身：" + (G.LeanCancelSprint ? "开" : "关");
                sprint.Visible = toggle;
            });
            TableLayoutPanel m = Grid(2);
            Row(m, "侧身方式", mode);
            Row(m, Blank(), sprint);
            TableLayoutPanel modeBox = Grid(1);
            modeBox.Controls.Add(m);
            modeBox.Controls.Add(Note("要和游戏里的侧身方式一样。侧身方式和侧身按键都在「按键」页改。", 520));
            modeBox.Controls.Add(KeysPageLink("去「按键」页改 →"));
            Section gm = Group("侧身方式", modeBox);

            // --- 侧身偏移
            TableLayoutPanel g = Grid(4);
            g.Controls.Add(Blank());
            g.Controls.Add(Lbl("X（+ 往右）"));
            g.Controls.Add(Lbl("Y（+ 往上）"));
            g.Controls.Add(Blank());
            Label lq = Lbl("左侧身"), le = Lbl("右侧身");
            refreshers.Add(delegate
            {
                lq.Text = "左侧身（" + G.Keys.ComboOf(KeyBindings.ActionLeanLeft) + "）";
                le.Text = "右侧身（" + G.Keys.ComboOf(KeyBindings.ActionLeanRight) + "）";
            });
            Row(g, lq,
                Num(-500, 500, 1, 0, delegate { return Cur.LeanQX; }, delegate(double v) { Cur.LeanQX = v; }),
                Num(-500, 500, 1, 0, delegate { return Cur.LeanQY; }, delegate(double v) { Cur.LeanQY = v; }), Unit("px"));
            Row(g, le,
                Num(-500, 500, 1, 0, delegate { return Cur.LeanEX; }, delegate(double v) { Cur.LeanEX = v; }),
                Num(-500, 500, 1, 0, delegate { return Cur.LeanEY; }, delegate(double v) { Cur.LeanEY = v; }), Unit("px"));
            AdvRow(g, "过渡时间", Num(0, 2000, 10, 0, delegate { return Cur.LeanMs; }, delegate(double v) { Cur.LeanMs = v; }), Unit("ms"), Blank());
            TableLayoutPanel box = Grid(1);
            box.Controls.Add(g);
            box.Controls.Add(Note("怎么调：站着不动，侧身开枪，把偏移调到准星差不多盖住弹孔就行。", 520));
            box.Controls.Add(Note("侧身时再移动：侧身偏移和移动偏移直接相加，不用另外调。", 520));
            Section gb = Group("侧身偏移", box);
            return Stack(gb, gm);
        }

        // ---------------- 换手 page (v3.1 换手自定义) ----------------

        /// <summary>Re-read the 换手 boxes (the 自动 rows follow the normal hand, which other pages may have changed).</summary>
        private readonly List<Action> handRefreshers = new List<Action>();
        /// <summary>Repaint the 换手 rows: 正常手 column, grey = 自动, 「恢复自动」 on custom rows.</summary>
        private readonly List<Action> handPainters = new List<Action>();

        private void PaintHandRows() { foreach (Action a in handPainters) a(); }

        private Control BuildHand()
        {
            // --- 换手键 summary (key, 换手方式 and 换手检测 are on the 按键 page)
            Label state = StatusLbl();
            refreshers.Add(delegate
            {
                if (!G.HandEnabled)
                {
                    state.Text = "换手检测已关：下面的数现在不会用到。";
                    state.ForeColor = Theme.ColWarn;
                }
                else
                {
                    state.Text = G.Keys.ComboOf(KeyBindings.ActionHandSwitch) + " · " + (G.HandMode == "hold" ? "按住" : "点一下切换");
                    state.ForeColor = Theme.ColAccent;
                }
            });
            TableLayoutPanel k1 = Grid(2);
            Row(k1, "换手键", state);
            TableLayoutPanel keyBox = Grid(1);
            keyBox.Controls.Add(k1);
            keyBox.Controls.Add(Note("要和游戏里的换手方式一样。程序只能按按键判断你用哪只手，对不上时按两下开关准星键（关再开）回到正常手。", 520));
            keyBox.Controls.Add(KeysPageLink("去「按键」页改 →"));
            Section gk = Group("换手键", keyBox);

            // --- 换手后的偏移
            TableLayoutPanel g = Grid(5);
            g.Controls.Add(Blank());
            g.Controls.Add(Lbl("正常手 X / Y"));
            g.Controls.Add(Lbl("换手后 X"));
            g.Controls.Add(Lbl("换手后 Y"));
            g.Controls.Add(Blank());
            for (int i = 0; i < Profile.HandItemCount; i++) if (i != Profile.HandStand) AddHandRow(g, i); // v3.4: 站着偏移 removed
            Button all = Btn("全部恢复自动", delegate
            {
                if (Cur.AnyHandCustom() && !Ask("换手的所有格子都恢复成自动（正常手左右镜像）？")) return;
                Cur.AllHandAuto();
                RefreshValues();
                PaintHandRows();
                app.Changed();
            });
            TableLayoutPanel box = Grid(1);
            box.Controls.Add(Note("灰色＝自动：用正常手的数左右镜像（X 取反，A↔D、Q↔E 对调）。", 560));
            box.Controls.Add(g);
            box.Controls.Add(all);
            box.Controls.Add(Note("换手不是绝对镜像，换手后偏移会有点变化。换手后把 W S A D 和侧身都实测一遍，对不上就直接改格子（改过的变白）；点「恢复自动」回到镜像。", 560));
            Section gb = Group("换手后的偏移（px）", box);

            Label hsMs = Lbl("换手过渡时间");
            Tip(hsMs, "跟着当前配置存");
            TableLayoutPanel t = Grid(3);
            Row(t, hsMs, Num(0, 2000, 10, 0, delegate { return Cur.HandSwitchMs; }, delegate(double v) { Cur.HandSwitchMs = v; }), Unit("ms"));
            Section gt = Group("换手过渡", t);
            AdvOnly(gt);
            return Stack(gb, gk, gt);
        }

        private void AddHandRow(TableLayoutPanel g, int item)
        {
            bool hasY = item != Profile.HandDrift;
            double lim = item == Profile.HandStand ? 200 : 500;
            int dec = item < 4 ? 1 : 0; // same decimals as the matching normal-hand box
            NumericUpDown nx = null, ny = null;
            Button reset = null;
            Label normal = Unit("");
            normal.Font = monoFont;
            Label auto = Unit("自动");
            Func<int, double> get = delegate(int axis)
            {
                double x, y;
                Cur.HandValue(item, out x, out y);
                return axis == 0 ? x : y;
            };
            Action paint = delegate
            {
                Profile p = Cur;
                if (p == null || nx == null || reset == null) return;
                bool custom = p.IsHandCustom(item);
                normal.Text = NormalHandText(p, item);
                Color fore = custom ? Theme.ColText : Theme.ColMuted;
                nx.ForeColor = fore;
                if (ny != null) ny.ForeColor = fore;
                auto.Visible = !custom;
                reset.Visible = custom;
            };
            nx = Num(-lim, lim, 1, dec, delegate { return get(0); },
                delegate(double v) { Cur.SetHandCustom(item, v, ny == null ? 0 : (double)ny.Value); paint(); });
            if (hasY)
                ny = Num(-lim, lim, 1, dec, delegate { return get(1); },
                    delegate(double v) { Cur.SetHandCustom(item, (double)nx.Value, v); paint(); });
            // one column width for every row (W/S/A/D boxes have 1 decimal, Q/E none): spin buttons line up
            FixUp(delegate { int w = NumWidth(-500, 500, 1); nx.Width = w; if (ny != null) ny.Width = w; });
            reset = Btn("恢复自动", delegate
            {
                Cur.SetHandAuto(item);
                RefreshValues();
                PaintHandRows();
                app.Changed();
            });
            Tip(reset, "回到自动（正常手左右镜像）");
            refreshers.Add(paint);
            handRefreshers.Add(delegate { nx.Value = ToDec(get(0), nx); if (ny != null) ny.Value = ToDec(get(1), ny); });
            handPainters.Add(paint);
            Label name = Lbl(Profile.HandItemNames[item]);
            if (item == Profile.HandDrift)
            {
                // 到顶时水平偏移 belongs to the recoil extras (folded on 后坐力): 高级设置 only, like there
                name.Text = "到顶时水平偏移（后坐力）";
                AdvRow(g, name, normal, nx, Blank(), Line(auto, reset));
            }
            else
            {
                int lean = item == Profile.HandQ ? KeyBindings.ActionLeanLeft : item == Profile.HandE ? KeyBindings.ActionLeanRight : -1;
                if (lean >= 0) // the user may have rebound 侧身 (e.g. Ctrl+D): show the real key
                    refreshers.Add(delegate { name.Text = (lean == KeyBindings.ActionLeanLeft ? "左侧身（" : "右侧身（") + G.Keys.ComboOf(lean) + "）"; });
                Row(g, name, normal, nx, hasY ? (Control)ny : Blank(), Line(auto, reset));
            }
        }

        /// <summary>"x / y" of the normal hand for a 换手 item (到顶时水平偏移: just x).</summary>
        private static string NormalHandText(Profile p, int item)
        {
            double x, y;
            switch (item)
            {
                case 0: case 1: case 2: case 3: x = p.Dirs[item].OffX; y = p.Dirs[item].OffY; break;
                case Profile.HandStand: x = p.StandOffsetX; y = p.StandOffsetY; break;
                case Profile.HandQ: x = p.LeanQX; y = p.LeanQY; break;
                case Profile.HandE: x = p.LeanEX; y = p.LeanEY; break;
                default: return HandFmt(p.RecoilDriftX);
            }
            return HandFmt(x) + " / " + HandFmt(y);
        }

        private static string HandFmt(double v)
        {
            double r = Math.Round(v, 1);
            if (r == 0) r = 0; // no "-0"
            return r.ToString("0.#", System.Globalization.CultureInfo.InvariantCulture);
        }
    }
}
#endif
