﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

// 分辨率 · 常规 page (PAGE-A). Part of the settings window: partial class SettingsForm (shell, shared helpers, 高级设置 switch: SettingsForm.cs).
// Page rule: use the shell helpers (Grid / Line / Stack / Row / AdvRow / AdvOnly / Lbl / Note / Unit / Num / Choice / Check /
// Btn / Group / Fold / FixUp / F / S / P / Tip / EnableWhen) and read `Advanced`; never change another page's file.

#if !UI_PURE_CHECK
namespace TarkovCrosshair
{
    internal sealed partial class SettingsForm
    {
        /// <summary>常规: 分辨率换算 first (SPEC v4 page 2), then display, game window, window / start-up.</summary>
        private Control BuildGeneral()
        {
            // 分辨率换算
            TableLayoutPanel gr = Grid(2);
            Row(gr, "游戏分辨率", Line(
                Num(640, 7680, 1, 0, delegate { return G.ResGameW; }, delegate(double v) { G.ResGameW = v; }), Unit("×"),
                Num(480, 4320, 1, 0, delegate { return G.ResGameH; }, delegate(double v) { G.ResGameH = v; }),
                AutoDetectBtn()));
            TableLayoutPanel resBox = Grid(1);
            resBox.Controls.Add(gr);
            resBox.Controls.Add(Note("填游戏里的分辨率。偏移量是按 2160×1440 调的，换分辨率会自动按比例换算（视野 FOV 不会换算）。第一次打开时已经自动填好主显示器的分辨率。", 560));
            Section gRes = Group("分辨率", resBox);
            return BuildGeneralRest(gRes);
        }

        private Button AutoDetectBtn()
        {
            Button b = Btn("自动检测", delegate
                {
                    Screen[] all = Screen.AllScreens;
                    Screen sc = (G.MonitorIndex >= 0 && G.MonitorIndex < all.Length) ? all[G.MonitorIndex] : Screen.PrimaryScreen;
                    // primary screen: its real pixels (not scaled by Windows display scaling); another screen: its bounds
                    if (!sc.Primary || !G.DetectGameResolution(ScreenDetect.PrimaryPixels))
                    {
                        G.ResGameW = Clamp.D(sc.Bounds.Width, 640, 7680, 2160);
                        G.ResGameH = Clamp.D(sc.Bounds.Height, 480, 4320, 1440);
                    }
                    RefreshValues();
                    app.Changed();
                    SetStatus("游戏分辨率：" + Math.Round(G.ResGameW) + " × " + Math.Round(G.ResGameH), false);
                });
            Tip(b, "填成显示器的真实分辨率（不受 Windows 缩放影响）");
            return b;
        }

        /// <summary>常规 after 分辨率: display (monitor shown when there is more than one), game window, window / start-up.</summary>
        private Control BuildGeneralRest(Section gRes)
        {
            // 显示器 / 渐变
            TableLayoutPanel o = Grid(2);
            cbMonitor = new ComboBox();
            cbMonitor.DropDownStyle = ComboBoxStyle.DropDownList;
            FixUp(delegate { cbMonitor.Width = F(250); });
            cbMonitor.Anchor = AnchorStyles.Left;
            cbMonitor.Margin = P(3, 3, 3, 3);
            cbMonitor.SelectedIndexChanged += delegate
            {
                if (loading || cbMonitor.SelectedIndex < 0) return;
                G.MonitorIndex = cbMonitor.SelectedIndex - 1; // item 0 = primary (-1)
                app.Changed();
            };
            WheelScrollsPage(cbMonitor);
            refreshers.Add(RefreshMonitors);
            Row(o, "显示器", cbMonitor);
            // v4.0: no frame-rate option -- the crosshair always runs at the monitor's refresh rate
            AdvRow(o, "出现渐变", Line(Num(0, 1000, 10, 0, delegate { return G.ShowFadeMs; }, delegate(double v) { G.ShowFadeMs = v; }), Unit("ms")));
            AdvRow(o, "消失渐变", Line(Num(0, 1000, 10, 0, delegate { return G.HideFadeMs; }, delegate(double v) { G.HideFadeMs = v; }), Unit("ms")));
            Section gDisp = Group("显示", o);
            // one screen: nothing to choose, so the group is 高级设置 only; several screens: the 显示器 choice is always shown
            refreshers.Add(delegate { gDisp.Visible = Advanced || ScreenCount() > 1; });

            // 只在塔科夫前台时显示
            TableLayoutPanel f = Grid(2);
            TextBox title = new TextBox();
            FixUp(delegate { title.Width = F(230); });
            title.Anchor = AnchorStyles.Left;
            title.Margin = P(3, 3, 3, 3);
            title.TextChanged += delegate
            {
                if (loading) return;
                G.GameWindowTitle = title.Text.Trim();
                app.Changed();
            };
            refreshers.Add(delegate { title.Text = G.GameWindowTitle ?? ""; });
            Tip(title, "前台窗口标题里包含这段文字就算塔科夫在前台（不分大小写）");
            Button pick = null;
            pick = Btn("从打开的窗口里选 ▾", delegate { ShowWindowMenu(pick, title); });
            Action titleOn = EnableWhen(delegate { return G.OnlyWhenGameFocused; }, title, pick);
            CheckBox only = Check("只在塔科夫前台时显示", delegate { return G.OnlyWhenGameFocused; }, delegate(bool v) { G.OnlyWhenGameFocused = v; titleOn(); });
            Tip(only, "切出游戏时准星自动隐藏，也不读按键；这个设置窗口在前台时照常显示");
            f.Controls.Add(only);
            f.SetColumnSpan(only, 2);
            Label onlyNote = Note("切出游戏（例如 Alt+Tab）时准星自动隐藏；这个设置窗口在前台时照常显示。", 560);
            onlyNote.Margin = P(22, 0, 6, 6);
            f.Controls.Add(onlyNote);
            f.SetColumnSpan(onlyNote, 2);
            AdvRow(f, "窗口标题", Line(title, pick));
            Section gGame = Group("游戏窗口", f);

            // 窗口 / 开机
            TableLayoutPanel w = Grid(1);
            w.Controls.Add(AdvOnly(Line(
                Check("设置窗口置顶", delegate { return G.SettingsTopMost; }, delegate(bool v) { G.SettingsTopMost = v; TopMost = v; if (tutorial != null && !tutorial.IsDisposed) tutorial.TopMost = v; }),
                Check("启动时打开设置", delegate { return G.ShowSettingsOnStart; }, delegate(bool v) { G.ShowSettingsOnStart = v; }),
                Check("启动动画", delegate { return G.SplashOnStart; }, delegate(bool v) { G.SplashOnStart = v; }))));
            chkAutostart = new CheckBox();
            chkAutostart.Text = "开机自动启动";
            chkAutostart.AutoSize = true;
            chkAutostart.Anchor = AnchorStyles.Left;
            chkAutostart.Margin = P(3, 3, 8, 3);
            Tip(chkAutostart, "登录 Windows 后自动在托盘里启动（用任务计划，不弹管理员确认）");
            chkAutostart.CheckedChanged += delegate { if (!loading) SetAutostart(chkAutostart.Checked); };
            refreshers.Add(delegate { chkAutostart.Checked = G.Autostart; });
            w.Controls.Add(Line(chkAutostart, AdvOnly(Btn("打开设置文件夹", delegate
            {
                try { Process.Start("explorer.exe", "\"" + Program.BaseDir.TrimEnd('\\') + "\""); }
                catch (Exception ex) { MessageBox.Show(this, ex.Message, Text); }
            }))));
            Section gWin = Group("窗口和开机", w);
            return Stack(gRes, gDisp, gGame, gWin);
        }

        private static int ScreenCount()
        {
            try { return Screen.AllScreens.Length; }
            catch (Exception) { return 1; }
        }

        private void ShowWindowMenu(Button anchor, TextBox target)
        {
            if (windowMenu == null) { windowMenu = new ContextMenuStrip(); StyleMenu(windowMenu); }
            windowMenu.Items.Clear();
            List<string> titles = null;
            try { titles = GameWindow.VisibleTitles(); }
            catch (Exception ex) { Program.Log("VisibleTitles: " + ex.Message); }
            if (titles == null || titles.Count == 0)
            {
                ToolStripMenuItem none = new ToolStripMenuItem("（没有找到打开的窗口）");
                none.Enabled = false;
                windowMenu.Items.Add(none);
            }
            else
            {
                foreach (string t in titles)
                {
                    if (string.IsNullOrEmpty(t)) continue;
                    string pickText = t;
                    string shown = t.Length > 70 ? t.Substring(0, 67) + "…" : t;
                    ToolStripMenuItem it = new ToolStripMenuItem(shown);
                    it.Click += delegate { target.Text = pickText; }; // TextChanged saves it
                    windowMenu.Items.Add(it);
                }
            }
            windowMenu.Show(anchor, new Point(0, anchor.Height));
        }

        private void SetAutostart(bool on)
        {
            string err = null;
            bool ok;
            Cursor old = Cursor.Current;
            Cursor.Current = Cursors.WaitCursor;
            try { ok = on ? Autostart.Enable(Application.ExecutablePath, out err) : Autostart.Disable(out err); }
            catch (Exception ex) { ok = false; err = ex.Message; }
            finally { Cursor.Current = old; }
            if (ok) G.Autostart = on;
            else
            {
                MessageBox.Show(this, (on ? "设置开机自动启动失败：" : "取消开机自动启动失败：") + (err ?? "未知错误"), Text,
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                try { G.Autostart = Autostart.IsEnabled(); } catch (Exception) { } // show the real task state
            }
            bool was = loading;
            loading = true;
            chkAutostart.Checked = G.Autostart;
            loading = was;
            app.Changed();
        }

        public void RefreshMonitors()
        {
            bool was = loading;
            loading = true;
            cbMonitor.Items.Clear();
            cbMonitor.Items.Add("主显示器");
            Screen[] all = Screen.AllScreens;
            for (int i = 0; i < all.Length; i++)
            {
                Rectangle b = all[i].Bounds;
                cbMonitor.Items.Add("显示器 " + (i + 1) + "（" + b.Width + "x" + b.Height + "）" + (all[i].Primary ? " 主" : ""));
            }
            int idx = G.MonitorIndex + 1;
            cbMonitor.SelectedIndex = (idx >= 0 && idx < cbMonitor.Items.Count) ? idx : 0;
            loading = was;
        }
    }
}
#endif
