﻿// SettingsForm.PageGuide.cs -- the 「指南」 page (v4.0, UI-SHELL): the whole 说明 README.txt inside the app -- by Leo.
using System;
#if !UI_PURE_CHECK
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
#endif

namespace TarkovCrosshair
{
    /// <summary>Splits the guide into display lines with a kind (pure: used by the page and the tests).</summary>
    internal static class GuideFormat
    {
        public const int Body = 0, Heading = 1, Rule = 2;

        /// <summary>A line of 5 or more '=' / '-' (or '─' '═') and nothing else.</summary>
        public static bool IsRule(string line)
        {
            string t = (line ?? "").Trim();
            if (t.Length < 5) return false;
            foreach (char c in t) if (c != '=' && c != '-' && c != '─' && c != '═') return false;
            return true;
        }

        /// <summary>Kind per line: Rule; Heading = a 【…】 line, a line between two rules, or the first non-empty line
        /// (the title); else Body.</summary>
        public static int[] Kinds(string[] lines)
        {
            int[] k = new int[lines.Length];
            bool titleSeen = false;
            for (int i = 0; i < lines.Length; i++)
            {
                string t = (lines[i] ?? "").Trim();
                if (IsRule(t)) { k[i] = Rule; continue; }
                bool between = i > 0 && i + 1 < lines.Length && IsRule(lines[i - 1]) && IsRule(lines[i + 1]);
                bool bracket = t.StartsWith("【") && t.EndsWith("】");
                bool title = !titleSeen && t.Length > 0;
                if (t.Length > 0) titleSeen = true;
                k[i] = (t.Length > 0 && (between || bracket || title)) ? Heading : Body;
            }
            return k;
        }

        /// <summary>RTF for the 指南 view: body in 'text', headings bold in 'accent', rules in 'rule'; every non-ASCII char
        /// as \uN? so any code page works.</summary>
        public static string Rtf(string[] lines, int[] kinds, string fontName, float pt, System.Drawing.Color text,
            System.Drawing.Color accent, System.Drawing.Color rule)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            int half = Math.Max(16, (int)Math.Round(pt * 2));
            sb.Append(@"{\rtf1\ansi\ansicpg936\deff0{\fonttbl{\f0\fnil\fcharset134 ");
            Escape(sb, string.IsNullOrEmpty(fontName) ? "Microsoft YaHei UI" : fontName);
            sb.Append(";}}{\\colortbl ;");
            foreach (System.Drawing.Color c in new System.Drawing.Color[] { text, accent, rule })
                sb.Append("\\red").Append(c.R).Append("\\green").Append(c.G).Append("\\blue").Append(c.B).Append(';');
            sb.Append("}\\f0\\fs").Append(half).Append(' ');
            for (int i = 0; i < lines.Length; i++)
            {
                int k = i < kinds.Length ? kinds[i] : Body;
                sb.Append(k == Heading ? "\\cf2\\b " : (k == Rule ? "\\cf3\\b0 " : "\\cf1\\b0 "));
                Escape(sb, lines[i] ?? "");
                if (k == Heading) sb.Append("\\b0");
                if (i + 1 < lines.Length) sb.Append("\\par\r\n");
            }
            sb.Append('}');
            return sb.ToString();
        }

        private static void Escape(System.Text.StringBuilder sb, string s)
        {
            foreach (char c in s)
            {
                if (c == '\\' || c == '{' || c == '}') sb.Append('\\').Append(c);
                else if (c == '\t') sb.Append("\\tab ");
                else if (c < 0x20) continue;
                else if (c < 0x80) sb.Append(c);
                else sb.Append("\\u").Append((int)(short)c).Append('?');
            }
        }

        public static string[] Lines(string text)
        {
            return (text ?? "").Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
        }
    }

#if !UI_PURE_CHECK
    internal sealed partial class SettingsForm
    {
        public const string GuideFileName = "说明 README.txt";
        private RichTextBox guideBox;
        private Font guideBold;

        /// <summary>指南: read-only, themed, wrapped view of GuideText.Text (headings bold, accent) + 「打开说明文件」.</summary>
        private Control BuildGuide()
        {
            TableLayoutPanel t = new TableLayoutPanel();
            t.ColumnCount = 1;
            t.RowCount = 2;
            t.Margin = new Padding(0);
            t.Padding = P(0, 8, 0, 0);
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            t.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            t.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));

            Button open = Btn("打开说明文件", delegate { OpenGuideFile(); });
            Tip(open, "用记事本打开启动程序旁边的「" + GuideFileName + "」（和这一页内容一样）");
            Label hint = Note("和文件夹里的「" + GuideFileName + "」内容一样。", 520);
            t.Controls.Add(Line(open, hint), 0, 0);

            guideBox = new RichTextBox();
            guideBox.Dock = DockStyle.Fill;
            guideBox.ReadOnly = true;
            guideBox.WordWrap = true;
            guideBox.ScrollBars = RichTextBoxScrollBars.Vertical; // wraps to the page width: never a horizontal bar
            guideBox.DetectUrls = false;
            guideBox.ShortcutsEnabled = true; // Ctrl+A / Ctrl+C still copy
            guideBox.BorderStyle = BorderStyle.FixedSingle;
            guideBox.BackColor = Theme.ColInput;
            guideBox.ForeColor = Theme.ColText;
            guideBox.Margin = P(0, 8, 0, 0);
            guideBox.Tag = "theme:keep-guide"; // coloured runs: the theme must not reset the whole text colour
            guideBox.TabStop = true;
            t.Controls.Add(guideBox, 0, 1);
            FixUp(FillGuide); // text size follows the window (11 pt x uiScale); rebuilt on every size step
            return t;
        }

        /// <summary>(Re)writes the guide with the current fonts: body = form font (>= 11 pt), headings bold accent.</summary>
        private void FillGuide()
        {
            if (guideBox == null || guideBox.IsDisposed) return;
            Font body = Font;
            Font oldBold = guideBold;
            guideBold = new Font(body, FontStyle.Bold);
            string[] lines = GuideFormat.Lines(GuideText.Text);
            int[] kinds = GuideFormat.Kinds(lines);
            int keep = guideBox.SelectionStart;
            guideBox.SuspendLayout();
            try
            {
                guideBox.Font = body;
                // one RTF document (RichEdit applies it in one go; per-run SelectionFont/Color is slower and less reliable)
                guideBox.Rtf = GuideFormat.Rtf(lines, kinds, body.Name, body.SizeInPoints, Theme.ColText, Theme.ColAccent, Theme.ColMuted);
                guideBox.SelectionStart = Math.Min(keep, guideBox.TextLength);
                guideBox.SelectionLength = 0;
                if (keep == 0) guideBox.ScrollToCaret();
            }
            catch (Exception ex) { Program.Log("UI: guide: " + ex); }
            finally { guideBox.ResumeLayout(); }
            if (oldBold != null && oldBold != guideBold) oldBold.Dispose();
        }

        /// <summary>Opens 「说明 README.txt」 next to the launcher (SettingsIO.UserDir); README.txt as a fallback name.</summary>
        private void OpenGuideFile()
        {
            string dir;
            try { dir = SettingsIO.UserDir(); } catch (Exception) { dir = AppDomain.CurrentDomain.BaseDirectory; }
            string path = null;
            foreach (string n in new string[] { GuideFileName, "README.txt" })
            {
                try { string p = Path.Combine(dir, n); if (File.Exists(p)) { path = p; break; } }
                catch (Exception) { }
            }
            if (path == null)
            {
                Say("没找到「" + GuideFileName + "」（应该在启动程序旁边）。这一页就是同样的内容。");
                return;
            }
            try { Process.Start(path); }
            catch (Exception)
            {
                try { Process.Start("notepad.exe", "\"" + path + "\""); }
                catch (Exception ex) { Say("打不开说明文件：" + ex.Message); }
            }
        }
    }
#endif
}
