﻿// DashboardLogic.cs -- v4.0 首页 dashboard: the pure pieces (trail buffer, terminal log, number cache, chart scale,
// decode effect, formatting). PURE file: only System / System.Text (+ KeyBindings / InputState from Settings.cs / Motion.cs). Compiles under net48 (C# 5) and net8.0 (tests).
// Nothing here allocates per call except where a NEW string is the result (a log line, a changed number).
using System;
using System.Globalization;
using System.Text;

namespace TarkovCrosshair
{
    /// <summary>Bit mask of the keys shown as key caps on the dashboard (raw state, before the opposite-key filter).</summary>
    public static class DashKeys
    {
        public const int W = 1, A = 2, S = 4, D = 8, Q = 16, E = 32, Space = 64, Lmb = 128, Rmb = 256, Shift = 512;
        public const int Count = 10;
        /// <summary>Cap order: W A S D Q E Space LMB RMB Shift (also the order of the combo text).</summary>
        public static readonly int[] Bits = new int[] { W, A, S, D, Q, E, Space, Lmb, Rmb, Shift };
        public static readonly string[] Names = new string[] { "W", "A", "S", "D", "Q", "E", "Space", "LMB", "RMB", "Shift" };

        /// <summary>冲刺 = Shift + W (the same rule MotionEngine uses for 冲刺取消开镜 / 冲刺取消侧身).</summary>
        public static bool Sprinting(int mask) { return (mask & (W | Shift)) == (W | Shift); }

        /// <summary>W = 前进, A = 左移, S = 后退, D = 右移, Q/E = 侧身, Space = 跳跃, LMB = 开火, RMB = 开镜, Shift = 冲刺 (with W).</summary>
        public static int FromInput(InputState i)
        {
            int m = 0;
            if (i.Fwd) m |= W;
            if (i.Left) m |= A;
            if (i.Back) m |= S;
            if (i.Right) m |= D;
            if (i.LeanL) m |= Q;
            if (i.LeanR) m |= E;
            if (i.Jump) m |= Space;
            if (i.Fire) m |= Lmb;
            if (i.Ads) m |= Rmb;
            if (i.Shift) m |= Shift;
            return m;
        }
    }

    public static class DashFormat
    {
        private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

        /// <summary>Tenths, rounded half away from zero; NaN / infinity -> 0; clamped to +-9,999,999.9.</summary>
        public static long Tenths(double v)
        {
            if (double.IsNaN(v) || double.IsInfinity(v)) return 0;
            double t = Math.Round(v * 10.0, MidpointRounding.AwayFromZero);
            if (t > 99999999) t = 99999999;
            if (t < -99999999) t = -99999999;
            return (long)t;
        }

        /// <summary>"+12.0", "-3.4", "+0.0" (never "-0.0").</summary>
        public static string Signed1FromTenths(long tenths)
        {
            long a = tenths < 0 ? -tenths : tenths;
            return (tenths < 0 ? "-" : "+") + (a / 10).ToString(Inv) + "." + (a % 10).ToString(Inv);
        }

        public static string Signed1(double v) { return Signed1FromTenths(Tenths(v)); }

        /// <summary>"12.0", "0.0" (absolute value, no sign).</summary>
        public static string Abs1FromTenths(long tenths)
        {
            long a = tenths < 0 ? -tenths : tenths;
            return (a / 10).ToString(Inv) + "." + (a % 10).ToString(Inv);
        }

        /// <summary>"W+D+LMB"; "IDLE" when no key is down. Order = DashKeys.Bits.</summary>
        public static string KeyCombo(int mask) { return KeyCombo(mask, null); }

        /// <summary>Same with the user's key names per cap (DashKeys order, e.g. "Ctrl+D" for 右侧身); null = DashKeys.Names.</summary>
        public static string KeyCombo(int mask, string[] names)
        {
            if ((mask & ((1 << DashKeys.Count) - 1)) == 0) return "IDLE";
            StringBuilder sb = new StringBuilder(32);
            for (int i = 0; i < DashKeys.Count; i++)
            {
                if ((mask & DashKeys.Bits[i]) == 0) continue;
                if (sb.Length > 0) sb.Append('+');
                string n = names != null && i < names.Length && !string.IsNullOrEmpty(names[i]) ? names[i] : DashKeys.Names[i];
                sb.Append(n);
            }
            return sb.ToString();
        }

        /// <summary>Seconds with 2 decimals: "0.70 s" (NaN / negative -> "0.00 s", clamped to 999.99).</summary>
        public static string Seconds2(double ms)
        {
            if (double.IsNaN(ms) || ms < 0) ms = 0;
            long c = (long)Math.Round(ms / 10.0, MidpointRounding.AwayFromZero);
            if (c > 99999) c = 99999;
            return (c / 100).ToString(Inv) + "." + (c % 100).ToString("00", Inv) + " s";
        }

        /// <summary>The line for a key state that has just ENDED: its keys, the ring offset it ended on (the same X / Y the
        /// 实时数据 card showed) and how long it lasted, e.g. "> D  X -30.0  Y +3.0 px  0.70 s"; "> W+Shift 冲刺  …".</summary>
        public static string StateLine(int mask, string[] names, double x, double y, double durationMs)
        {
            return "> " + KeyCombo(mask, names) + (DashKeys.Sprinting(mask) ? " 冲刺" : "") + "  X " + Signed1(x) + "  Y " + Signed1(y)
                + " px  " + Seconds2(durationMs);
        }

        /// <summary>Whole ms, clamped 0..99999 (NaN -> 0).</summary>
        public static long Ms(double ms)
        {
            if (double.IsNaN(ms) || ms < 0) return 0;
            if (ms > 99999) return 99999;
            return (long)Math.Round(ms, MidpointRounding.AwayFromZero);
        }

        /// <summary>Bytes -> "18.4 MB" (1 MB = 1024 x 1024 bytes). Negative -> "0.0 MB".</summary>
        public static string Megabytes(long bytes)
        {
            if (bytes < 0) bytes = 0;
            return Abs1FromTenths(MbTenths(bytes)) + " MB";
        }

        public static long MbTenths(long bytes)
        {
            if (bytes < 0) bytes = 0;
            return (long)Math.Round(bytes * 10.0 / (1024.0 * 1024.0), MidpointRounding.AwayFromZero);
        }
    }

    /// <summary>
    /// A text that is rebuilt only when its displayed number changes (so a steady value costs no allocation per frame).
    /// One instance per on-screen field; prefix / suffix are fixed per call site.
    /// </summary>
    public sealed class DashText
    {
        private long key = long.MinValue;
        private string text = "";
        public string Text { get { return text; } }

        /// <summary>Signed, one decimal: prefix + "+12.0" + suffix. Returns true when the text changed.</summary>
        public bool Signed1(double v, string prefix, string suffix)
        {
            long k = DashFormat.Tenths(v);
            if (k == key) return false;
            key = k;
            text = prefix + DashFormat.Signed1FromTenths(k) + suffix;
            return true;
        }

        /// <summary>Unsigned (absolute), one decimal.</summary>
        public bool Abs1(double v, string prefix, string suffix)
        {
            long k = DashFormat.Tenths(Math.Abs(double.IsNaN(v) ? 0 : v));
            if (k == key) return false;
            key = k;
            text = prefix + DashFormat.Abs1FromTenths(k) + suffix;
            return true;
        }

        public bool Int(long v, string prefix, string suffix)
        {
            if (v == key) return false;
            key = v;
            text = prefix + v.ToString(CultureInfo.InvariantCulture) + suffix;
            return true;
        }

        public bool Megabytes(long bytes, string prefix, string suffix)
        {
            long k = DashFormat.MbTenths(bytes);
            if (k == key) return false;
            key = k;
            text = prefix + DashFormat.Abs1FromTenths(k) + " MB" + suffix;
            return true;
        }

        /// <summary>A text chosen by the caller for a small integer state (e.g. lean percent with side).</summary>
        public bool Keyed(long k, string value)
        {
            if (k == key) return false;
            key = k;
            text = value ?? "";
            return true;
        }

        public void Invalidate() { key = long.MinValue; }
    }

    /// <summary>Fixed-size ring buffer of ring positions with a time stamp; points older than MaxAgeMs are dropped.</summary>
    public sealed class DashTrail
    {
        private readonly double[] xs, ys, ts;
        private int head;   // index of the oldest point
        private int count;
        private double lastX, lastY; // the newest point ever added (kept after the buffer empties: a still ring adds nothing)
        private bool hasLast;
        public readonly int Capacity;
        public double MaxAgeMs;

        public DashTrail(int capacity, double maxAgeMs)
        {
            if (capacity < 2) capacity = 2;
            Capacity = capacity;
            xs = new double[capacity]; ys = new double[capacity]; ts = new double[capacity];
            MaxAgeMs = maxAgeMs > 0 ? maxAgeMs : 1000;
        }

        public int Count { get { return count; } }

        public void Clear() { head = 0; count = 0; hasLast = false; }

        /// <summary>Adds a point unless it is closer than minStep to the newest point ever added -- also after every point
        /// has aged out, so a ring that stands still keeps the trail empty -- or is not a number. Full buffer: the oldest goes.</summary>
        public bool Add(double tMs, double x, double y, double minStep)
        {
            if (double.IsNaN(x) || double.IsNaN(y) || double.IsInfinity(x) || double.IsInfinity(y) || double.IsNaN(tMs)) return false;
            if (hasLast)
            {
                double ddx = x - lastX, ddy = y - lastY;
                if (ddx * ddx + ddy * ddy < minStep * minStep) return false;
            }
            lastX = x; lastY = y; hasLast = true;
            int idx;
            if (count < Capacity) { idx = (head + count) % Capacity; count++; }
            else { idx = head; head = (head + 1) % Capacity; }
            xs[idx] = x; ys[idx] = y; ts[idx] = tMs;
            return true;
        }

        /// <summary>Drops points older than MaxAgeMs (and any stamped in the future by more than a second -- clock reset).</summary>
        public void Trim(double nowMs)
        {
            while (count > 0)
            {
                double age = nowMs - ts[head];
                if (age > MaxAgeMs || age < -1000) { head = (head + 1) % Capacity; count--; }
                else break;
            }
            if (count == 0) head = 0;
        }

        /// <summary>i = 0 is the oldest point.</summary>
        public void Get(int i, out double x, out double y, out double tMs)
        {
            if (i < 0 || i >= count) throw new ArgumentOutOfRangeException("i");
            int k = (head + i) % Capacity;
            x = xs[k]; y = ys[k]; tMs = ts[k];
        }

        /// <summary>Largest |x| or |y| of the stored points (0 when empty).</summary>
        public double AbsPeak()
        {
            double m = 0;
            for (int i = 0; i < count; i++)
            {
                int k = (head + i) % Capacity;
                double a = Math.Abs(xs[k]), b = Math.Abs(ys[k]);
                if (a > m) m = a;
                if (b > m) m = b;
            }
            return m;
        }
    }

    /// <summary>
    /// The terminal box: a capped list of lines with a typed-out effect. A new line starts typing when the previous
    /// one has finished; if that would queue it more than MaxQueueMs, every earlier line is completed at once (so a
    /// burst of key changes never builds a long backlog).
    /// </summary>
    public sealed class DashLog
    {
        private readonly string[] lines;
        private readonly double[] starts;
        private int head, count;
        public readonly int Capacity;
        public double CharsPerSec = 160;
        public double MaxQueueMs = 250;
        private int version;

        public DashLog(int capacity)
        {
            if (capacity < 1) capacity = 1;
            Capacity = capacity;
            lines = new string[capacity];
            starts = new double[capacity];
        }

        public int Count { get { return count; } }
        /// <summary>Changes whenever a line is added or the log is cleared.</summary>
        public int Version { get { return version; } }

        public void Clear() { head = 0; count = 0; version++; }

        private int Index(int i) { return (head + i) % Capacity; }

        private double EndMs(int idx)
        {
            double cps = CharsPerSec > 1 ? CharsPerSec : 1;
            return starts[idx] + lines[idx].Length * 1000.0 / cps;
        }

        public void Add(string line, double nowMs)
        {
            if (line == null) line = "";
            double start = nowMs;
            if (count > 0)
            {
                double end = EndMs(Index(count - 1));
                if (end > nowMs)
                {
                    if (end - nowMs <= MaxQueueMs) start = end;
                    else CompleteAll();
                }
            }
            int idx;
            if (count < Capacity) { idx = Index(count); count++; }
            else { idx = head; head = (head + 1) % Capacity; }
            lines[idx] = line;
            starts[idx] = start;
            version++;
        }

        /// <summary>Shows every line in full right now.</summary>
        public void CompleteAll()
        {
            for (int i = 0; i < count; i++) starts[Index(i)] = double.MinValue / 4;
        }

        /// <summary>i = 0 is the oldest line.</summary>
        public string Line(int i)
        {
            if (i < 0 || i >= count) throw new ArgumentOutOfRangeException("i");
            return lines[Index(i)];
        }

        /// <summary>How many characters of line i are typed out at nowMs (0..length).</summary>
        public int Visible(int i, double nowMs)
        {
            if (i < 0 || i >= count) return 0;
            int idx = Index(i);
            int len = lines[idx].Length;
            double cps = CharsPerSec > 1 ? CharsPerSec : 1;
            double n = (nowMs - starts[idx]) * cps / 1000.0;
            if (double.IsNaN(n) || n <= 0) return 0;
            if (n >= len) return len;
            return (int)n;
        }

        /// <summary>True while the newest line is still being typed.</summary>
        public bool Typing(double nowMs)
        {
            if (count == 0) return false;
            return Visible(count - 1, nowMs) < lines[Index(count - 1)].Length;
        }
    }

    /// <summary>Chart range (UI px from the centre to the edge) on a fixed ladder, with hysteresis so it does not flicker.</summary>
    public sealed class DashScale
    {
        public static readonly double[] Ladder = new double[] { 30, 50, 80, 120, 200, 300, 500, 800, 1200 };
        public static readonly double[] Steps = new double[] { 10, 10, 20, 30, 50, 100, 100, 200, 300 };
        /// <summary>Headroom: a range must hold peak x Headroom.</summary>
        public const double Headroom = 1.15;
        public double ShrinkAfterMs = 2500;

        private int rung;
        private double belowSinceMs = double.NaN;

        public int Rung { get { return rung; } }
        public double Range { get { return Ladder[rung]; } }
        public double Step { get { return Steps[rung]; } }

        /// <summary>Smallest rung that holds peak x Headroom (the top rung when nothing does).</summary>
        public static int RungFor(double peak)
        {
            if (double.IsNaN(peak) || peak < 0) peak = 0;
            double need = peak * Headroom;
            for (int i = 0; i < Ladder.Length; i++) if (Ladder[i] >= need) return i;
            return Ladder.Length - 1;
        }

        /// <summary>Grows at once; shrinks one rung only after the peak fit the smaller rung for ShrinkAfterMs. Returns true on change.</summary>
        public bool Update(double peak, double nowMs)
        {
            int want = RungFor(peak);
            if (want > rung) { rung = want; belowSinceMs = double.NaN; return true; }
            if (want < rung)
            {
                if (double.IsNaN(belowSinceMs)) { belowSinceMs = nowMs; return false; }
                if (nowMs - belowSinceMs >= ShrinkAfterMs)
                {
                    rung--;
                    belowSinceMs = rung > want ? nowMs : double.NaN;
                    return true;
                }
                return false;
            }
            belowSinceMs = double.NaN;
            return false;
        }

        public void Reset() { rung = 0; belowSinceMs = double.NaN; }
    }

    /// <summary>"Decoding" title effect: characters resolve left to right out of random glyphs.</summary>
    public static class DashDecode
    {
        public const string Glyphs = "01<>/\\#$%&*+=?ABCDEFXZ";

        /// <summary>Writes the frame for progress 0..1 into buf (length = target length). Spaces stay spaces.
        /// Returns true when every character is resolved.</summary>
        public static bool Fill(char[] buf, string target, double progress, int frame)
        {
            if (buf == null || target == null) return true;
            int n = Math.Min(buf.Length, target.Length);
            if (double.IsNaN(progress) || progress < 0) progress = 0;
            if (progress > 1) progress = 1;
            int resolved = (int)Math.Floor(progress * (n + 4)) - 4; // a 4-char scrambling window ahead of the resolved part
            bool done = true;
            for (int i = 0; i < n; i++)
            {
                char t = target[i];
                if (t == ' ' || i < resolved || progress >= 1) { buf[i] = t; continue; }
                done = false;
                uint h = (uint)(i * 7919 + frame * 104729) * 2654435761u;
                buf[i] = Glyphs[(int)((h >> 16) % (uint)Glyphs.Length)];
            }
            return done;
        }
    }

    /// <summary>
    /// Turns state changes into terminal lines. When the key mask changes, the state that just ENDED is logged with the
    /// ring offset it ended on and how long it lasted (DashFormat.StateLine; nothing for a no-key state), so the line
    /// agrees with the 实时数据 card. Plus one line when the hand, 强化准星 or 开镜 state flips. The first Step only records
    /// the state (no line).
    /// </summary>
    public sealed class DashEvents
    {
        public const string HandSwitched = "> 换手：左手持枪";
        public const string HandNormal = "> 换手：回到右手";
        public const string BoostOn = "> 强化准星 开";
        public const string BoostOff = "> 强化准星 关";
        public const string AdsOn = "> 开镜 开（准星隐藏）";
        public const string AdsOff = "> 开镜 关";

        private int prevMask = -1;
        private bool prevHand, prevBoost, prevAds;
        private double lastChangeMs, lastX, lastY;

        /// <summary>Key name per cap for the log (DashKeys order, the user's bindings); null = DashKeys.Names.</summary>
        public string[] Names;

        public void Reset() { prevMask = -1; }

        /// <summary>Returns the number of lines added. x / y = the ring offset this frame (after this frame's input).</summary>
        public int Step(int mask, bool hand, bool boost, bool ads, double x, double y, double nowMs, DashLog log)
        {
            if (prevMask < 0)
            {
                prevMask = mask; prevHand = hand; prevBoost = boost; prevAds = ads; lastChangeMs = nowMs; lastX = x; lastY = y;
                return 0;
            }
            int n = 0;
            if (mask != prevMask)
            {
                // the previous frame's offset is where the ended state left the ring (this frame already moved under the new keys)
                if ((prevMask & ((1 << DashKeys.Count) - 1)) != 0)
                {
                    log.Add(DashFormat.StateLine(prevMask, Names, lastX, lastY, nowMs - lastChangeMs), nowMs);
                    n++;
                }
                lastChangeMs = nowMs;
                prevMask = mask;
            }
            lastX = x; lastY = y;
            if (hand != prevHand) { log.Add(hand ? HandSwitched : HandNormal, nowMs); prevHand = hand; n++; }
            if (boost != prevBoost) { log.Add(boost ? BoostOn : BoostOff, nowMs); prevBoost = boost; n++; }
            if (ads != prevAds) { log.Add(ads ? AdsOn : AdsOff, nowMs); prevAds = ads; n++; }
            return n;
        }
    }

    // =================================================================================================== v4.0 layout

    /// <summary>Integer rectangle (pixels) for the pure layout (no System.Drawing here).</summary>
    public struct DashRect
    {
        public int X, Y, W, H;
        public DashRect(int x, int y, int w, int h) { X = x; Y = y; W = w < 0 ? 0 : w; H = h < 0 ? 0 : h; }
        public int Right { get { return X + W; } }
        public int Bottom { get { return Y + H; } }
        public bool IsEmpty { get { return W <= 0 || H <= 0; } }
        public bool Intersects(DashRect o)
        {
            if (IsEmpty || o.IsEmpty) return false;
            return X < o.Right && o.X < Right && Y < o.Bottom && o.Y < Bottom;
        }
        public bool Contains(DashRect o)
        {
            if (o.IsEmpty) return true;
            return o.X >= X && o.Y >= Y && o.Right <= Right && o.Bottom <= Bottom;
        }
        public override string ToString() { return X + "," + Y + " " + W + "x" + H; }
    }

    /// <summary>Measured text heights / widths in pixels (the panel measures its fonts; tests use Estimate).</summary>
    public sealed class DashMetrics
    {
        public double Title, Body, Small, Value, Mono, Cap;
        /// <summary>Width of the header's right block ("FPS 000   内存占用 0000.0 MB").</summary>
        public double RightW;

        /// <summary>Typical Microsoft YaHei UI / Consolas heights at u px per design unit (u = DPI scale x zoom).</summary>
        public static DashMetrics Estimate(double u)
        {
            DashMetrics m = new DashMetrics();
            // 16 / 11 / 10.5 pt YaHei UI, 12 pt bold / 10.5 pt / 11 pt bold Consolas
            m.Title = 28 * u; m.Body = 19.5 * u; m.Small = 18.6 * u; m.Value = 19 * u; m.Mono = 16.5 * u; m.Cap = 17.5 * u;
            m.RightW = 150 * u;
            return m;
        }
    }

    /// <summary>
    /// The 首页 dashboard layout, computed from the client size, the DPI scale and the measured font heights only:
    /// header (title + note | FPS + 内存占用), chart, 实时数据 card, terminal and the 按键 card. Wide panels put the
    /// data card right of the chart and the key caps right of the terminal; narrow panels (under 600 design units)
    /// stack the data card (2 columns when it fits) under the chart. Rows that do not fit are dropped from the end
    /// (least important first) and the key caps are hidden when they would be smaller than 16 units -- nothing is
    /// ever drawn outside its card or over another card.
    /// </summary>
    public sealed class DashLayout
    {
        public const int RowCount = 7;
        public const double NarrowBelow = 600;   // design units
        public const double CompactBelow = 420;  // design units of height: one-line header
        public const double MinCap = 22, WantCap = 28, MaxCap = 56, RowMax = 40, MinPlot = 110;

        public int W, H;
        public double S = 1, Zoom = 1, U = 1;
        public bool CompactHeader, Narrow, CapsShown, CapsTwoRows;
        public int Columns = 1, RowsShown, RowH, Pad, Gap, LineH;
        public DashRect Header, HeaderTitle, HeaderNote, HeaderRight1, HeaderRight2;
        public DashRect Chart, ChartTitle, ChartInner;
        public DashRect Data, DataTitle;
        public DashRect Term, TermTitle, TermInner;
        public DashRect Caps, CapsTitle, CapsInner;
        /// <summary>Live key-combo read-out under the caps ("> W+D+LMB"), only when the card has room for it.</summary>
        public DashRect CapsCombo;
        public readonly DashRect[] Rows = new DashRect[RowCount];
        /// <summary>Same order as DashKeys.Bits: W A S D Q E Space LMB RMB.</summary>
        public readonly DashRect[] CapRects = new DashRect[DashKeys.Count];
        public int CapSize;

        private int P(double units) { return (int)Math.Round(units * U); }

        /// <summary>Font / spacing zoom: the SPEC "dynamic font size by window size" rule, the same formula as
        /// Theme.UiScale.For (copied here because this file is pure): clamp(min(w / 1100, h / 740) in logical px, 1.0, 1.8),
        /// quantised down to 0.05. The panel passes its window's client size so its text matches the settings pages.</summary>
        public static double ZoomFor(int w, int h, double s)
        {
            if (w <= 0 || h <= 0) return 1;
            if (double.IsNaN(s) || double.IsInfinity(s) || s <= 0) s = 1;
            double z = Math.Min(w / s / 1100.0, h / s / 740.0);
            if (double.IsNaN(z) || z < 1) z = 1;
            if (z > 1.8) z = 1.8;
            return Math.Round(Math.Floor(z / 0.05 + 1e-9) * 0.05, 2);
        }

        public void Arrange(int w, int h, double s, double zoom, DashMetrics m)
        {
            if (m == null) m = DashMetrics.Estimate((s > 0 ? s : 1) * (zoom > 0 ? zoom : 1));
            W = Math.Max(1, w); H = Math.Max(1, h);
            S = s > 0 && !double.IsNaN(s) ? s : 1;
            Zoom = zoom > 0 && !double.IsNaN(zoom) ? zoom : 1;
            U = S * Zoom;
            Pad = P(12); Gap = P(10);
            int pad = Pad, gap = Gap;

            int tH = Ceil(m.Title), smH = Ceil(m.Small), bodyFontH = Ceil(Math.Max(m.Body, m.Small));
            int rowMin = Ceil(Math.Max(m.Body, m.Value)) + P(2);
            int rowPref = Math.Max(rowMin, P(28));
            LineH = Math.Max(1, Ceil(m.Mono) + P(2));
            int titleBar = bodyFontH + P(10);
            int termTitle = Math.Max(smH + P(10), P(20));
            int termMin = termTitle + P(10) + (H / U < 300 ? 2 : 3) * LineH;   // a very short page keeps 2 log lines

            // ---------------- header
            CompactHeader = H / U < CompactBelow;
            int headerH = CompactHeader ? tH + P(10) : tH + smH + P(20);
            if (headerH > H / 3) headerH = H / 3;
            Header = new DashRect(0, 0, W, headerH);
            int rbw = Ceil(m.RightW);
            int rbMax = W / 2 - pad;
            if (rbw > rbMax) rbw = Math.Max(0, rbMax);
            int rx = W - pad - rbw;
            int row1Y = CompactHeader ? 0 : P(6);
            int row1H = CompactHeader ? headerH : Math.Min(headerH - row1Y, tH + P(2));
            HeaderRight1 = new DashRect(rx, row1Y, rbw, row1H);
            HeaderTitle = new DashRect(pad, row1Y, Math.Max(0, rx - P(12) - pad), row1H);
            if (CompactHeader)
            {
                HeaderNote = new DashRect(0, 0, 0, 0);
                HeaderRight2 = new DashRect(0, 0, 0, 0);
            }
            else
            {
                int ny = row1Y + row1H;
                int nh = Math.Max(0, Math.Min(smH + P(4), headerH - 1 - ny));
                HeaderNote = new DashRect(pad, ny, HeaderTitle.W, nh);
                HeaderRight2 = new DashRect(rx, ny, rbw, nh);
            }

            // ---------------- body
            bTop = Header.Bottom + gap;
            bBottom = H - pad;
            bH = Math.Max(0, bBottom - bTop);
            bW = Math.Max(0, W - 2 * pad);
            kTitleBar = titleBar; kRowMin = rowMin; kRowPref = rowPref; kTermMin = termMin;
            int wideScore = ArrangeWide();
            Narrow = false;
            if (W / U < NarrowBelow)
            {
                int narrowScore = ArrangeNarrow();
                if (narrowScore > wideScore) Narrow = true;
                else ArrangeWide();
            }

            ChartTitle = new DashRect(Chart.X, Chart.Y, Chart.W, Math.Min(titleBar, Chart.H));
            ChartInner = new DashRect(Chart.X + 1, Chart.Y + ChartTitle.H, Chart.W - 2, Chart.H - ChartTitle.H - 1);
            DataTitle = new DashRect(Data.X + P(12), Data.Y, Data.W - P(24), Math.Min(titleBar, Data.H));
            int colGap = P(16);
            int colW = Columns > 1 ? (Data.W - P(24) - colGap) / 2 : Data.W - P(24);
            for (int i = 0; i < RowCount; i++)
            {
                if (i >= RowsShown) { Rows[i] = new DashRect(0, 0, 0, 0); continue; }
                int c = i % Columns, r = i / Columns;
                Rows[i] = new DashRect(Data.X + P(12) + c * (colW + colGap), Data.Y + titleBar + r * RowH, colW, RowH);
            }
            TermTitle = new DashRect(Term.X + P(10), Term.Y, Term.W - P(20), Math.Min(termTitle, Term.H));
            TermInner = new DashRect(Term.X + P(10), Term.Y + termTitle + P(4), Term.W - P(20), Term.H - termTitle - P(8));
        }

        private int bTop, bBottom, bH, bW, kTitleBar, kRowMin, kRowPref, kTermMin;

        private void ResetCaps()
        {
            CapsShown = false; CapsTwoRows = false; CapSize = 0;
            for (int i = 0; i < CapRects.Length; i++) CapRects[i] = new DashRect(0, 0, 0, 0);
            Caps = CapsTitle = CapsInner = CapsCombo = new DashRect(0, 0, 0, 0);
        }

        /// <summary>Chart + terminal on the left; 实时数据 (content height) + 按键 (the rest) on the right.
        /// Returns the chart's usable size (smaller side of its plot area) to compare layouts.</summary>
        private int ArrangeWide()
        {
            ResetCaps();
            int pad = Pad, gap = Gap, titleBar = kTitleBar;
            int sideW = Clamp((int)Math.Round(bW * 0.30), P(200), P(300));
            if (sideW > (int)(bW * 0.45)) sideW = (int)(bW * 0.45);
            int leftW = Math.Max(0, bW - sideW - gap);
            int termH = Clamp((int)Math.Round(bH * 0.30), kTermMin, P(220));
            int chartH = bH - gap - termH;
            if (chartH - titleBar < P(MinPlot))
            {   // too short for chart + terminal: the chart (the main view) gets the whole column, the terminal goes
                Chart = new DashRect(pad, bTop, leftW, bH);
                Term = new DashRect(pad, bBottom, 0, 0);
            }
            else
            {
                Chart = new DashRect(pad, bTop, leftW, chartH);
                Term = new DashRect(pad, Chart.Bottom + gap, leftW, Math.Max(0, bBottom - (Chart.Bottom + gap)));
            }

            int x = pad + leftW + gap;
            int colH = bH;
            Columns = 1;
            int fitRows = kRowMin > 0 ? (colH - titleBar - P(6)) / kRowMin : 0;
            int n = Clamp(fitRows, 0, RowCount);
            RowsShown = n;
            int cg = P(6), innerW = sideW - P(20);
            int capsMinH = titleBar + P(8) + 2 * P(MinCap) + cg;          // 2-row caps at the smallest size
            int capsWantH = titleBar + P(8) + 2 * P(WantCap) + cg;        // 2-row caps at a comfortable size
            int csIdeal = Math.Max(P(MinCap), Math.Min(P(MaxCap), (innerW - 2 * cg) / 3));
            int capsIdealH = titleBar + P(8) + (int)(3.5 * csIdeal) + 3 * cg; // 4-row caps at full size
            bool caps = false;
            if (n > 0)
            {
                // rows share the column with the caps: grow up to RowMax when there is room, shrink to rowMin before
                // the caps go below their comfortable size, and only then let the caps shrink to MinCap
                int rowH = Clamp((colH - gap - capsIdealH - titleBar - P(6)) / n, Math.Min(kRowPref, kRowMin + P(6)), Math.Max(kRowPref, P(RowMax)));
                if (colH - gap - (titleBar + n * rowH + P(6)) < capsWantH)
                    rowH = Clamp((colH - gap - capsWantH - titleBar - P(6)) / n, kRowMin, rowH);
                if (colH - gap - (titleBar + n * rowH + P(6)) < capsMinH)
                    rowH = Math.Max(kRowMin, (colH - gap - capsMinH - titleBar - P(6)) / n);
                int dataH = titleBar + n * rowH + P(6);
                if (colH - gap - dataH >= capsMinH)
                {
                    Data = new DashRect(x, bTop, sideW, dataH);
                    RowH = rowH;
                    caps = PlaceCaps(new DashRect(x, Data.Bottom + gap, sideW, bBottom - (Data.Bottom + gap)), titleBar);
                }
            }
            if (!caps)
            {
                ResetCaps();
                Data = new DashRect(x, bTop, sideW, colH);
                RowH = n > 0 ? Math.Min(kRowPref, (colH - titleBar - P(6)) / n) : 0;
                // short page: the 按键 card goes to the right end of the terminal row instead (the terminal grows to
                // hold 2 rows of comfortable caps if the chart can spare it)
                int boxW = Clamp((int)(leftW * 0.36), P(170), P(260));
                if (!Term.IsEmpty && leftW - boxW - gap >= P(300))
                {
                    int needH = titleBar + P(8) + 2 * P(WantCap) + cg;
                    if (Term.H < needH)
                    {
                        int grow = needH - Term.H;
                        if (Chart.H - grow - titleBar >= P(MinPlot))
                        {
                            Chart.H -= grow;
                            Term = new DashRect(pad, Chart.Bottom + gap, leftW, Math.Max(0, bBottom - (Chart.Bottom + gap)));
                        }
                    }
                    if (PlaceCaps(new DashRect(pad + leftW - boxW, Term.Y, boxW, Term.H), titleBar))
                        Term = new DashRect(pad, Term.Y, leftW - boxW - gap, Term.H);
                    else ResetCaps();
                }
            }
            return Math.Min(Chart.W - 2, Chart.H - titleBar - 1);
        }

        /// <summary>Chart on top, 实时数据 (1-2 columns) under it, terminal (+ 按键 when wide enough) at the bottom.</summary>
        private int ArrangeNarrow()
        {
            ResetCaps();
            int pad = Pad, gap = Gap, titleBar = kTitleBar, cw = bW, bodyH = bH;
            int termH = Clamp((int)Math.Round(bodyH * 0.26), kTermMin, P(170));
            Columns = (cw - P(24)) >= 2 * P(190) + P(16) ? 2 : 1;
            int rowH = kRowMin + P(2);
            int n = RowCount, dataH = 0, chartH = 0;
            for (; ; )
            {
                dataH = titleBar + ((n + Columns - 1) / Columns) * rowH + P(8);
                chartH = bodyH - termH - dataH - 2 * gap;
                if (chartH >= P(130) || n <= 3) break;
                n--;
            }
            if (chartH < P(40))
            {   // a tiny page: give the chart what the terminal can spare, never go negative
                int spare = termH - kTermMin;
                if (spare > 0) { int take = Math.Min(spare, P(40) - chartH); termH -= take; chartH += take; }
                if (chartH < 0) { termH = Math.Max(0, termH + chartH); chartH = 0; }
                if (bodyH - termH - chartH - 2 * gap < dataH) dataH = Math.Max(0, bodyH - termH - chartH - 2 * gap);
                if (dataH < titleBar + rowH) n = 0;
            }
            Chart = new DashRect(pad, bTop, cw, chartH);
            Data = new DashRect(pad, Chart.Bottom + gap, cw, dataH);
            RowsShown = n;
            RowH = rowH;
            int ty = Data.Bottom + gap;
            int th = Math.Max(0, bBottom - ty);
            int capsW = (int)Math.Round(cw * 0.40);
            bool caps = cw - capsW - gap >= P(220) && PlaceCaps(new DashRect(pad + cw - capsW, ty, capsW, th), titleBar);
            if (!caps) ResetCaps();
            Term = new DashRect(pad, ty, caps ? cw - capsW - gap : cw, th);
            return Math.Min(Chart.W - 2, Chart.H - titleBar - 1);
        }

        /// <summary>Places the 按键 card in box (title bar + caps). False (and nothing placed) when the caps would be under MinCap.</summary>
        private bool PlaceCaps(DashRect box, int titleBar)
        {
            int cg = P(6);
            DashRect inner = new DashRect(box.X + P(10), box.Y + titleBar, box.W - P(20), box.H - titleBar - P(8));
            // A: [Q][W][E] / [A][S][D] / [Shift][Space] / [LMB][RMB]    (3 caps wide, 3.5 caps tall)
            int csA = (int)Math.Floor(Math.Min((inner.W - 2 * cg) / 3.0, (inner.H - 3 * cg) / 3.5));
            // B: [Q][W][E]  [Shift][Space] / [A][S][D]  [LMB][RMB]  (5.5 caps wide, 2 caps tall)
            int csB = (int)Math.Floor(Math.Min((inner.W - 5 * cg) / 5.5, (inner.H - cg) / 2.0));
            bool two = csB > csA;
            int cs = Math.Min(two ? csB : csA, P(MaxCap));
            if (cs < P(MinCap) || inner.IsEmpty) return false;
            Caps = box; CapsInner = inner;
            CapsTitle = new DashRect(box.X + P(10), box.Y, box.W - P(20), titleBar);
            CapsShown = true; CapsTwoRows = two; CapSize = cs;
            int sh = Math.Max(P(MinCap) * 3 / 4, cs * 3 / 4);
            int comboH = LineH + P(6);
            bool combo;
            if (!two)
            {
                int bw = 3 * cs + 2 * cg, bh = 2 * cs + 2 * sh + 3 * cg;
                combo = inner.H - bh >= comboH + P(14);
                int x0 = inner.X + (inner.W - bw) / 2, y0 = inner.Y + TopGap(inner.H - bh - (combo ? comboH + P(8) : 0)); // under the title, not floating mid-card
                CapsCombo = combo ? new DashRect(inner.X, y0 + bh + P(8), inner.W, comboH) : new DashRect(0, 0, 0, 0);
                CapRects[4] = new DashRect(x0, y0, cs, cs);                         // Q
                CapRects[0] = new DashRect(x0 + cs + cg, y0, cs, cs);               // W
                CapRects[5] = new DashRect(x0 + 2 * (cs + cg), y0, cs, cs);         // E
                int y1 = y0 + cs + cg;
                CapRects[1] = new DashRect(x0, y1, cs, cs);                         // A
                CapRects[2] = new DashRect(x0 + cs + cg, y1, cs, cs);               // S
                CapRects[3] = new DashRect(x0 + 2 * (cs + cg), y1, cs, cs);         // D
                int y2 = y1 + cs + cg;
                int half = (bw - cg) / 2;
                CapRects[9] = new DashRect(x0, y2, half, sh);                       // Shift
                CapRects[6] = new DashRect(x0 + bw - half, y2, half, sh);           // Space
                int y3 = y2 + sh + cg;
                CapRects[7] = new DashRect(x0, y3, half, sh);                       // LMB
                CapRects[8] = new DashRect(x0 + bw - half, y3, half, sh);           // RMB
            }
            else
            {
                // right block (Space / LMB RMB) takes the spare width so 3-letter mouse labels fit (<= 2 caps each)
                int mw = Math.Min(2 * cs, (inner.W - (3 * cs + 4 * cg) - cg) / 2);
                if (mw < (int)Math.Floor(cs * 1.25)) mw = (int)Math.Floor(cs * 1.25);
                int rw = 2 * mw + cg;
                int bw = 3 * cs + 2 * cg + 2 * cg + rw, bh = 2 * cs + cg;
                combo = inner.H - bh >= comboH + P(14);
                int x0 = inner.X + (inner.W - bw) / 2, y0 = inner.Y + TopGap(inner.H - bh - (combo ? comboH + P(8) : 0)); // under the title, not floating mid-card
                CapsCombo = combo ? new DashRect(inner.X, y0 + bh + P(8), inner.W, comboH) : new DashRect(0, 0, 0, 0);
                int y1 = y0 + cs + cg;
                CapRects[4] = new DashRect(x0, y0, cs, cs);
                CapRects[0] = new DashRect(x0 + cs + cg, y0, cs, cs);
                CapRects[5] = new DashRect(x0 + 2 * (cs + cg), y0, cs, cs);
                CapRects[1] = new DashRect(x0, y1, cs, cs);
                CapRects[2] = new DashRect(x0 + cs + cg, y1, cs, cs);
                CapRects[3] = new DashRect(x0 + 2 * (cs + cg), y1, cs, cs);
                int xr = x0 + 3 * cs + 4 * cg;
                CapRects[9] = new DashRect(xr, y0, mw, cs);                         // Shift
                CapRects[6] = new DashRect(xr + mw + cg, y0, mw, cs);               // Space
                CapRects[7] = new DashRect(xr, y1, mw, cs);
                CapRects[8] = new DashRect(xr + mw + cg, y1, mw, cs);
            }
            return true;
        }

        /// <summary>Space above the caps block: a small fixed gap under the card title (spare height goes below the block).</summary>
        private int TopGap(int spare)
        {
            if (spare <= 0) return 0;
            return Math.Min(spare, P(6));
        }

        /// <summary>Where the 「屏幕中心」 tag goes for a text of tw x th px: in quadrant III, clear of both axes, the
        /// ring at the origin (outer edge ~12 units) and the X-axis number labels (which sit just under the axis).</summary>
        public DashRect CentreLabel(double cx, double cy, int tw, int th)
        {
            int padX = P(5), padY = P(2);
            int w = tw + 2 * padX, h = th + 2 * padY;
            int right = (int)Math.Floor(cx) - P(18);
            int top = (int)Math.Ceiling(cy) + P(22);
            return new DashRect(right - w, top, w, h);
        }

        private static int Ceil(double v) { return double.IsNaN(v) || v < 0 ? 0 : (int)Math.Ceiling(v); }

        private static int Clamp(int v, int lo, int hi)
        {
            if (hi < lo) hi = lo;
            return v < lo ? lo : (v > hi ? hi : v);
        }
    }

    /// <summary>Key names for the dashboard hint, key caps and terminal, built from the user's bindings.</summary>
    public static class DashKeyNames
    {
        /// <summary>Action per cap (DashKeys order); -1 = fixed W/A/S/D.</summary>
        public static readonly int[] CapAction = new int[]
        {
            -1, -1, -1, -1, KeyBindings.ActionLeanLeft, KeyBindings.ActionLeanRight, KeyBindings.ActionJump, KeyBindings.ActionFire, KeyBindings.ActionAds, -1
        };
        /// <summary>Short Chinese action names used on a cap when the key name does not fit / is not ASCII.</summary>
        public static readonly string[] CapFallback = new string[] { "W", "A", "S", "D", "侧左", "侧右", "跳跃", "开火", "开镜", "冲刺" };
        public static readonly string[] AsciiFallback = new string[] { "W", "A", "S", "D", "LEAN-L", "LEAN-R", "JUMP", "FIRE", "ADS", "Shift" };

        /// <summary>ASCII short name ("Q", "Ctrl+D", "LMB", "M4", "Num5", "LShift"), or null when there is none.</summary>
        public static string Ascii(int vk, int mods)
        {
            string k;
            switch (vk)
            {
                case 0: return null;
                case 0x01: k = "LMB"; break;
                case 0x02: k = "RMB"; break;
                case 0x04: k = "MMB"; break;
                case 0x05: k = "M4"; break;
                case 0x06: k = "M5"; break;
                case 0x14: k = "Caps"; break;
                case 0x25: k = "Left"; break;
                case 0x26: k = "Up"; break;
                case 0x27: k = "Right"; break;
                case 0x28: k = "Down"; break;
                case 0xA0: k = "LShift"; break;
                case 0xA1: k = "RShift"; break;
                case 0xA2: k = "LCtrl"; break;
                case 0xA3: k = "RCtrl"; break;
                case 0xA4: k = "LAlt"; break;
                case 0xA5: k = "RAlt"; break;
                default:
                    if (vk >= 0x60 && vk <= 0x69) { k = "Num" + (vk - 0x60).ToString(CultureInfo.InvariantCulture); break; }
                    k = KeyBindings.KeyName(vk);
                    break;
            }
            if (string.IsNullOrEmpty(k)) return null;
            for (int i = 0; i < k.Length; i++) if (k[i] < 0x20 || k[i] > 0x7E) return null;
            int m = KeyBindings.NormalizeMods(vk, mods);
            if (m == 0) return k;
            return ((m & KeyBindings.ModCtrl) != 0 ? "Ctrl+" : "") + ((m & KeyBindings.ModShift) != 0 ? "Shift+" : "")
                + ((m & KeyBindings.ModAlt) != 0 ? "Alt+" : "") + k;
        }

        /// <summary>Name for the Chinese hint line: mouse buttons as 左键 / 右键 / 中键 / 侧键1 / 侧键2, the rest as ComboName.</summary>
        public static string Hint(int vk, int mods)
        {
            string k;
            switch (vk)
            {
                case 0x01: k = "左键"; break;
                case 0x02: k = "右键"; break;
                case 0x04: k = "中键"; break;
                case 0x05: k = "侧键1"; break;
                case 0x06: k = "侧键2"; break;
                default: return KeyBindings.ComboName(vk, mods);
            }
            int m = KeyBindings.NormalizeMods(vk, mods);
            return ((m & KeyBindings.ModCtrl) != 0 ? "Ctrl+" : "") + ((m & KeyBindings.ModShift) != 0 ? "Shift+" : "")
                + ((m & KeyBindings.ModAlt) != 0 ? "Alt+" : "") + k;
        }

        /// <summary>Changes when any key shown on the dashboard is rebound (cheap: no allocation).</summary>
        public static int Signature(KeyBindings k)
        {
            if (k == null) return 0;
            int h = 17;
            for (int i = 4; i < CapAction.Length; i++)
            {
                int a = CapAction[i];
                if (a < 0) continue;
                h = unchecked(h * 31 + k.Get(a));
                h = unchecked(h * 31 + k.GetMods(a));
            }
            return h;
        }

        /// <summary>Label of cap i (DashKeys order): the ASCII key name, else the action name. ascii = false means the
        /// label is Chinese (draw it with the UI font, not the monospace one).</summary>
        public static string Cap(KeyBindings k, int i, out bool ascii)
        {
            ascii = true;
            if (i < 0 || i >= DashKeys.Count) return "";
            int a = CapAction[i];
            if (a < 0 || k == null) return DashKeys.Names[i];
            string n = Ascii(k.Get(a), k.GetMods(a));
            if (n != null) return n;
            ascii = false;
            return CapFallback[i];
        }

        /// <summary>Header hint, e.g. 「按 W A S D 移动 · Q / E 侧身 · Space 跳跃 · 左键开火 · 右键开镜，准星实时跟着动」.</summary>
        public static string HintLine(KeyBindings k)
        {
            if (k == null) return "按 W A S D 移动，准星实时跟着动";
            return "按 W A S D 移动 · " + Hint(k.Get(KeyBindings.ActionLeanLeft), k.GetMods(KeyBindings.ActionLeanLeft)) + " / "
                + Hint(k.Get(KeyBindings.ActionLeanRight), k.GetMods(KeyBindings.ActionLeanRight)) + " 侧身 · "
                + Hint(k.Get(KeyBindings.ActionJump), k.GetMods(KeyBindings.ActionJump)) + " 跳跃 · "
                + Hint(k.Get(KeyBindings.ActionFire), k.GetMods(KeyBindings.ActionFire)) + " 开火 · "
                + Hint(k.Get(KeyBindings.ActionAds), k.GetMods(KeyBindings.ActionAds)) + " 开镜，准星实时跟着动";
        }

        /// <summary>Key name per cap for the terminal (DashKeys order): W A S D, the bound ASCII names ("Ctrl+D", "M4")
        /// or the ASCII action name ("ADS") when a key has none, and Shift.</summary>
        public static string[] LogNames(KeyBindings k)
        {
            string[] n = new string[DashKeys.Count];
            for (int i = 0; i < DashKeys.Count; i++)
            {
                int a = CapAction[i];
                if (a < 0 || k == null) { n[i] = DashKeys.Names[i]; continue; }
                n[i] = Ascii(k.Get(a), k.GetMods(a)) ?? AsciiFallback[i];
            }
            return n;
        }

        /// <summary>Terminal try lines (two, so each fits the terminal at the minimum window):
        /// "> 试一试：W A S D 移动 | Q E 侧身 | Space 跳跃" and "> LMB 开火 | RMB 开镜 | Shift+W 冲刺".</summary>
        public static string[] TryLines(KeyBindings k)
        {
            string[] n = LogNames(k);
            return new string[] {
                "> 试一试：W A S D 移动 | " + n[4] + " " + n[5] + " 侧身 | " + n[6] + " 跳跃",
                "> " + n[7] + " 开火 | " + n[8] + " 开镜 | Shift+W 冲刺" };
        }
    }
}
