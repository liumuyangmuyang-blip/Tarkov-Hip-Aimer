﻿// Theme.cs -- dark "Tarkov" theme for Tarkov Hip Aimer -- by Leo.
// Drop-in, standalone. C# 5 / .NET Framework 4.8 / WinForms + System.Drawing only.
//
//   Theme.Apply(form)                          -> call at the END of a form's constructor
//   Theme.Header(title, subtitle, version)     -> header bar (Dock = Top); add it to the form
//   Theme.AppIcon()                            -> app.ico (or the drawn ring) for Form.Icon / NotifyIcon.Icon
//
// Controls whose Tag is a string starting with "theme:keep" are left untouched
// (e.g. colour-swatch buttons). Apply never changes Size, Location, Text, Dock,
// Anchor or fonts of existing controls.
//
// THEME_PURE_CHECK: when defined, only the pure colour / .ico maths is compiled
// (used by the Linux net8.0 self-test). The real app never defines it.

using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
#if !THEME_PURE_CHECK
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;
#endif

internal static class Theme
{
    // ------------------------------------------------------------------ palette (v4.0: dark terminal + neon)
    internal static readonly Color ColBackground = Color.FromArgb(0x0A, 0x0E, 0x11); // window, nav
    internal static readonly Color ColSurface    = Color.FromArgb(0x10, 0x16, 0x1B); // pages, group boxes
    internal static readonly Color ColInput      = Color.FromArgb(0x17, 0x20, 0x28); // buttons, text boxes, combos
    internal static readonly Color ColBorder     = Color.FromArgb(0x22, 0x33, 0x3B);
    internal static readonly Color ColText       = Color.FromArgb(0xD6, 0xE9, 0xE1);
    internal static readonly Color ColMuted      = Color.FromArgb(0x7A, 0x96, 0x8F); // >= 4.5:1 on every surface
    internal static readonly Color ColAccent     = Color.FromArgb(0x39, 0xFF, 0x8C); // neon green
    internal static readonly Color ColAccent2    = Color.FromArgb(0x00, 0xE5, 0xFF); // cyan
    internal static readonly Color ColWarn       = Color.FromArgb(0xFF, 0xB5, 0x47); // amber
    internal static readonly Color ColHeader     = Color.FromArgb(0x07, 0x0A, 0x0C); // a shade darker than background
    internal static readonly Color ColHover      = Color.FromArgb(0x1D, 0x2A, 0x33); // hover fill
    internal static readonly Color ColGrid       = Color.FromArgb(0x15, 0x23, 0x2A); // chart grid lines
    internal static readonly Color ColPressed    = Blend(ColInput, ColAccent, 0.25);  // pressed fill
    internal static readonly Color ColRingInner  = Color.FromArgb(0x00, 0xDF, 0x00);
    internal static readonly Color ColRingOuter  = Color.FromArgb(0x00, 0x00, 0x00);

    // ------------------------------------------------------- decode text effect (pure)
    private const string DecodeAscii = "01#%&*+=<>/\\$?7ABCDEFX";
    private const string DecodeWide = "０１＃％＆＊＋＝＜＞／＼＄？７ＡＢＣＤＥＦＸ";

    /// <summary>
    /// "Decoding" text effect: characters left of progress*length are the real text, the rest are scrambled glyphs of
    /// the same width class (full-width glyphs for CJK, ASCII for ASCII; spaces stay spaces). progress &lt;= 0 = all
    /// scrambled, &gt;= 1 = the text itself. Deterministic for a given seed. Never throws; null -> "".
    /// </summary>
    internal static string Decode(string text, double progress, int seed)
    {
        if (string.IsNullOrEmpty(text)) return "";
        if (double.IsNaN(progress) || progress >= 1) return text;
        if (progress < 0) progress = 0;
        int n = text.Length;
        int shown = (int)Math.Floor(progress * n);
        char[] r = text.ToCharArray();
        uint h = (uint)seed * 2654435761u + 12345u;
        for (int i = shown; i < n; i++)
        {
            char c = r[i];
            h = h * 1103515245u + 12345u;
            if (char.IsWhiteSpace(c) || char.IsSurrogate(c)) continue;
            int pick = (int)((h >> 8) % (uint)DecodeAscii.Length);
            r[i] = c > 0x2E7F ? DecodeWide[pick] : DecodeAscii[pick];
        }
        return new string(r);
    }

    internal const double MinContrast = 4.5;

    // ------------------------------------------------------------ colour maths
    internal static double Channel(int c)
    {
        double s = c / 255.0;
        return s <= 0.04045 ? s / 12.92 : Math.Pow((s + 0.055) / 1.055, 2.4);
    }

    /// <summary>WCAG relative luminance.</summary>
    internal static double Luminance(Color c)
    {
        return 0.2126 * Channel(c.R) + 0.7152 * Channel(c.G) + 0.0722 * Channel(c.B);
    }

    /// <summary>WCAG contrast ratio (1..21).</summary>
    internal static double Contrast(Color a, Color b)
    {
        double la = Luminance(a) + 0.05;
        double lb = Luminance(b) + 0.05;
        return la > lb ? la / lb : lb / la;
    }

    internal static Color Blend(Color a, Color b, double t)
    {
        if (t < 0) t = 0;
        if (t > 1) t = 1;
        return Color.FromArgb(
            (int)Math.Round(a.R + (b.R - a.R) * t),
            (int)Math.Round(a.G + (b.G - a.G) * t),
            (int)Math.Round(a.B + (b.B - a.B) * t));
    }

    /// <summary>Moves fg towards white (dark bg) or black (light bg) until it reaches min contrast.</summary>
    internal static Color EnsureContrast(Color fg, Color bg, double min)
    {
        Color opaque = Color.FromArgb(fg.R, fg.G, fg.B);
        if (Contrast(opaque, bg) >= min) return opaque;
        Color target = Luminance(bg) < 0.18 ? Color.White : Color.Black;
        for (int i = 1; i <= 20; i++)
        {
            Color c = Blend(opaque, target, i / 20.0);
            if (Contrast(c, bg) >= min) return c;
        }
        return target;
    }

    internal static bool IsGreyish(Color c)
    {
        int max = Math.Max(c.R, Math.Max(c.G, c.B));
        int min = Math.Min(c.R, Math.Min(c.G, c.B));
        return (max - min) <= 28 && max >= 90 && max <= 215;
    }

    internal static bool IsNearBlack(Color c)
    {
        int max = Math.Max(c.R, Math.Max(c.G, c.B));
        int min = Math.Min(c.R, Math.Min(c.G, c.B));
        return max < 90 && (max - min) < 40;
    }

    /// <summary>Text colour rule: black-ish -> text, grey hint -> muted, anything else kept but made readable.</summary>
    internal static Color MapForeground(Color fg, Color bg)
    {
        if (fg.A == 0 || IsNearBlack(fg)) return ColText;
        if (IsGreyish(fg)) return ColMuted;
        return EnsureContrast(fg, bg, MinContrast);
    }

    /// <summary>Background rule: transparent kept, light (old default) colours -> target, custom dark kept.</summary>
    internal static Color MapBackground(Color current, Color target, bool isSystemColor)
    {
        if (current.A == 0) return current;
        if (isSystemColor || Luminance(current) > 0.30) return target;
        return current;
    }

    // ------------------------------------------------------------- .ico writer
    /// <summary>Builds a multi-size 32bpp .ico. pixels[i] = top-down BGRA, sizes[i] x sizes[i].</summary>
    internal static byte[] BuildIco(IList<int> sizes, IList<byte[]> pixels)
    {
        int n = sizes.Count;
        List<byte[]> images = new List<byte[]>();
        for (int i = 0; i < n; i++) images.Add(BuildDib(sizes[i], pixels[i]));

        using (MemoryStream ms = new MemoryStream())
        using (BinaryWriter w = new BinaryWriter(ms))
        {
            w.Write((ushort)0);     // reserved
            w.Write((ushort)1);     // type = icon
            w.Write((ushort)n);     // count
            int offset = 6 + 16 * n;
            for (int i = 0; i < n; i++)
            {
                int s = sizes[i];
                w.Write((byte)(s >= 256 ? 0 : s));
                w.Write((byte)(s >= 256 ? 0 : s));
                w.Write((byte)0);   // palette colours
                w.Write((byte)0);   // reserved
                w.Write((ushort)1); // planes
                w.Write((ushort)32);// bpp
                w.Write(images[i].Length);
                w.Write(offset);
                offset += images[i].Length;
            }
            for (int i = 0; i < n; i++) w.Write(images[i]);
            w.Flush();
            return ms.ToArray();
        }
    }

    private static byte[] BuildDib(int s, byte[] bgraTopDown)
    {
        int xorSize = s * s * 4;
        int maskStride = ((s + 31) / 32) * 4;
        int maskSize = maskStride * s;
        using (MemoryStream ms = new MemoryStream())
        using (BinaryWriter w = new BinaryWriter(ms))
        {
            w.Write(40);            // biSize
            w.Write(s);             // biWidth
            w.Write(s * 2);         // biHeight (XOR + AND)
            w.Write((ushort)1);     // planes
            w.Write((ushort)32);    // bit count
            w.Write(0);             // BI_RGB
            w.Write(xorSize + maskSize);
            w.Write(0); w.Write(0); w.Write(0); w.Write(0);
            for (int y = s - 1; y >= 0; y--) w.Write(bgraTopDown, y * s * 4, s * 4); // bottom-up
            byte[] mask = new byte[maskSize];
            for (int y = 0; y < s; y++)
            {
                int row = s - 1 - y; // bottom-up
                for (int x = 0; x < s; x++)
                {
                    if (bgraTopDown[(y * s + x) * 4 + 3] == 0)
                        mask[row * maskStride + (x >> 3)] |= (byte)(0x80 >> (x & 7));
                }
            }
            w.Write(mask);
            w.Flush();
            return ms.ToArray();
        }
    }

#if !THEME_PURE_CHECK
    // ================================================================ public API

    /// <summary>Restyles the form and its whole control tree (incl. controls added later). Never throws.</summary>
    public static void Apply(Form f)
    {
        if (f == null) return;
        try
        {
            try { f.BackColor = ColBackground; } catch { }
            try { f.ForeColor = ColText; } catch { }
            try { HookDarkTitleBar(f); } catch { }
            try { HookAdded(f); } catch { }
            Control[] kids = Children(f);
            for (int i = 0; i < kids.Length; i++) ApplyControl(kids[i], ColBackground);
        }
        catch { }
    }

    /// <summary>Header bar: ring icon, decoding title, muted subtitle, version on the right, scanlines. Dock = Top.</summary>
    public static Control Header(string title, string subtitle, string version)
    {
        return new HeaderPanel(title ?? "", subtitle ?? "", version ?? "");
    }

    /// <summary>Applies the window's UiScale to a header made by Header() (no-op for other controls).</summary>
    public static void SetHeaderScale(Control header, double scale)
    {
        HeaderPanel h = header as HeaderPanel;
        if (h != null) h.UiScaleFactor = scale;
    }

    /// <summary>
    /// StyleToolTip for every ToolTip field of a control the caller does not own (e.g. the 外观 page's StylePanel keeps
    /// its ToolTip private): fields found by reflection; ones already owner-drawn are left alone. Returns how many.
    /// </summary>
    public static int StyleToolTips(object owner, Func<Font> font)
    {
        int n = 0;
        if (owner == null || font == null) return 0;
        try
        {
            foreach (FieldInfo fi in owner.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
            {
                if (!typeof(ToolTip).IsAssignableFrom(fi.FieldType)) continue;
                ToolTip t = fi.GetValue(owner) as ToolTip;
                if (t == null || t.OwnerDraw) continue;
                StyleToolTip(t, font);
                n++;
            }
        }
        catch { }
        return n;
    }

    /// <summary>
    /// Dark, readable tooltips (SPEC v4: text >= 11 pt; the stock tooltip uses the ~9 pt system font): owner-drawn with
    /// font() (the caller's current UI font, so it follows the window's text size), wrapped at about 22 CJK characters.
    /// </summary>
    public static void StyleToolTip(ToolTip tip, Func<Font> font)
    {
        if (tip == null || font == null || tip.OwnerDraw) return; // already styled: never hook twice
        try
        {
            tip.OwnerDraw = true;
            tip.BackColor = ColInput;
            tip.ForeColor = ColText;
            const TextFormatFlags flags = TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix | TextFormatFlags.Left;
            tip.Popup += delegate(object s, PopupEventArgs e)
            {
                try
                {
                    Font f = font();
                    string text = tip.GetToolTip(e.AssociatedControl) ?? "";
                    int pad = Math.Max(4, f.Height / 3);
                    int maxW = f.Height * 23; // ~22 CJK characters per line
                    Size ts = TextRenderer.MeasureText(text, f, new Size(maxW, 0), flags);
                    e.ToolTipSize = new Size(ts.Width + 2 * pad + 2, ts.Height + 2 * pad + 2);
                }
                catch { }
            };
            tip.Draw += delegate(object s, DrawToolTipEventArgs e)
            {
                try
                {
                    Font f = font();
                    int pad = Math.Max(4, f.Height / 3);
                    Rectangle r = e.Bounds;
                    using (SolidBrush b = new SolidBrush(ColInput)) e.Graphics.FillRectangle(b, r);
                    using (Pen p = new Pen(Blend(ColBorder, ColAccent2, 0.6))) e.Graphics.DrawRectangle(p, r.X, r.Y, r.Width - 1, r.Height - 1);
                    Rectangle tr = new Rectangle(r.X + pad + 1, r.Y + pad + 1, Math.Max(1, r.Width - 2 * pad - 2), Math.Max(1, r.Height - 2 * pad - 2));
                    TextRenderer.DrawText(e.Graphics, e.ToolTipText ?? "", f, tr, ColText, flags);
                }
                catch { e.DrawBackground(); e.DrawText(); }
            };
        }
        catch { }
    }

    /// <summary>Monospace font for numbers / terminal text (Cascadia Mono, Consolas, else generic). Caller disposes.</summary>
    public static Font Mono(float pt) { return Mono(pt, FontStyle.Regular); }

    public static Font Mono(float pt, FontStyle style)
    {
        string[] names = { "Cascadia Mono", "Consolas", "Lucida Console" };
        foreach (string n in names)
        {
            try
            {
                Font f = new Font(n, pt, style);
                if (string.Equals(f.Name, n, StringComparison.OrdinalIgnoreCase)) return f;
                f.Dispose();
            }
            catch { }
        }
        return new Font(FontFamily.GenericMonospace, pt, style);
    }

    /// <summary>UI font (Microsoft YaHei UI, else the system message font). Caller disposes.</summary>
    public static Font Ui(float pt) { return Ui(pt, FontStyle.Regular); }

    public static Font Ui(float pt, FontStyle style)
    {
        try
        {
            Font f = new Font("Microsoft YaHei UI", pt, style);
            if (f.Name == "Microsoft YaHei UI") return f;
            f.Dispose();
        }
        catch { }
        return new Font(SystemFonts.MessageBoxFont.FontFamily, pt, style);
    }

    /// <summary>False when Windows animations are turned off: draw the final frame straight away.</summary>
    public static bool AnimationsOn
    {
        get
        {
            try { return SystemInformation.UIEffectsEnabled; } catch { return true; }
        }
    }

    /// <summary>Subtle CRT scanlines (1 px dark line every 3 px).</summary>
    public static void DrawScanlines(Graphics g, Rectangle r, int alpha)
    {
        if (g == null || r.Width <= 0 || r.Height <= 0 || alpha <= 0) return;
        using (Pen p = new Pen(Color.FromArgb(Math.Min(255, alpha), 0, 0, 0)))
            for (int y = r.Top; y < r.Bottom; y += 3) g.DrawLine(p, r.Left, y, r.Right - 1, y);
    }

    /// <summary>Accent -> transparent horizontal hairline (section underline).</summary>
    public static void DrawFadeLine(Graphics g, int x, int y, int w, int h, Color c)
    {
        if (g == null || w <= 1 || h <= 0) return;
        Rectangle r = new Rectangle(x, y, w, h);
        using (LinearGradientBrush b = new LinearGradientBrush(new Rectangle(x - 1, y, w + 2, h), c, Color.FromArgb(0, c), LinearGradientMode.Horizontal))
            g.FillRectangle(b, r);
    }

    /// <summary>App icon: app.ico next to the exe (multi-size 16..256, v3.0); fallback the drawn two-tone ring
    /// (16..64 px inside). Caller owns (and may Dispose) the result.</summary>
    public static Icon AppIcon()
    {
        try
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "app.ico");
            if (File.Exists(path))
            {
                byte[] file = File.ReadAllBytes(path);
                using (MemoryStream ms = new MemoryStream(file)) return new Icon(ms);
            }
        }
        catch { }
        try
        {
            byte[] ico = IconBytes();
            using (MemoryStream ms = new MemoryStream(ico)) return new Icon(ms);
        }
        catch { }
        try { return HiconIcon(32); } catch { }
        try { return (Icon)SystemIcons.Application.Clone(); } catch { }
        return null;
    }

    // ============================================================ tree walking
    private static readonly object Marker = new object();
    private static readonly ConditionalWeakTable<Control, object> AddedHooked = new ConditionalWeakTable<Control, object>();
    private static readonly ConditionalWeakTable<Control, object> PaintHooked = new ConditionalWeakTable<Control, object>();
    private static readonly ConditionalWeakTable<Control, object> TitleHooked = new ConditionalWeakTable<Control, object>();

    private static bool MarkOnce(ConditionalWeakTable<Control, object> table, Control c)
    {
        object o;
        if (table.TryGetValue(c, out o)) return false;
        table.Add(c, Marker);
        return true;
    }

    private static Control[] Children(Control c)
    {
        Control[] arr = new Control[c.Controls.Count];
        c.Controls.CopyTo(arr, 0);
        return arr;
    }

    private static bool IsKeep(Control c)
    {
        string s = c.Tag as string;
        return s != null && s.StartsWith("theme:keep", StringComparison.Ordinal);
    }

    private static bool CanRecurse(Control c)
    {
        return !(c is UpDownBase || c is TextBoxBase || c is ComboBox || c is ListControl ||
                 c is ButtonBase || c is Label || c is TrackBar || c is DataGridView ||
                 c is DateTimePicker || c is ScrollBar || c is WebBrowser || c is PropertyGrid ||
                 c is HeaderPanel);
    }

    private static Color EffectiveBack(Control c, Color fallback)
    {
        Color b = c.BackColor;
        return b.A < 255 ? fallback : b;
    }

    private static Color EffectiveBackUp(Control c)
    {
        while (c != null)
        {
            Color b = c.BackColor;
            if (b.A == 255) return b;
            c = c.Parent;
        }
        return ColBackground;
    }

    private static void HookAdded(Control c)
    {
        if (!MarkOnce(AddedHooked, c)) return;
        c.ControlAdded += OnControlAdded;
    }

    private static void OnControlAdded(object sender, ControlEventArgs e)
    {
        try
        {
            Control p = sender as Control;
            if (e == null || e.Control == null) return;
            ApplyControl(e.Control, p == null ? ColBackground : EffectiveBackUp(p));
        }
        catch { }
    }

    private static void ApplyControl(Control c, Color parentBack)
    {
        if (c == null) return;
        if (!IsKeep(c))
        {
            try { StyleControl(c, parentBack); } catch { }
        }
        try
        {
            if (!CanRecurse(c)) return;
            HookAdded(c);
            Color mine = EffectiveBack(c, parentBack);
            Control[] kids = Children(c);
            for (int i = 0; i < kids.Length; i++) ApplyControl(kids[i], mine);
        }
        catch { }
    }

    // ======================================================== per-type styling
    private static void StyleControl(Control c, Color parentBack)
    {
        if (c is HeaderPanel) return;

        if (c is Form)                // non-top-level / MDI child forms
        {
            c.BackColor = ColBackground;
            c.ForeColor = ColText;
            return;
        }
        TabControl tc = c as TabControl;
        if (tc != null) { StyleTabControl(tc); return; }

        TabPage tp = c as TabPage;
        if (tp != null)
        {
            tp.UseVisualStyleBackColor = false;
            tp.BackColor = ColSurface;
            tp.ForeColor = ColText;
            return;
        }
        GroupBox gb = c as GroupBox;
        if (gb != null) { StyleGroupBox(gb); return; }

        LinkLabel ll = c as LinkLabel;
        if (ll != null)
        {
            ll.LinkColor = ColAccent;
            ll.VisitedLinkColor = ColAccent;
            ll.ActiveLinkColor = Blend(ColAccent, Color.White, 0.3);
            ll.DisabledLinkColor = ColMuted;
            StyleLabel(ll, parentBack);
            return;
        }
        Label lb = c as Label;
        if (lb != null) { StyleLabel(lb, parentBack); return; }

        Button bt = c as Button;
        if (bt != null) { StyleButton(bt); return; }

        if (c is CheckBox || c is RadioButton)
        {
            c.BackColor = MapBackground(c.BackColor, parentBack, c.BackColor.IsSystemColor);
            c.ForeColor = MapForeground(c.ForeColor, EffectiveBack(c, parentBack));
            ButtonBase bb = (ButtonBase)c;
            Preserve(c, delegate { bb.FlatStyle = FlatStyle.Flat; }); // dark box instead of the white system box
            bb.FlatAppearance.BorderColor = ColMuted;
            bb.FlatAppearance.CheckedBackColor = Blend(ColInput, ColAccent, 0.35);
            bb.FlatAppearance.MouseOverBackColor = ColHover;
            bb.FlatAppearance.MouseDownBackColor = ColPressed;
            bb.Cursor = Cursors.Hand;
            return;
        }
        RichTextBox rtb = c as RichTextBox;
        if (rtb != null)
        {
            rtb.BackColor = ColInput;
            rtb.ForeColor = ColText;
            Preserve(rtb, delegate { rtb.BorderStyle = BorderStyle.FixedSingle; });
            return;
        }
        TextBox tb = c as TextBox;
        if (tb != null)
        {
            tb.BackColor = ColInput;
            tb.ForeColor = ColText;
            Preserve(tb, delegate { tb.BorderStyle = BorderStyle.FixedSingle; });
            return;
        }
        UpDownBase ud = c as UpDownBase;   // NumericUpDown, DomainUpDown
        if (ud != null)
        {
            ud.BackColor = ColInput;
            ud.ForeColor = ColText;
            Preserve(ud, delegate { ud.BorderStyle = BorderStyle.FixedSingle; });
            return;
        }
        ComboBox cb = c as ComboBox;
        if (cb != null)
        {
            Preserve(cb, delegate { cb.FlatStyle = FlatStyle.Flat; });
            cb.BackColor = ColInput;
            cb.ForeColor = ColText;
            // Owner-drawn items: the height follows the font at every DPI (a fixed system height clipped the text in
            // the 200 % render) and the selection uses the theme instead of system blue.
            if (cb.DropDownStyle == ComboBoxStyle.DropDownList && cb.DrawMode == DrawMode.Normal && MarkOnce(PaintHooked, cb))
            {
                cb.DrawMode = DrawMode.OwnerDrawFixed;
                cb.ItemHeight = cb.Font.Height + Px(cb, 6);
                try { cb.Height = cb.ItemHeight + Px(cb, 6); } catch { } // Windows derives it from ItemHeight anyway; Mono needs it
                cb.DrawItem += OnComboDrawItem;
                cb.FontChanged += delegate(object s, EventArgs e2) { try { cb.ItemHeight = cb.Font.Height + Px(cb, 6); } catch { } };
            }
            return;
        }
        ListBox lbx = c as ListBox;
        if (lbx != null)
        {
            lbx.BackColor = ColInput;
            lbx.ForeColor = ColText;
            return;
        }
        TrackBar trk = c as TrackBar;      // TrackBar does not accept Transparent
        if (trk != null)
        {
            trk.BackColor = parentBack;
            return;
        }
        if (c is Panel || c is UserControl || c is SplitContainer)
        {
            // Panel, TableLayoutPanel, FlowLayoutPanel, SplitterPanel, UserControl
            c.BackColor = MapBackground(c.BackColor, parentBack, c.BackColor.IsSystemColor);
            if (c.ForeColor.IsSystemColor || IsNearBlack(c.ForeColor)) c.ForeColor = ColText;
            return;
        }
        // Unknown control types (e.g. a custom preview canvas) are left alone on purpose.
    }

    private static void OnComboDrawItem(object sender, DrawItemEventArgs e)
    {
        try
        {
            ComboBox cb = sender as ComboBox;
            if (cb == null) return;
            bool edit = (e.State & DrawItemState.ComboBoxEdit) != 0;
            bool sel = (e.State & DrawItemState.Selected) != 0 && !edit;
            Color back = sel ? Blend(ColInput, ColAccent, 0.22) : ColInput;
            using (SolidBrush b = new SolidBrush(back)) e.Graphics.FillRectangle(b, e.Bounds);
            if (e.Index < 0 || e.Index >= cb.Items.Count) return;
            string text = cb.GetItemText(cb.Items[e.Index]);
            Color fg = !cb.Enabled ? ColMuted : (sel ? ColAccent : ColText);
            Rectangle r = new Rectangle(e.Bounds.X + Px(cb, 4), e.Bounds.Y, Math.Max(0, e.Bounds.Width - Px(cb, 6)), e.Bounds.Height);
            TextRenderer.DrawText(e.Graphics, text, cb.Font, r, fg,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
        }
        catch { }
    }

    private static void StyleLabel(Label lb, Color parentBack)
    {
        lb.BackColor = MapBackground(lb.BackColor, parentBack, lb.BackColor.IsSystemColor);
        lb.ForeColor = MapForeground(lb.ForeColor, EffectiveBack(lb, parentBack));
    }

    private static bool IsAccent(Control c)
    {
        string s = c.Tag as string;
        return s != null && s.StartsWith("theme:accent", StringComparison.Ordinal);
    }

    private static Color RestBorder(Button b) { return IsAccent(b) ? Blend(ColBorder, ColAccent, 0.6) : ColBorder; }

    private static void StyleButton(Button b)
    {
        Color fg = b.ForeColor;
        bool accent = IsAccent(b);
        Preserve(b, delegate
        {
            b.UseVisualStyleBackColor = false;
            b.FlatStyle = FlatStyle.Flat;
        });
        b.BackColor = accent ? Blend(ColInput, ColAccent, 0.10) : ColInput;
        b.ForeColor = accent ? ColAccent : MapForeground(fg, ColInput);
        b.Cursor = Cursors.Hand;
        b.FlatAppearance.BorderSize = 1;
        b.FlatAppearance.BorderColor = RestBorder(b);
        b.FlatAppearance.MouseOverBackColor = accent ? Blend(ColInput, ColAccent, 0.18) : ColHover;
        b.FlatAppearance.MouseDownBackColor = ColPressed;
        if (MarkOnce(PaintHooked, b))
        {
            b.MouseEnter += OnButtonEnter;
            b.MouseLeave += OnButtonLeave;
            b.MouseDown += OnButtonEnter;
            b.EnabledChanged += OnButtonLeave;
        }
    }

    private static void OnButtonEnter(object sender, EventArgs e)
    {
        try
        {
            Button b = sender as Button;
            if (b != null && b.Enabled) b.FlatAppearance.BorderColor = ColAccent;
        }
        catch { }
    }

    private static void OnButtonLeave(object sender, EventArgs e)
    {
        try
        {
            Button b = sender as Button;
            if (b != null) b.FlatAppearance.BorderColor = RestBorder(b);
        }
        catch { }
    }

    /// <summary>Runs a style change and puts Location/Size back if the change moved them.</summary>
    private static void Preserve(Control c, Action change)
    {
        Point loc = c.Location;
        Size size = c.Size;
        change();
        try
        {
            if (c.Dock == DockStyle.None)
            {
                if (c.Location != loc) c.Location = loc;
                if (c.Size != size) c.Size = size;
            }
        }
        catch { }
    }

    private static bool TrySetStyle(Control c, ControlStyles styles, bool value)
    {
        try
        {
            MethodInfo m = typeof(Control).GetMethod("SetStyle", BindingFlags.NonPublic | BindingFlags.Instance);
            if (m == null) return false;
            m.Invoke(c, new object[] { styles, value });
            return true;
        }
        catch { return false; }
    }

    private static int Px(Control c, int px)
    {
        int dpi = 96;
        try { dpi = c.DeviceDpi; } catch { }
        if (dpi <= 0) dpi = 96;
        return (int)Math.Round(px * dpi / 96.0);
    }

    // ---------------------------------------------------------------- GroupBox
    private static void StyleGroupBox(GroupBox gb)
    {
        if (gb.FlatStyle == FlatStyle.System) gb.FlatStyle = FlatStyle.Standard; // System skips OnPaint
        gb.BackColor = ColSurface;
        gb.ForeColor = ColText;
        if (MarkOnce(PaintHooked, gb))
        {
            TrySetStyle(gb, ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint | ControlStyles.ResizeRedraw, true);
            gb.Paint += OnGroupBoxPaint;
        }
        gb.Invalidate();
    }

    private static void OnGroupBoxPaint(object sender, PaintEventArgs e)
    {
        try
        {
            GroupBox gb = sender as GroupBox;
            if (gb == null || gb.Width < 2 || gb.Height < 2) return;
            Graphics g = e.Graphics;
            Color back = EffectiveBack(gb, ColSurface);
            using (SolidBrush b = new SolidBrush(back)) g.FillRectangle(b, gb.ClientRectangle);

            string text = gb.Text;
            bool hasText = !string.IsNullOrEmpty(text);
            Font font = gb.Font;
            int top = hasText ? font.Height / 2 : 0;
            Rectangle box = new Rectangle(0, top, gb.Width - 1, Math.Max(1, gb.Height - top - 1));
            using (Pen p = new Pen(ColBorder)) g.DrawRectangle(p, box);

            if (hasText)
            {
                TextFormatFlags flags = TextFormatFlags.SingleLine | TextFormatFlags.NoPadding | TextFormatFlags.EndEllipsis;
                int x = Px(gb, 8);
                int maxW = Math.Max(0, gb.Width - 2 * x);
                Size ts = TextRenderer.MeasureText(g, text, font, new Size(maxW, font.Height), flags);
                int w = Math.Min(ts.Width, maxW);
                using (SolidBrush b = new SolidBrush(back))
                    g.FillRectangle(b, new Rectangle(x - Px(gb, 3), 0, w + Px(gb, 6), font.Height));
                TextRenderer.DrawText(g, text, font, new Rectangle(x, 0, w, font.Height),
                    gb.Enabled ? ColAccent2 : ColMuted, flags);
                // corner ticks: a terminal-frame feel without extra lines
                int tick = Px(gb, 10);
                using (Pen ap = new Pen(Blend(ColBorder, ColAccent2, 0.7)))
                {
                    g.DrawLine(ap, 0, top, 0, top + tick);
                    g.DrawLine(ap, box.Right, box.Bottom, box.Right, box.Bottom - tick);
                    g.DrawLine(ap, box.Right, box.Bottom, box.Right - tick, box.Bottom);
                }
            }
        }
        catch { }
    }

    // -------------------------------------------------------------- TabControl
    // Preferred: switch the TabControl to UserPaint (via reflection) so the whole
    // control -- tab headers AND the empty strip behind them -- is drawn by us.
    // Fallback (if SetStyle can't be reached): OwnerDrawFixed headers only; the
    // empty strip area then stays system-coloured.
    private static void StyleTabControl(TabControl tc)
    {
        if (!MarkOnce(PaintHooked, tc)) { tc.Invalidate(); return; }
        bool userPaint = TrySetStyle(tc,
            ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
            ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        if (userPaint)
        {
            tc.Paint += OnTabPaint;
        }
        else
        {
            tc.DrawMode = TabDrawMode.OwnerDrawFixed;
            tc.DrawItem += OnTabDrawItem;
        }
        tc.Invalidate();
    }

    private static void OnTabPaint(object sender, PaintEventArgs e)
    {
        try
        {
            TabControl tc = sender as TabControl;
            if (tc == null) return;
            Graphics g = e.Graphics;
            using (SolidBrush b = new SolidBrush(ColBackground)) g.FillRectangle(b, tc.ClientRectangle);

            Rectangle page = tc.DisplayRectangle;
            page.Inflate(2, 2);
            page.Intersect(tc.ClientRectangle);
            using (SolidBrush b = new SolidBrush(ColSurface)) g.FillRectangle(b, page);
            using (Pen p = new Pen(ColBorder))
                g.DrawRectangle(p, page.X, page.Y, Math.Max(0, page.Width - 1), Math.Max(0, page.Height - 1));

            for (int i = 0; i < tc.TabCount; i++)
            {
                Rectangle r = tc.GetTabRect(i);
                if (r.Width <= 0 || r.Height <= 0) continue;
                DrawTab(g, tc, i, r, i == tc.SelectedIndex, page);
            }
        }
        catch { }
    }

    private static void OnTabDrawItem(object sender, DrawItemEventArgs e)
    {
        try
        {
            TabControl tc = sender as TabControl;
            if (tc == null || e.Index < 0 || e.Index >= tc.TabCount) return;
            DrawTab(e.Graphics, tc, e.Index, e.Bounds, e.Index == tc.SelectedIndex, Rectangle.Empty);
        }
        catch { }
    }

    private static void DrawTab(Graphics g, TabControl tc, int index, Rectangle r, bool selected, Rectangle page)
    {
        bool top = tc.Alignment == TabAlignment.Top;
        Rectangle fill = r;
        if (selected && top && !page.IsEmpty)
            fill = new Rectangle(r.X, r.Y, r.Width, Math.Max(r.Height, page.Y - r.Y + 1)); // merge into page

        using (SolidBrush b = new SolidBrush(selected ? ColSurface : ColBackground)) g.FillRectangle(b, fill);
        using (Pen p = new Pen(ColBorder))
        {
            if (top)
            {
                g.DrawLine(p, fill.Left, fill.Bottom - 1, fill.Left, fill.Top);
                g.DrawLine(p, fill.Left, fill.Top, fill.Right - 1, fill.Top);
                g.DrawLine(p, fill.Right - 1, fill.Top, fill.Right - 1, fill.Bottom - 1);
            }
            else
            {
                g.DrawRectangle(p, fill.X, fill.Y, Math.Max(0, fill.Width - 1), Math.Max(0, fill.Height - 1));
            }
        }
        if (selected)
        {
            int bar = Math.Max(2, Px(tc, 2));
            using (SolidBrush b = new SolidBrush(ColAccent))
                g.FillRectangle(b, new Rectangle(r.X, r.Y, r.Width, bar));
        }
        string text = tc.TabPages[index].Text;
        TextRenderer.DrawText(g, text, tc.Font, r, selected ? ColAccent : ColMuted,
            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter |
            TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis);
    }

    // ------------------------------------------------------- dark title bar
    [DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int size);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool DestroyIcon(IntPtr hIcon);

    private static void HookDarkTitleBar(Form f)
    {
        if (f.IsHandleCreated) DarkTitleBar(f.Handle);
        if (MarkOnce(TitleHooked, f)) f.HandleCreated += OnFormHandleCreated; // handle can be recreated
    }

    private static void OnFormHandleCreated(object sender, EventArgs e)
    {
        try
        {
            Form f = sender as Form;
            if (f != null) DarkTitleBar(f.Handle);
        }
        catch { }
    }

    private static void DarkTitleBar(IntPtr hwnd)
    {
        if (hwnd == IntPtr.Zero) return;
        int on = 1;
        int hr = -1;
        try { hr = DwmSetWindowAttribute(hwnd, 20, ref on, 4); } catch { } // DWMWA_USE_IMMERSIVE_DARK_MODE (20H1+)
        if (hr != 0)
        {
            try { DwmSetWindowAttribute(hwnd, 19, ref on, 4); } catch { }  // pre-20H1 value
        }
    }

    // ---------------------------------------------------------------- ring art
    /// <summary>Two-tone ring fitted in bounds: black outline under a green ring.</summary>
    internal static void DrawRing(Graphics g, RectangleF bounds)
    {
        float s = Math.Min(bounds.Width, bounds.Height);
        if (s < 4) return;
        float o = Math.Max(1f, (float)Math.Round(s / 16f));      // black outline width each side
        float w = Math.Max(2f, (float)Math.Round(s * 0.14f));    // green stroke
        float bw = w + 2 * o;
        float rad = s / 2f - bw / 2f;
        float cx = bounds.X + bounds.Width / 2f;
        float cy = bounds.Y + bounds.Height / 2f;
        RectangleF circle = new RectangleF(cx - rad, cy - rad, rad * 2, rad * 2);

        SmoothingMode oldSm = g.SmoothingMode;
        PixelOffsetMode oldPo = g.PixelOffsetMode;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.PixelOffsetMode = PixelOffsetMode.HighQuality;
        using (Pen outer = new Pen(ColRingOuter, bw))
        using (Pen inner = new Pen(ColRingInner, w))
        {
            g.DrawEllipse(outer, circle);
            g.DrawEllipse(inner, circle);
        }
        g.SmoothingMode = oldSm;
        g.PixelOffsetMode = oldPo;
    }

    private static Bitmap RenderRing(int size)
    {
        Bitmap bmp = new Bitmap(size, size, PixelFormat.Format32bppArgb);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.Clear(Color.Transparent);
            DrawRing(g, new RectangleF(0, 0, size, size));
        }
        return bmp;
    }

    private static byte[] cachedIco;

    private static byte[] IconBytes()
    {
        if (cachedIco != null) return cachedIco;
        int[] sizes = new int[] { 16, 20, 24, 32, 40, 48, 64 };
        List<int> sz = new List<int>();
        List<byte[]> px = new List<byte[]>();
        for (int i = 0; i < sizes.Length; i++)
        {
            int s = sizes[i];
            using (Bitmap bmp = RenderRing(s))
            {
                BitmapData data = bmp.LockBits(new Rectangle(0, 0, s, s), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
                try
                {
                    byte[] buf = new byte[s * s * 4];
                    for (int y = 0; y < s; y++)
                        Marshal.Copy(new IntPtr(data.Scan0.ToInt64() + (long)y * data.Stride), buf, y * s * 4, s * 4);
                    sz.Add(s);
                    px.Add(buf);
                }
                finally { bmp.UnlockBits(data); }
            }
        }
        cachedIco = BuildIco(sz, px);
        return cachedIco;
    }

    /// <summary>Fallback: GetHicon -> managed clone (owns its own copy) -> DestroyIcon on the original.</summary>
    private static Icon HiconIcon(int size)
    {
        using (Bitmap bmp = RenderRing(size))
        {
            IntPtr h = bmp.GetHicon();
            try
            {
                using (Icon tmp = Icon.FromHandle(h)) return (Icon)tmp.Clone();
            }
            finally { DestroyIcon(h); }
        }
    }



    // ------------------------------------------------------------------ header
    private sealed class HeaderPanel : Panel
    {
        private const double DecodeMs = 650;
        private readonly string title;
        private readonly string subtitle;
        private readonly string version;
        private readonly System.Diagnostics.Stopwatch clock = new System.Diagnostics.Stopwatch();
        private readonly Timer timer = new Timer();

        public HeaderPanel(string title, string subtitle, string version)
        {
            this.title = title;
            this.subtitle = subtitle;
            this.version = version;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Dock = DockStyle.Top;
            BackColor = ColHeader;
            ForeColor = ColText;
            Tag = "theme:keep-header";
            TabStop = false;
            timer.Interval = 30;
            timer.Tick += delegate
            {
                if (clock.Elapsed.TotalMilliseconds >= DecodeMs) { timer.Stop(); clock.Stop(); }
                Invalidate();
            };
            FixHeight();
        }

        private double scale = 1.0;

        /// <summary>UiScale of the window (fonts and height follow it).</summary>
        public double UiScaleFactor
        {
            get { return scale; }
            set { double v = Math.Max(UiScale.Min, Math.Min(UiScale.Max, value)); if (v == scale) return; scale = v; FixHeight(); Invalidate(); }
        }

        private void FixHeight()
        {
            try { Height = Px(this, (int)Math.Round(48 * scale)); } catch { }
        }

        // Height is DPI-scaled by us; stop form auto-scaling from scaling it a second time.
        protected override void ScaleControl(SizeF factor, BoundsSpecified specified)
        {
            base.ScaleControl(factor, specified & ~BoundsSpecified.Height);
        }

        protected override void OnDpiChangedAfterParent(EventArgs e)
        {
            base.OnDpiChangedAfterParent(e);
            FixHeight();
            Invalidate();
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            FixHeight();
        }

        protected override void OnVisibleChanged(EventArgs e)
        {
            base.OnVisibleChanged(e);
            if (Visible && AnimationsOn) { clock.Reset(); clock.Start(); timer.Start(); }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) timer.Dispose();
            base.Dispose(disposing);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            try
            {
                Graphics g = e.Graphics;
                int w = ClientSize.Width, h = ClientSize.Height;
                using (LinearGradientBrush b = new LinearGradientBrush(new Rectangle(0, -1, Math.Max(1, w), h + 2), ColBackground, ColHeader, LinearGradientMode.Vertical))
                    g.FillRectangle(b, 0, 0, w, h);
                DrawScanlines(g, new Rectangle(0, 0, w, h), 70);
                int line = Math.Max(1, Px(this, 1));
                DrawFadeLine(g, 0, h - line, w, line, ColAccent);

                int pad = Px(this, 14);
                int icon = Px(this, 22);
                int textH = h - line;
                DrawRing(g, new RectangleF(pad, (textH - icon) / 2f, icon, icon));

                double p = clock.IsRunning ? clock.Elapsed.TotalMilliseconds / DecodeMs : 1.0;
                TextFormatFlags flags = TextFormatFlags.Left | TextFormatFlags.VerticalCenter |
                                        TextFormatFlags.SingleLine | TextFormatFlags.NoPrefix |
                                        TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding;
                // point sizes: GDI scales them with the screen DPI already
                // SPEC v4 readability (>= 11 pt) x the window's UiScale
                using (Font tf = Mono(UiScale.Pt(13f, scale, 13f), FontStyle.Bold))
                using (Font sf = Ui(UiScale.Pt(11f, scale, 11f)))
                using (Font vf = Mono(UiScale.Pt(11f, scale, 11f)))
                {
                    int right = w - pad;
                    if (version.Length > 0)
                    {
                        string v = "[ " + version + " ]";
                        Size vs = TextRenderer.MeasureText(g, v, vf, new Size(w, textH), flags);
                        TextRenderer.DrawText(g, v, vf, new Rectangle(right - vs.Width, 0, vs.Width, textH), ColAccent2, flags);
                        right -= vs.Width + Px(this, 12);
                    }
                    int x = pad + icon + Px(this, 12);
                    string shown = Decode(title.ToUpperInvariant(), p, 7);
                    if (shown.Length > 0 && right > x)
                    {
                        Size ts = TextRenderer.MeasureText(g, title.ToUpperInvariant(), tf, new Size(w, textH), flags);
                        int tw = Math.Min(ts.Width, right - x);
                        TextRenderer.DrawText(g, shown, tf, new Rectangle(x, 0, tw, textH), ColAccent, flags);
                        x += tw + Px(this, 10);
                    }
                    if (subtitle.Length > 0 && right > x)
                        TextRenderer.DrawText(g, "// " + subtitle, sf, new Rectangle(x, 0, right - x, textH), ColMuted, flags);
                }
            }
            catch { }
        }
    }
#endif
}

#if !THEME_PURE_CHECK
namespace TarkovCrosshair
{
    /// <summary>One entry of the settings window's left navigation: "01  按键", hover, selected bar.</summary>
    internal sealed class NavItem : Control
    {
        private bool selected, hover;
        public readonly string Index;
        public readonly string Title;
        private readonly float k;

        public NavItem(string index, string title, float scale)
        {
            Index = index ?? "";
            Title = title ?? "";
            k = scale;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
            Tag = "theme:keep-nav";
            Cursor = Cursors.Hand;
            TabStop = true; // keyboard: Tab reaches the list, ↑ / ↓ move, Enter / Space open
            Text = Title;
            AccessibleName = Title;
            AccessibleRole = AccessibleRole.PageTab;
            Height = (int)Math.Round(40 * k);
        }

        public bool Selected
        {
            get { return selected; }
            set { if (selected == value) return; selected = value; Invalidate(); }
        }

        /// <summary>↑ (-1) / ↓ (+1) pressed while this item has focus.</summary>
        public event Action<int> Navigate;

        protected override bool IsInputKey(Keys keyData)
        {
            Keys c = keyData & Keys.KeyCode;
            if (c == Keys.Up || c == Keys.Down) return true;
            return base.IsInputKey(keyData);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Space) { e.Handled = true; OnClick(EventArgs.Empty); }
            else if (e.KeyCode == Keys.Up || e.KeyCode == Keys.Down)
            {
                e.Handled = true;
                Action<int> h = Navigate;
                if (h != null) h(e.KeyCode == Keys.Up ? -1 : 1);
            }
        }

        protected override void OnGotFocus(EventArgs e) { base.OnGotFocus(e); Invalidate(); }
        protected override void OnLostFocus(EventArgs e) { base.OnLostFocus(e); Invalidate(); }
        protected override void OnMouseEnter(EventArgs e) { base.OnMouseEnter(e); hover = true; Invalidate(); }
        protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e); hover = false; Invalidate(); }

        protected override void OnPaint(PaintEventArgs e)
        {
            try
            {
                Graphics g = e.Graphics;
                int w = ClientSize.Width, h = ClientSize.Height;
                Color back = selected ? Theme.Blend(Theme.ColBackground, Theme.ColAccent, 0.09) : (hover ? Theme.ColHover : Theme.ColBackground);
                using (SolidBrush b = new SolidBrush(back)) g.FillRectangle(b, 0, 0, w, h);
                if (selected)
                {
                    int bar = Math.Max(2, (int)Math.Round(3 * k));
                    using (SolidBrush b = new SolidBrush(Theme.ColAccent)) g.FillRectangle(b, 0, 0, bar, h);
                    Theme.DrawFadeLine(g, bar, h - 1, w - bar, 1, Theme.Blend(Theme.ColBackground, Theme.ColAccent, 0.45));
                }
                TextFormatFlags f = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine |
                                    TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding | TextFormatFlags.EndEllipsis;
                int x = (int)Math.Round(16 * k);
                using (Font mono = Theme.Mono(Math.Max(11f, Font.SizeInPoints))) // numbers >= 11 pt (SPEC v4)
                {
                    int iw = TextRenderer.MeasureText(g, "00", mono, new Size(w, h), f).Width;
                    TextRenderer.DrawText(g, Index, mono, new Rectangle(x, 0, iw + 2, h),
                        selected ? Theme.ColAccent : Theme.ColMuted, f); // >= 4.5:1 contrast (was a dimmer grey)
                    x += iw + (int)Math.Round(12 * k);
                }
                TextRenderer.DrawText(g, Title, Font, new Rectangle(x, 0, Math.Max(0, w - x - 4), h),
                    selected ? Theme.ColText : (hover ? Theme.ColText : Theme.ColMuted), f);
                if (Focused && ShowFocusCues)
                    using (Pen fp = new Pen(Theme.Blend(Theme.ColBackground, Theme.ColAccent2, 0.7)))
                    {
                        fp.DashStyle = DashStyle.Dot;
                        g.DrawRectangle(fp, 1, 1, w - 3, h - 3);
                    }
            }
            catch { }
        }
    }

    /// <summary>Page heading: "▍ 标题  // 副标题", decodes in when Restart() is called; accent hairline below.</summary>
    internal sealed class PageTitle : Control
    {
        private const double DecodeMs = 420;
        private readonly string title, sub;
        private readonly float k;
        private readonly System.Diagnostics.Stopwatch clock = new System.Diagnostics.Stopwatch();
        private readonly Timer timer = new Timer();
        private int seed;

        public PageTitle(string title, string sub, float scale)
        {
            this.title = title ?? "";
            this.sub = sub ?? "";
            k = scale;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Tag = "theme:keep-title";
            TabStop = false;
            Text = this.title;
            timer.Interval = 30;
            timer.Tick += delegate
            {
                if (clock.Elapsed.TotalMilliseconds >= DecodeMs) { timer.Stop(); clock.Stop(); }
                Invalidate();
            };
        }

        public override Size GetPreferredSize(Size proposedSize)
        {
            return new Size((int)Math.Round(320 * k), (int)Math.Round(Font.Height * 2.0f + 10 * k));
        }

        public void Restart()
        {
            seed++;
            if (!Theme.AnimationsOn) { Invalidate(); return; }
            clock.Reset();
            clock.Start();
            timer.Start();
            Invalidate();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) timer.Dispose();
            base.Dispose(disposing);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            try
            {
                Graphics g = e.Graphics;
                int w = ClientSize.Width, h = ClientSize.Height;
                Color back = Parent != null ? Parent.BackColor : Theme.ColSurface;
                if (back.A < 255) back = Theme.ColSurface;
                using (SolidBrush b = new SolidBrush(back)) g.FillRectangle(b, 0, 0, w, h);
                double p = clock.IsRunning ? clock.Elapsed.TotalMilliseconds / DecodeMs : 1.0;
                TextFormatFlags f = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine |
                                    TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding;
                int lineY = h - (int)Math.Round(4 * k);
                int bar = Math.Max(2, (int)Math.Round(3 * k));
                using (SolidBrush ab = new SolidBrush(Theme.ColAccent))
                    g.FillRectangle(ab, 0, (int)Math.Round(8 * k), bar, lineY - (int)Math.Round(14 * k));
                int x = bar + (int)Math.Round(10 * k);
                using (Font tf = Theme.Ui(Math.Max(16f, Font.SizeInPoints * 1.5f), FontStyle.Bold)) // page titles >= 16 pt
                {
                    string shown = Theme.Decode(title, p, seed);
                    Size ts = TextRenderer.MeasureText(g, title, tf, new Size(w, h), f);
                    Rectangle tr = new Rectangle(x, 0, Math.Min(ts.Width + 4, Math.Max(0, w - x)), lineY - (int)Math.Round(2 * k));
                    TextRenderer.DrawText(g, shown, tf, tr, Theme.ColText, f);
                    x += ts.Width + (int)Math.Round(14 * k);
                }
                if (sub.Length > 0 && x < w)
                    using (Font sf = Theme.Mono(Math.Max(10.5f, Font.SizeInPoints * 0.95f))) // labels >= 10.5 pt
                        TextRenderer.DrawText(g, "// " + Theme.Decode(sub, p * 1.3 - 0.2, seed + 3), sf,
                            new Rectangle(x, 0, w - x, lineY - (int)Math.Round(2 * k)), Theme.ColMuted, f | TextFormatFlags.EndEllipsis);
                Theme.DrawFadeLine(g, 0, lineY, w, 1, Theme.Blend(back, Theme.ColAccent, 0.55));
            }
            catch { }
        }
    }

    /// <summary>Clickable "▸ 可选 / 高级" header of a collapsed section. Toggled fires after Open changes.</summary>
    internal sealed class FoldHeader : Control
    {
        private bool open, hover;
        private readonly float k;
        public event Action Toggled;

        public FoldHeader(string text, float scale)
        {
            Text = text ?? "";
            k = scale;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
            Tag = "theme:keep-fold";
            Cursor = Cursors.Hand;
            TabStop = true;
            AccessibleRole = AccessibleRole.OutlineButton;
        }

        public bool Open
        {
            get { return open; }
            set { if (open == value) return; open = value; Invalidate(); Action h = Toggled; if (h != null) h(); }
        }

        public override Size GetPreferredSize(Size proposedSize)
        {
            Size t = TextRenderer.MeasureText(Text, Font);
            return new Size(Math.Max((int)Math.Round(420 * k), t.Width + (int)Math.Round(60 * k)), Font.Height + (int)Math.Round(12 * k));
        }

        protected override void OnClick(EventArgs e) { base.OnClick(e); Focus(); Open = !Open; }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            if (e.KeyCode == Keys.Space || e.KeyCode == Keys.Enter) { Open = !Open; e.Handled = true; }
        }

        protected override void OnMouseEnter(EventArgs e) { base.OnMouseEnter(e); hover = true; Invalidate(); }
        protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e); hover = false; Invalidate(); }
        protected override void OnGotFocus(EventArgs e) { base.OnGotFocus(e); Invalidate(); }
        protected override void OnLostFocus(EventArgs e) { base.OnLostFocus(e); Invalidate(); }

        protected override void OnPaint(PaintEventArgs e)
        {
            try
            {
                Graphics g = e.Graphics;
                int w = ClientSize.Width, h = ClientSize.Height;
                Color back = Parent != null && Parent.BackColor.A == 255 ? Parent.BackColor : Theme.ColSurface;
                using (SolidBrush b = new SolidBrush(hover ? Theme.Blend(back, Theme.ColHover, 0.8) : back)) g.FillRectangle(b, 0, 0, w, h);
                Color c = hover || Focused ? Theme.ColAccent2 : Theme.Blend(Theme.ColMuted, Theme.ColAccent2, 0.45);
                TextFormatFlags f = TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine | TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding;
                int x = (int)Math.Round(4 * k);
                string arrow = open ? "▾" : "▸";
                using (Font mono = Theme.Mono(Font.SizeInPoints))
                {
                    TextRenderer.DrawText(g, arrow, mono, new Rectangle(x, 0, w, h), c, f);
                    x += TextRenderer.MeasureText(g, "▾", mono, new Size(w, h), f).Width + (int)Math.Round(8 * k);
                }
                Size ts = TextRenderer.MeasureText(g, Text, Font, new Size(w, h), f);
                TextRenderer.DrawText(g, Text, Font, new Rectangle(x, 0, w - x, h), c, f);
                x += ts.Width + (int)Math.Round(10 * k);
                if (x < w)
                    using (Pen p = new Pen(Theme.ColBorder))
                    {
                        p.DashStyle = DashStyle.Dash;
                        g.DrawLine(p, x, h / 2, w - 1, h / 2);
                    }
            }
            catch { }
        }
    }

    /// <summary>The 「首次设置教程」 button: neon frame; while Highlight is on it pulses (stops when hidden).</summary>
    internal sealed class GlowButton : Control
    {
        private bool highlight, hover, down;
        private readonly float k;
        private readonly Timer timer = new Timer();
        private readonly System.Diagnostics.Stopwatch clock = System.Diagnostics.Stopwatch.StartNew();

        public GlowButton(string text, float scale)
        {
            Text = text ?? "";
            k = scale;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
            Tag = "theme:keep-glow";
            Cursor = Cursors.Hand;
            TabStop = true;
            AccessibleRole = AccessibleRole.PushButton;
            timer.Interval = 40;
            timer.Tick += delegate { Invalidate(); };
        }

        public bool Highlight
        {
            get { return highlight; }
            set { highlight = value; SyncTimer(); Invalidate(); }
        }

        private void SyncTimer()
        {
            bool run = highlight && Visible && Theme.AnimationsOn;
            if (run && !timer.Enabled) timer.Start();
            else if (!run && timer.Enabled) timer.Stop();
        }

        protected override void OnVisibleChanged(EventArgs e) { base.OnVisibleChanged(e); SyncTimer(); }
        protected override void OnMouseEnter(EventArgs e) { base.OnMouseEnter(e); hover = true; Invalidate(); }
        protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e); hover = false; down = false; Invalidate(); }
        protected override void OnMouseDown(MouseEventArgs e) { base.OnMouseDown(e); if (e.Button == MouseButtons.Left) { down = true; Invalidate(); } }
        protected override void OnMouseUp(MouseEventArgs e) { base.OnMouseUp(e); down = false; Invalidate(); }
        protected override void OnGotFocus(EventArgs e) { base.OnGotFocus(e); Invalidate(); }
        protected override void OnLostFocus(EventArgs e) { base.OnLostFocus(e); Invalidate(); }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            if (e.KeyCode == Keys.Space || e.KeyCode == Keys.Enter) { e.Handled = true; OnClick(EventArgs.Empty); }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) timer.Dispose();
            base.Dispose(disposing);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            try
            {
                Graphics g = e.Graphics;
                int w = ClientSize.Width, h = ClientSize.Height;
                Color back = Parent != null && Parent.BackColor.A == 255 ? Parent.BackColor : Theme.ColBackground;
                using (SolidBrush b = new SolidBrush(back)) g.FillRectangle(b, 0, 0, w, h);
                double pulse = highlight && timer.Enabled ? 0.5 + 0.5 * Math.Sin(clock.Elapsed.TotalMilliseconds / 420.0) : 0.6;
                Color edge = highlight ? Theme.Blend(Theme.ColBorder, Theme.ColAccent, 0.55 + 0.45 * pulse)
                                       : (hover || Focused ? Theme.ColAccent2 : Theme.ColBorder);
                double fillT = highlight ? 0.10 + 0.10 * pulse : (hover ? 0.06 : 0.0);
                if (down) fillT += 0.12;
                Rectangle r = new Rectangle(0, 0, w - 1, h - 1);
                using (SolidBrush b = new SolidBrush(Theme.Blend(Theme.ColInput, highlight ? Theme.ColAccent : Theme.ColAccent2, fillT)))
                    g.FillRectangle(b, r);
                if (highlight)
                {
                    // soft outer glow: 3 fading frames
                    for (int i = 1; i <= 3; i++)
                    {
                        int a = (int)Math.Round((60 - i * 16) * pulse);
                        if (a <= 0) continue;
                        using (Pen gp = new Pen(Color.FromArgb(a, Theme.ColAccent)))
                            g.DrawRectangle(gp, -i + 1, -i + 1, w - 1 + 2 * i - 2, h - 1 + 2 * i - 2);
                    }
                }
                using (Pen p = new Pen(edge)) g.DrawRectangle(p, r);
                TextFormatFlags f = TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine |
                                    TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis;
                TextRenderer.DrawText(g, Text, Font, r, highlight ? Theme.ColAccent : (hover ? Theme.ColText : Theme.ColMuted), f);
            }
            catch { }
        }
    }
}
#endif


#if !THEME_PURE_CHECK
namespace TarkovCrosshair
{
    /// <summary>
    /// A titled settings card (v4.0, replaces GroupBox, whose auto-size clips its last row on some systems):
    /// a 1-column auto-size grid = cyan title row + content, a hairline frame and terminal corner ticks.
    /// </summary>
    internal sealed class Section : TableLayoutPanel
    {
        private readonly float k;
        public readonly Label TitleLabel;

        public Section(string title, Control content, float scale)
        {
            k = scale;
            SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint | ControlStyles.ResizeRedraw, true);
            ColumnCount = 1;
            ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            AutoSize = true;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            Padding = new Padding(Px(14), Px(10), Px(14), Px(12));
            Margin = new Padding(0, 0, Px(12), Px(12));
            BackColor = Theme.Blend(Theme.ColSurface, Theme.ColInput, 0.35);
            Tag = "theme:keep-section";
            TitleLabel = new Label();
            TitleLabel.Text = title ?? "";
            TitleLabel.AutoSize = true;
            TitleLabel.ForeColor = Theme.ColAccent2;
            TitleLabel.BackColor = Color.Transparent;
            TitleLabel.Tag = "theme:keep-sectitle";
            TitleLabel.Margin = new Padding(Px(1), 0, 0, Px(8));
            TitleLabel.Visible = TitleLabel.Text.Length > 0;
            Controls.Add(TitleLabel, 0, 0);
            content.Margin = new Padding(0);
            content.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            Controls.Add(content, 0, 1);
        }

        private int Px(int v) { return (int)Math.Round(v * k); }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            try
            {
                Graphics g = e.Graphics;
                int w = ClientSize.Width, h = ClientSize.Height;
                if (w < 4 || h < 4) return;
                using (Pen p = new Pen(Theme.ColBorder)) g.DrawRectangle(p, 0, 0, w - 1, h - 1);
                int t = Px(10);
                using (Pen a = new Pen(Theme.Blend(Theme.ColBorder, Theme.ColAccent2, 0.75)))
                {
                    g.DrawLine(a, 0, 0, t, 0);
                    g.DrawLine(a, 0, 0, 0, t);
                    g.DrawLine(a, w - 1, h - 1, w - 1 - t, h - 1);
                    g.DrawLine(a, w - 1, h - 1, w - 1, h - 1 - t);
                }
            }
            catch { }
        }
    }
}
#endif

// Global namespace like Theme, so Theme and every TarkovCrosshair file can use it.
/// <summary>
/// v4.0 dynamic text size (SPEC "dynamic font size by window size"), pure and shared by SettingsForm, StylePanel,
/// DashboardPanel and TutorialForm: uiScale = clamp(min(w / 1100, h / 740), 1.0, 1.8) with w, h in LOGICAL px
/// (physical px / (dpi / 96)). Every font = base pt x uiScale (base pt already >= the readability minimums), so a big
/// window shows bigger text and a small one never goes below the base sizes.
/// </summary>
internal static class UiScale
{
    public const double RefWidth = 1100, RefHeight = 740, Min = 1.0, Max = 1.8;
    /// <summary>Scale steps: fonts are only rebuilt when the scale moves to another step (no churn while dragging).</summary>
    public const double Step = 0.05;

    /// <summary>width/height = client size in physical px; dpi = the window's DPI (96 = 100 %). Bad input -> 1.0.</summary>
    public static double For(int width, int height, float dpi)
    {
        if (width <= 0 || height <= 0) return Min;
        double k = (dpi > 0 && !float.IsNaN(dpi) && !float.IsInfinity(dpi)) ? dpi / 96.0 : 1.0;
        double s = Math.Min(width / k / RefWidth, height / k / RefHeight);
        if (double.IsNaN(s) || s < Min) s = Min;
        if (s > Max) s = Max;
        return Math.Round(Math.Floor(s / Step + 1e-9) * Step, 2); // quantised down to 0.05
    }

    /// <summary>A font size: base pt x scale, never below minPt.</summary>
    public static float Pt(float basePt, double scale, float minPt)
    {
        double v = basePt * (double.IsNaN(scale) || scale < Min ? Min : (scale > Max ? Max : scale));
        return (float)Math.Max(minPt, Math.Round(v * 4) / 4.0); // quarter-points: stable sizes
    }
}
