﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

// 跳跃 page (PAGE-C). Part of the settings window: partial class SettingsForm (shell, shared helpers, 高级设置 switch: SettingsForm.cs).
// Page rule: use the shell helpers (Grid / Line / Stack / Row / AdvRow / AdvOnly / Lbl / Note / Unit / Num / Choice / Check /
// Btn / Group / Fold / FixUp / F / S / P / Tip / EnableWhen) and read `Advanced`; never change another page's file.

#if !UI_PURE_CHECK
namespace TarkovCrosshair
{
    internal sealed partial class SettingsForm
    {
        /// <summary>跳跃: ☑ enable, 跳跃键 summary, 总时长, a read-only path plot; 高级设置: 3 phase rows + 自动分配.</summary>
        private Control BuildJump()
        {
            Func<JumpSettings> J = delegate { return Cur.Jump; };
            JumpPlot plot = new JumpPlot();
            plot.Jump = J;
            FixUp(delegate { plot.Size = new Size(F(420), F(130)); });
            plot.Margin = P(3, 8, 3, 3);
            refreshers.Add(plot.Invalidate);
            List<Control> parts = new List<Control>();

            NumericUpDown total = Num(JumpSettings.MinTotalMs, JumpSettings.MaxTotalMs, 10, 0, delegate { return J().TotalMs; },
                delegate(double v) { JumpSplit.SetTotal(J(), (int)Math.Round(v)); RefreshValues(); });
            Button auto = Btn("自动分配", delegate { JumpSplit.Auto(J()); RefreshValues(); app.Changed(); });
            Tip(total, "三段加起来永远等于总时长，改总时长三段按比例一起变");
            Tip(auto, "三段时长按 30% / 40% / 30% 分");
            parts.Add(total); parts.Add(auto);

            TableLayoutPanel g = Grid(4);
            g.Controls.Add(Lbl("阶段"));
            g.Controls.Add(Lbl("时长 ms"));
            Label he = Lbl("结束位置 px（+ 往上）");
            Tip(he, "正数往上");
            g.Controls.Add(he);
            g.Controls.Add(Lbl("曲线"));
            for (int i = 0; i < JumpSettings.PhaseCount; i++)
            {
                int idx = i;
                g.Controls.Add(Lbl((i + 1) + ". " + JumpSettings.PhaseNames[i]));
                NumericUpDown ms = Num(0, JumpSettings.MaxTotalMs, 10, 0, delegate { return J().Phases[idx].Ms; },
                    delegate(double v) { JumpSplit.SetPhase(J(), idx, (int)Math.Round(v)); RefreshValues(); });
                g.Controls.Add(ms);
                parts.Add(ms);
                if (i < JumpSettings.PhaseCount - 1)
                {
                    NumericUpDown end = Num(-JumpSettings.LimitPx, JumpSettings.LimitPx, 1, 1, delegate { return J().Phases[idx].EndPx; },
                        delegate(double v) { J().Phases[idx].EndPx = v; plot.Invalidate(); });
                    g.Controls.Add(end);
                    parts.Add(end);
                }
                else g.Controls.Add(Unit("0（固定）"));
                ComboBox cv = Choice(JumpSettings.CurveLabels, JumpSettings.Curves, delegate { return J().Phases[idx].Curve; },
                    delegate(string v) { J().Phases[idx].Curve = v; plot.Invalidate(); });
                g.Controls.Add(cv);
                parts.Add(cv);
            }

            CheckBox on = Check("跳跃时准星跟着动", delegate { return J().Enabled; },
                delegate(bool v) { J().Enabled = v; foreach (Control c in parts) c.Enabled = v; });
            refreshers.Add(delegate { foreach (Control c in parts) c.Enabled = J().Enabled; });
            Label key = StatusLbl();
            refreshers.Add(delegate { key.Text = G.Keys.ComboOf(KeyBindings.ActionJump); });

            TableLayoutPanel box = Grid(1);
            box.Controls.Add(on);
            box.Controls.Add(Line(Lbl("跳跃键"), key, KeysPageLink("去「按键」页改 →")));
            box.Controls.Add(Note("按一下跳跃键，准星按下面这条路线走一遍（跳的过程中再按不算）。", 520));
            box.Controls.Add(Line(Lbl("总时长"), total, Unit("ms"), AdvOnly(auto)));
            box.Controls.Add(plot);
            box.Controls.Add(Unit("竖着看：准星上下位置（px，往下为负）；横着看：时间。"));
            box.Controls.Add(Note("默认就是开发者调好的路线，一般不用改；要改的话，一般只改总时长。", 520));
            box.Controls.Add(AdvOnly(g)); // per-phase table: 高级设置 only
            box.Controls.Add(AdvOnly(Note("三段加起来永远等于总时长：改总时长，三段按比例一起变；「自动分配」＝ 30% / 40% / 30%。结束位置正数往上。", 520)));
            return Stack(Group("跳跃", box));
        }
    }
}
#endif
