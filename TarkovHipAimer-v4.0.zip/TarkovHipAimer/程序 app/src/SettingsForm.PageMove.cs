﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

// 移动 page + optional curve editor (PAGE-B). Part of the settings window: partial class SettingsForm (shell, shared helpers, 高级设置 switch: SettingsForm.cs).
// Page rule: use the shell helpers (Grid / Line / Stack / Row / AdvRow / AdvOnly / Lbl / Note / Unit / Num / Choice / Check /
// Btn / Group / Fold / FixUp / F / S / P / Tip / EnableWhen) and read `Advanced`; never change another page's file.

#if !UI_PURE_CHECK
namespace TarkovCrosshair
{
    internal sealed partial class SettingsForm
    {
        /// <summary>移动: W/S/A/D offsets; the curve editor sits under 「可选：移动曲线（高级）」 with 推荐 marked.</summary>
        private Control BuildMovement()
        {
            TableLayoutPanel g = Grid(3);
            g.Controls.Add(Blank());
            g.Controls.Add(Lbl("X（右为正）"));
            g.Controls.Add(Lbl("Y（上为正）"));
            string[] names = { "W 前", "S 后", "A 左", "D 右" };
            for (int i = 0; i < 4; i++)
            {
                int idx = i;
                Row(g, names[i],
                    Num(-500, 500, 1, 1, delegate { return Cur.Dirs[idx].OffX; }, delegate(double v) { Cur.Dirs[idx].OffX = v; Profile.RecomputeDiagonals(Cur); }),
                    Num(-500, 500, 1, 1, delegate { return Cur.Dirs[idx].OffY; }, delegate(double v) { Cur.Dirs[idx].OffY = v; Profile.RecomputeDiagonals(Cur); }));
            }
            TableLayoutPanel dirBox = Grid(1);
            dirBox.Controls.Add(g);
            dirBox.Controls.Add(Note("按住这个方向走路时，准星往哪边移、移多少。", 480));
            dirBox.Controls.Add(Note("A / D 主要调 X，W / S 主要调 Y，另一格一般不用动。", 480));
            dirBox.Controls.Add(Note("斜向（WA / WD / SA / SD）自动算好；侧身时再加上侧身的偏移。", 480));
            Section gDir = Group("移动时准星偏移（px）", dirBox);

            // 高级设置 off: say where the curve is instead of showing it.
            Label hint = Note("移动曲线（可选）在顶部「高级设置」里，默认就是推荐方案。", 480);
            refreshers.Add(delegate { hint.Visible = !Advanced; });

            // 移动速率曲线 (optional)
            Label state = TagLabel("", Theme.ColAccent);
            Action stateOn = delegate
            {
                bool rec = Cur.CurveAD.IsRecommended && Cur.CurveWS.IsRecommended;
                state.Text = rec ? "● 当前为推荐" : "○ 已自定义";
                state.ForeColor = rec ? Theme.ColAccent : Theme.ColMuted;
            };
            refreshers.Add(stateOn);
            Button recommend = AccentBtn("恢复推荐（慢起 · " + Profile.RecommendedCurveMs + " ms）", delegate
            {
                Cur.ResetCurvesToRecommended();
                RefreshValues();
                app.Changed();
            });
            Tip(recommend, "Leo 的方案：前后、左右都用 380 ms 慢起");
            TableLayoutPanel curves = Grid(2);
            Control blockAD = CurveBlock("左右 A/D", delegate { return Cur.CurveAD; }, stateOn);
            Control blockWS = CurveBlock("前后 W/S", delegate { return Cur.CurveWS; }, stateOn);
            curves.Controls.Add(blockAD, 0, 0);
            curves.Controls.Add(blockWS, 1, 0);
            // Two curves side by side when the page is wide enough, else one under the other (no sideways scrolling).
            Action placeCurves = delegate
            {
                if (pageHost == null) return;
                int need = blockAD.PreferredSize.Width + blockAD.Margin.Horizontal + blockWS.PreferredSize.Width + blockWS.Margin.Horizontal
                    + S(22 + 10 + 40 + 14 + 30) + SystemInformation.VerticalScrollBarWidth; // page + section + fold indent + slack
                bool side = pageHost.ClientSize.Width >= need;
                TableLayoutPanelCellPosition want = side ? new TableLayoutPanelCellPosition(1, 0) : new TableLayoutPanelCellPosition(0, 1);
                TableLayoutPanelCellPosition now = curves.GetPositionFromControl(blockWS);
                if (now.Column != want.Column || now.Row != want.Row) curves.SetCellPosition(blockWS, want);
            };
            if (pageHost != null) pageHost.Resize += delegate { placeCurves(); };
            FixUp(placeCurves);
            Button copy = Btn("把左右的曲线复制到前后", delegate
            {
                if (!Ask("把前后 W/S 的曲线（总时长和 5 个速度）改成和左右 A/D 一样？")) return;
                Cur.CurveWS = Cur.CurveAD.Clone();
                RefreshValues();
                app.Changed();
            });
            TableLayoutPanel curveBox = Grid(1);
            curveBox.Controls.Add(Line(recommend, state));
            curveBox.Controls.Add(curves);
            curveBox.Controls.Add(copy);
            curveBox.Controls.Add(Note("推荐＝Leo 的方案，一般不用改。曲线管准星移过去的快慢：横轴是时间，纵轴是速度，点越高那一段动得越快，总时长到了刚好到位。按下、松开、换方向都用这条曲线。可以拖曲线上的点，也可以直接填数字。", 560));
            Section gCurve = Group("移动速率曲线", curveBox);
            return Stack(gDir, hint, AdvOnly(Fold("可选：移动曲线（推荐＝Leo 的方案）", gCurve)));
        }

        /// <summary>One 移动速率曲线 block: 总时长, the curve editor, 5 number boxes (synced both ways), presets (推荐 marked).</summary>
        private Control CurveBlock(string title, Func<MoveCurve> get, Action changed)
        {
            TableLayoutPanel b = Grid(1);
            b.Margin = P(0, 0, 16, 0);
            CurveEditor ed = new CurveEditor();
            ed.Curve = get;
            FixUp(delegate { ed.Size = new Size(F(300), F(120)); });
            ed.Margin = P(3, 4, 3, 4);
            b.Controls.Add(Line(Lbl(title), Lbl("总时长"),
                Num(0, 2000, 10, 0, delegate { return get().DurationMs; }, delegate(double v) { get().DurationMs = v; ed.Invalidate(); changed(); }),
                Unit("ms")));
            b.Controls.Add(ed);
            TableLayoutPanel pts = Grid(MotionCurve.Points);
            NumericUpDown[] boxes = new NumericUpDown[MotionCurve.Points];
            // The editor already labels 0% .. 100% under its points, so the boxes need no second label row.
            for (int i = 0; i < MotionCurve.Points; i++)
            {
                int idx = i;
                boxes[i] = Num(0, 100, 1, 0, delegate { return get().Speeds[idx]; }, delegate(double v) { get().Speeds[idx] = v; ed.Invalidate(); changed(); });
                boxes[i].Margin = P(1, 2, 1, 2);
                Tip(boxes[i], "时间 " + (i * 25) + "% 处的速度（0–100）");
                pts.Controls.Add(boxes[i], i, 0);
            }
            b.Controls.Add(pts);
            ed.PointChanged += delegate(int i)
            {
                bool was = loading;
                loading = true;
                try { boxes[i].Value = ToDec(get().Speeds[i], boxes[i]); }
                finally { loading = was; }
                changed();
                app.Changed();
            };
            refreshers.Add(ed.Invalidate);
            Control[] presets = new Control[MotionCurve.PresetNames.Length];
            for (int i = 0; i < MotionCurve.PresetNames.Length; i++)
            {
                int idx = i;
                string name = MotionCurve.PresetNames[i] + (i == MotionCurve.RecommendedPreset ? "（推荐）" : "");
                EventHandler click = delegate { get().SetPreset(idx); RefreshValues(); app.Changed(); };
                presets[i] = i == MotionCurve.RecommendedPreset ? AccentBtn(name, click) : Btn(name, click);
            }
            b.Controls.Add(Line(presets));
            return b;
        }
    }
}
#endif
