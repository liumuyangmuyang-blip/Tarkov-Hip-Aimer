﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

// 按键 page (PAGE-A). Part of the settings window: partial class SettingsForm (shell, shared helpers, 高级设置 switch: SettingsForm.cs).
// Page rule: use the shell helpers (Grid / Line / Stack / Row / AdvRow / AdvOnly / Lbl / Note / Unit / Num / Choice / Check /
// Btn / Group / Fold / FixUp / F / S / P / Tip / EnableWhen) and read `Advanced`; never change another page's file.

#if !UI_PURE_CHECK
namespace TarkovCrosshair
{
    internal sealed partial class SettingsForm
    {
        /// <summary>按键: the 9 rebindable actions (W/A/S/D are fixed), combos, and the ADS / lean / hand options.</summary>
        private Control BuildKeys()
        {
            TableLayoutPanel g = Grid(3);
            Label toggleL = Lbl("开关准星");
            Tip(toggleL, "按两下（关再开）＝回到正常手、退出强化准星");
            Label toggleHint = Unit("连按两下＝全部复位");
            Tip(toggleHint, "按两下（关再开）＝回到正常手、退出强化准星、取消切换的侧身");
            Row(g, toggleL, KeyBtn(0), toggleHint);
            Row(g, "开火", KeyBtn(1), Blank());

            CheckBox adsTab = Check("Tab / Esc 取消开镜", delegate { return G.AdsCancelTabEsc; }, delegate(bool v) { G.AdsCancelTabEsc = v; });
            CheckBox adsSprint = Check("冲刺（Shift+W）取消开镜", delegate { return G.AdsCancelSprint; }, delegate(bool v) { G.AdsCancelSprint = v; });
            Tip(adsSprint, "只按 Shift（屏息）不算");
            Action adsToggleOnly = delegate { bool t = G.AdsMode == "toggle"; adsTab.Visible = t && Advanced; adsSprint.Visible = t; };
            refreshers.Add(adsToggleOnly);
            Row(g, "开镜", KeyBtn(2), Line(Lbl("开镜方式"), Choice(new string[] { "按住", "点一下切换" }, new string[] { "hold", "toggle" },
                delegate { return G.AdsMode; }, delegate(string v) { G.AdsMode = v; adsToggleOnly(); })));
            // one row that always has a visible item, so hiding the 切换-only boxes never leaves an empty row
            // stacked, not side by side: three boxes in one line made the page scroll sideways at small windows
            Row(g, Blank(), Blank(), Stack(
                AdvOnly(Check("Alt / Ctrl + 右键不算开镜", delegate { return G.AdsIgnoreAltCtrl; }, delegate(bool v) { G.AdsIgnoreAltCtrl = v; })),
                adsTab, adsSprint));

            CheckBox leanSprint = LeanSprintCheck();
            Row(g, "左侧身", KeyBtn(5), Line(Lbl("侧身方式"), LeanModeChoice()));
            Row(g, "右侧身", KeyBtn(6), Blank());
            Row(g, Blank(), Blank(), leanSprint); // own row: it applies to both lean keys

            CheckBox hsOn = Check("换手检测", delegate { return G.HandEnabled; }, delegate(bool v) { G.HandEnabled = v; RefreshValues(); });
            Tip(hsOn, "程序只能按按键判断你用哪只手；对不上时按两下开关准星键（关再开）回到正常手");
            KeyButton handKey = KeyBtn(4);
            Label handModeL = Lbl("换手方式");
            ComboBox handMode = Choice(new string[] { "按住", "点一下切换" }, new string[] { "hold", "toggle" },
                delegate { return G.HandMode; }, delegate(string v) { G.HandMode = v; });
            EnableWhen(delegate { return G.HandEnabled; }, handKey, handModeL, handMode);
            // 高级设置 only -- but while 换手检测 is off it stays visible, so the greyed key can always be switched back on
            refreshers.Add(delegate { hsOn.Visible = Advanced || !G.HandEnabled; });
            Row(g, "换手", handKey, Line(handModeL, handMode, hsOn));
            Row(g, "跳跃", KeyBtn(11), Blank());
            // W/A/S/D are fixed (SPEC v4 req 2): shown read-only so nobody looks for them
            Label wasd = Lbl("W  A  S  D");
            wasd.Font = monoFont;
            wasd.ForeColor = SystemColors.GrayText;
            wasd.TextAlign = ContentAlignment.MiddleCenter;
            wasd.Margin = P(3, 3, 8, 3);
            // same width as the key boxes above, so the column lines up
            FixUp(delegate { wasd.MinimumSize = new Size(Math.Max(F(150), TextRenderer.MeasureText("鼠标侧键1（XButton1）", Font).Width + S(18)), Font.Height + S(6)); });
            Row(g, "前后左右", wasd, Unit("固定，不用改"));
            AdvRow(g, "自由视角（转头）", KeyBtn(3),
                Check("按住时隐藏准星", delegate { return G.HideOnFreeLook; }, delegate(bool v) { G.HideOnFreeLook = v; }));
            CheckBox boostOn = Check("启用", delegate { return G.BoostEnabled; }, delegate(bool v) { G.BoostEnabled = v; });
            Label boostL = Lbl("强化准星");
            Tip(boostL, "按一下变成更显眼的准星，再按一下恢复；开关准星（关再开）也会恢复");
            AdvRow(g, boostL, KeyBtn(12), boostOn);
            TableLayoutPanel keyBox = Grid(1);
            keyBox.Controls.Add(Note("改键：点一下按键框，再按键盘或鼠标键（Esc 取消）。组合键：先按住 Ctrl / Shift / Alt 再按键，例如 Ctrl+D。", 600));
            keyBox.Controls.Add(g);
            keyBox.Controls.Add(Note("开镜方式、侧身方式、换手方式要和游戏里的设置一样。", 600));
            keyBox.Controls.Add(Note("按组合键时只算组合键：例如右侧身设成 Ctrl+D，按 Ctrl+D 只会侧身，准星不会再当成按了 D 去移动。", 600));
            Section gb = Group("按键映射", keyBox);

            Button reset = Btn("按键恢复初始", delegate
            {
                if (!Ask("把这一页的按键和方式全部恢复成第一次安装时的样子？")) return;
                G.ResetKeys();
                RefreshValues();
                app.UpdateTray();
                app.Changed();
            });
            return Stack(gb, reset);
        }
    }
}
#endif
