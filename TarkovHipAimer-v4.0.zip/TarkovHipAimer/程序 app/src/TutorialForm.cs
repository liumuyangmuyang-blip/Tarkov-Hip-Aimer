// TutorialForm.cs -- 首次设置教程 window (v4.0). Hosts TutorialFrame on one double-buffered canvas at ~60 fps, reads the
// keys like the overlay (GetAsyncKeyState via MotionEngine.ReadInput + LiveInputFilter: 组合键, last pressed wins),
// places real input controls for the step's fields, and saves settings.json (SettingsIO) after edits and on 完成.
//
// Use (UI worker):  using (TutorialForm t = new TutorialForm(app.Settings, delegate(string page) { ShowPage(page); }))
//                   { t.ValuesChanged += delegate { app.Changed(); }; t.ShowDialog(this); }  then RefreshValues().
// Page keys passed to jumpToPage: TutorialPages (首页 按键 常规 后坐力 移动 侧身 换手 跳跃 外观 反馈).
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace TarkovCrosshair
{
    public sealed class TutorialForm : Form
    {
        /// <summary>Raised on the UI thread after the tutorial changed a profile value or set TutorialDone (publish + refresh).</summary>
        public event Action ValuesChanged;

        private readonly GlobalSettings g;
        private readonly Action<string> jumpToPage;
        private readonly TutorialContext ctx;
        private readonly FontFamily uiFamily, monoFamily;
        private float uiScale = 1f;
        private readonly Timer resizeTimer;
        private readonly TutorialGfx gx;
        private readonly TutorialFrame frame;
        private readonly Canvas canvas;
        private readonly Timer timer;
        private readonly Timer saveTimer;
        private bool layoutReady;
        private readonly Stopwatch clock = Stopwatch.StartNew();
        private long lastTicks;
        private readonly LiveInputFilter filter = new LiveInputFilter();
        private readonly Func<int, bool> isDown = Native.IsDown;
        private readonly float k;
        private Font ctlFont;
        private bool mouseFire, dirty, finished, closing;
        private TutorialHit downHit = TutorialHit.None;
        private int downDot = -1, downChip = -1;
        private readonly List<Control> fieldCtl = new List<Control>();
        private TutorialField[] fieldsShown;
        private bool updatingFields;
        private int frameSkip;
        private double paintMs;

        /// <summary>Where the tutorial was left in this app session (reopening resumes there).</summary>
        private static int lastIndex;

        public TutorialForm(GlobalSettings g, Action<string> jumpToPage)
        {
            if (g == null) throw new ArgumentNullException("g");
            this.g = g;
            this.jumpToPage = jumpToPage;
            k = SystemScale();

            SuspendLayout();
            AutoScaleMode = AutoScaleMode.None;
            Text = "首次设置教程 · Tarkov Hip Aimer";
            ShowInTaskbar = false;
            KeyPreview = true;
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.Sizable;
            MaximizeBox = true; MinimizeBox = true;
            Rectangle wa = Screen.PrimaryScreen.WorkingArea;
            try { wa = Screen.FromPoint(Cursor.Position).WorkingArea; } catch (Exception) { }
            Size want = new Size((int)(1180 * k), (int)(760 * k));
            Size max = new Size((int)(wa.Width * 0.96), (int)(wa.Height * 0.94));
            Size min = new Size(Math.Min((int)(960 * k), max.Width), Math.Min((int)(620 * k), max.Height));
            ClientSize = new Size(Math.Min(want.Width, max.Width), Math.Min(want.Height, max.Height));
            MinimumSize = SizeFromClientSize(min);

            TutorialPalette pal = TutorialPalette.FromTheme(); // same colours as the settings window (and the offscreen renders)
            BackColor = pal.Bg;
            ForeColor = pal.Text;

            uiFamily = PickFamily(new string[] { "Microsoft YaHei UI", "Microsoft YaHei" }, SystemFonts.MessageBoxFont.FontFamily);
            monoFamily = PickFamily(new string[] { "Consolas", "Cascadia Mono", "Courier New" }, FontFamily.GenericMonospace);
            uiScale = ScaleFor(ClientSize);
            ctlFont = new Font(uiFamily, TutorialFonts.NumberPt * uiScale); // numbers >= 11 pt (SPEC)
            gx = new TutorialGfx(pal, new TutorialFonts(uiFamily, monoFamily, uiScale));
            gx.K = k * uiScale;

            ctx = new TutorialContext(g);
            ctx.K = k;
            ctx.ChangedHook = delegate { AfterEdit(false); };
            ctx.FinishHook = delegate { Finish(); };
            ctx.CloseAndJumpHook = delegate(string page) { Finish(); CloseAndOpen(page); };

            List<TutorialStep> steps = new List<TutorialStep>();
            steps.AddRange(TutorialStepsA.Create());
            steps.AddRange(TutorialStepsB.Create());
            frame = new TutorialFrame(ctx, gx, steps);
            frame.SetMeasureDpi(96f * k); // text is laid out at the screen DPI it is painted at
            frame.LayoutChanged += PlaceFields;

            canvas = new Canvas();
            canvas.Dock = DockStyle.Fill;
            canvas.BackColor = pal.Bg;
            canvas.Paint += delegate(object s, PaintEventArgs e)
            {
                long t0 = clock.ElapsedTicks;
                frame.Draw(e.Graphics);
                double ms = (clock.ElapsedTicks - t0) * 1000.0 / Stopwatch.Frequency;
                paintMs = paintMs * 0.9 + ms * 0.1; // smoothed paint cost
            };
            canvas.Resize += delegate { OnCanvasResize(); };
            canvas.MouseWheel += delegate(object s, MouseEventArgs e) { if (frame.Wheel(new PointF(e.X, e.Y), e.Delta)) { } };
            canvas.MouseMove += OnCanvasMove;
            canvas.MouseDown += OnCanvasDown;
            canvas.MouseUp += OnCanvasUp;
            canvas.MouseLeave += delegate { frame.Mouse = new PointF(-1, -1); frame.MouseDown = false; };
            Controls.Add(canvas);

            timer = new Timer();
            timer.Interval = 15; // fires every system tick (~64 Hz at the default 15.6 ms resolution)
            timer.Tick += OnTick;
            saveTimer = new Timer();
            saveTimer.Interval = 600;
            saveTimer.Tick += delegate { saveTimer.Stop(); SaveNow(); };
            resizeTimer = new Timer();
            resizeTimer.Interval = 100; // SPEC: fonts follow the window size, rebuilt ~100 ms after a resize
            resizeTimer.Tick += delegate { resizeTimer.Stop(); ApplyScale(); };

            // select the first page BEFORE any layout (fields need a current step), then lay out at the real size
            int start = g.TutorialDone ? 0 : lastIndex;
            if (start < 0 || start >= steps.Count) start = 0;
            frame.Go(start);
            ResumeLayout(true);
            layoutReady = true;
            frame.SetClient(LayoutSize(), k * uiScale);
        }

        /// <summary>The canvas size, or the form's client size before the canvas is docked.</summary>
        private Size LayoutSize()
        {
            Size s = canvas.ClientSize;
            if (s.Width <= 0 || s.Height <= 0) s = ClientSize;
            return s;
        }

        /// <summary>SPEC "dynamic font size by window size": the shared Theme.cs rule (UiScale.For, 1.0 .. 1.8).</summary>
        private float ScaleFor(Size client)
        {
            return (float)UiScale.For(client.Width, client.Height, 96f * k);
        }

        private void OnCanvasResize()
        {
            if (!layoutReady) return;
            Size sz = LayoutSize();
            if (sz.Width <= 0 || sz.Height <= 0) return;
            frame.SetClient(sz, k * uiScale);          // follow the size now with the current fonts
            resizeTimer.Stop();
            resizeTimer.Start();                       // rebuild the fonts once the size settles
        }

        /// <summary>Recreates the fonts when the window-size scale moved a whole step (disposes the old ones).</summary>
        private void ApplyScale()
        {
            if (closing || IsDisposed) return;
            Size sz = LayoutSize();
            float s = ScaleFor(sz);
            if (Math.Abs(s - uiScale) < 0.001f) return;
            uiScale = s;
            gx.SetFonts(new TutorialFonts(uiFamily, monoFamily, uiScale));
            Font old = ctlFont;
            ctlFont = new Font(uiFamily, TutorialFonts.NumberPt * uiScale);
            foreach (Control c in fieldCtl) c.Font = ctlFont;
            if (old != null) old.Dispose();
            frame.SetClient(sz, k * uiScale);
            canvas.Invalidate();
        }

        // ------------------------------------------------------------------ setup helpers
        private static float SystemScale()
        {
            try
            {
                using (Graphics gr = Graphics.FromHwnd(IntPtr.Zero))
                {
                    float s = gr.DpiX / 96f;
                    if (s >= 0.5f && s <= 5f) return s;
                }
            }
            catch (Exception) { }
            return 1f;
        }

        private static FontFamily PickFamily(string[] names, FontFamily fallback)
        {
            foreach (string n in names)
            {
                try { FontFamily f = new FontFamily(n); return f; }
                catch (Exception) { }
            }
            return fallback;
        }

        [DllImport("dwmapi.dll")]
        private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int size);

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            try
            {
                int on = 1;
                if (DwmSetWindowAttribute(Handle, 20, ref on, 4) != 0) DwmSetWindowAttribute(Handle, 19, ref on, 4); // dark title bar
            }
            catch (Exception) { }
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            try { if (Owner != null && Owner.Icon != null) Icon = Owner.Icon; } catch (Exception) { }
            lastTicks = clock.ElapsedTicks;
            timer.Start();
            canvas.Focus();
        }

        // ------------------------------------------------------------------ frame loop
        private void OnTick(object sender, EventArgs e)
        {
            if (closing || IsDisposed) return;
            long now = clock.ElapsedTicks;
            double dtMs = (now - lastTicks) * 1000.0 / Stopwatch.Frequency;
            lastTicks = now;
            if (WindowState == FormWindowState.Minimized) return;
            bool active = Form.ActiveForm == this;
            ReadLive(active);
            frame.Update(dtMs);
            // inactive (e.g. testing in the game on another screen): ~20 fps is plenty and saves CPU; a slow paint (very
            // large window on a slow PC) drops to ~32 fps so the window stays responsive
            frameSkip++;
            if (!active && (frameSkip % 3) != 0) return;
            if (active && paintMs > 11 && (frameSkip % 2) != 0) return;
            canvas.Invalidate();
        }

        private void ReadLive(bool active)
        {
            InputState raw = active ? MotionEngine.ReadInput(g.Keys, isDown) : new InputState();
            InputState live = filter.Next(raw, true, true); // like the overlay: opposite keys, last pressed wins
            bool keyFire = active && g.Keys != null && g.Keys.Fire > 6 && raw.Fire; // 开火 bound to a keyboard key
            live.Fire = false;                                                    // mouse buttons: only clicks on the scene count
            bool fire = (mouseFire && active) || keyFire;
            ctx.Live = live;
            ctx.LiveFire = fire;
            ctx.LiveMask = TKey.Of(live, fire);
        }

        // ------------------------------------------------------------------ mouse
        private PointF P(MouseEventArgs e) { return new PointF(e.X, e.Y); }

        private void OnCanvasMove(object sender, MouseEventArgs e)
        {
            frame.Mouse = P(e);
            Cursor c = frame.Clickable(P(e)) ? Cursors.Hand : Cursors.Default;
            if (canvas.Cursor != c) canvas.Cursor = c;
        }

        private static int Vk(MouseButtons b)
        {
            switch (b)
            {
                case MouseButtons.Left: return 1;
                case MouseButtons.Right: return 2;
                case MouseButtons.Middle: return 4;
                case MouseButtons.XButton1: return 5;
                case MouseButtons.XButton2: return 6;
                default: return 0;
            }
        }

        private void OnCanvasDown(object sender, MouseEventArgs e)
        {
            canvas.Focus(); // commits a number box being typed in
            PointF p = P(e);
            frame.Mouse = p;
            frame.MouseDown = e.Button == MouseButtons.Left;
            downHit = frame.HitTest(p, out downDot);
            downChip = downHit == TutorialHit.Scene ? gx.HitChip(p) : -1;
            bool fireButton = e.Button == MouseButtons.Left || (g.Keys != null && Vk(e.Button) == g.Keys.Fire);
            if (downHit == TutorialHit.Scene && downChip < 0 && fireButton && frame.Current != null && frame.Current.ClickFires) mouseFire = true;
        }

        private void OnCanvasUp(object sender, MouseEventArgs e)
        {
            PointF p = P(e);
            mouseFire = false;
            frame.MouseDown = false;
            if (e.Button != MouseButtons.Left) return;
            int dot;
            TutorialHit up = frame.HitTest(p, out dot);
            if (up != downHit) return;
            switch (up)
            {
                case TutorialHit.Next:
                    if (frame.IsLast) { Finish(); CloseAndOpen(TutorialPages.Recoil); }
                    else frame.Next(false);
                    break;
                case TutorialHit.Skip: frame.Next(true); break;
                case TutorialHit.Prev: frame.Prev(); break;
                case TutorialHit.Exit: Close(); break;
                case TutorialHit.Dot: if (dot == downDot) frame.Go(dot); break;
                case TutorialHit.SettingsLink:
                    if (!string.IsNullOrEmpty(frame.Current.SettingsPage)) CloseAndOpen(frame.Current.SettingsPage);
                    break;
                case TutorialHit.Expander: frame.ToggleExpander(); break;
                case TutorialHit.DevNote: frame.ToggleDevNote(); break;
                case TutorialHit.Text: frame.FinishTyping(); break;
                case TutorialHit.Scene:
                    int chip = gx.HitChip(p);
                    if (chip >= 0 && chip == downChip) { try { frame.Current.OnChip(ctx, chip); } catch (Exception) { } }
                    break;
            }
        }

        protected override void OnDeactivate(EventArgs e)
        {
            base.OnDeactivate(e);
            mouseFire = false;
            frame.MouseDown = false;
        }

        // ------------------------------------------------------------------ keys
        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            bool inBox = ActiveControl is NumericUpDown || (ActiveControl != null && ActiveControl.Parent is NumericUpDown);
            if (inBox)
            {
                // the demo keys (W A S D Q E Space ...) must not beep or type into a number box
                if ((e.KeyCode >= Keys.A && e.KeyCode <= Keys.Z) || e.KeyCode == Keys.Space) { e.Handled = true; e.SuppressKeyPress = true; }
                if (e.KeyCode == Keys.Enter) { e.Handled = true; e.SuppressKeyPress = true; canvas.Focus(); }
                return;
            }
            if (e.KeyCode == Keys.Enter && ActiveControl == canvas)
            {
                e.Handled = true;
                if (frame.IsLast) { Finish(); CloseAndOpen(TutorialPages.Recoil); } else frame.Next(false);
            }
        }

        // ------------------------------------------------------------------ fields
        private void PlaceFields()
        {
            if (frame == null || frame.Current == null) return; // layout before the first step
            TutorialField[] f = frame.Current.Fields;
            if (f != fieldsShown) BuildFields(f);
            for (int i = 0; i < fieldCtl.Count; i++)
            {
                RectangleF r = frame.FieldRect(i);
                Control c = fieldCtl[i];
                if (r.IsEmpty) { c.Visible = false; continue; }
                c.Bounds = new Rectangle((int)Math.Round(r.X), (int)Math.Round(r.Y), (int)Math.Round(r.Width), (int)Math.Round(r.Height));
                if (!c.Visible) c.Visible = true;
            }
            RefreshFields();
        }

        private void BuildFields(TutorialField[] f)
        {
            canvas.SuspendLayout();
            foreach (Control c in fieldCtl) { canvas.Controls.Remove(c); c.Dispose(); }
            fieldCtl.Clear();
            fieldsShown = f;
            int n = f == null ? 0 : f.Length;
            for (int i = 0; i < n; i++)
            {
                int idx = i;
                TutorialField fd = f[i];
                if (fd.Kind == TutorialField.KindCheck)
                {
                    CheckBox cb = new CheckBox();
                    cb.Text = "";
                    cb.AutoSize = false;
                    cb.Size = new Size((int)(22 * k * uiScale), (int)(22 * k * uiScale));
                    cb.BackColor = gx.Pal.Panel;
                    cb.FlatStyle = FlatStyle.Flat;
                    cb.FlatAppearance.BorderColor = gx.Pal.Border;
                    cb.CheckedChanged += delegate { OnCheck(idx); };
                    fieldCtl.Add(cb);
                    canvas.Controls.Add(cb);
                }
                else
                {
                    NumericUpDown nud = new NumericUpDown();
                    nud.Font = ctlFont;
                    nud.BorderStyle = BorderStyle.FixedSingle;
                    nud.BackColor = Color.FromArgb(0x2F, 0x33, 0x38);
                    nud.ForeColor = gx.Pal.Text;
                    nud.DecimalPlaces = Math.Max(0, Math.Min(2, fd.Decimals));
                    nud.Minimum = (decimal)fd.Min;
                    nud.Maximum = (decimal)fd.Max;
                    nud.Increment = (decimal)(fd.Increment > 0 ? fd.Increment : 1);
                    nud.TextAlign = HorizontalAlignment.Left; // like the settings pages (SettingsForm number boxes)
                    nud.ValueChanged += delegate { OnNumber(idx); };
                    nud.MouseWheel += delegate(object ws, MouseEventArgs we)
                    {
                        // the wheel scrolls the panel unless the pointer is on this (focused) box: no accidental value changes
                        Point cp = canvas.PointToClient(Cursor.Position);
                        if (nud.Focused && nud.Bounds.Contains(cp)) return;
                        HandledMouseEventArgs h = we as HandledMouseEventArgs;
                        if (h != null) h.Handled = true;
                        frame.Wheel(new PointF(cp.X, cp.Y), we.Delta);
                    };
                    fieldCtl.Add(nud);
                    canvas.Controls.Add(nud);
                }
            }
            canvas.ResumeLayout(false);
        }

        private static decimal Dec(double v, decimal min, decimal max)
        {
            if (double.IsNaN(v) || double.IsInfinity(v)) v = 0;
            decimal d;
            try { d = (decimal)v; } catch (OverflowException) { d = v > 0 ? max : min; }
            if (d < min) d = min;
            if (d > max) d = max;
            return d;
        }

        /// <summary>Re-reads every field from the profile (values, enabled state).</summary>
        private void RefreshFields()
        {
            TutorialField[] f = fieldsShown;
            Profile p = ctx.P;
            if (f == null || p == null) return;
            updatingFields = true;
            try
            {
                for (int i = 0; i < f.Length && i < fieldCtl.Count; i++)
                {
                    TutorialField fd = f[i];
                    bool en = fd.Enabled == null || fd.Enabled(p);
                    NumericUpDown nud = fieldCtl[i] as NumericUpDown;
                    if (nud != null)
                    {
                        decimal v = Dec(fd.Get(p), nud.Minimum, nud.Maximum);
                        decimal r = Math.Round(v, nud.DecimalPlaces, MidpointRounding.AwayFromZero);
                        if (nud.Value != r) nud.Value = r;
                        if (nud.Enabled != en) nud.Enabled = en;
                    }
                    CheckBox cb = fieldCtl[i] as CheckBox;
                    if (cb != null)
                    {
                        bool v = fd.GetCheck != null && fd.GetCheck(p);
                        if (cb.Checked != v) cb.Checked = v;
                        if (cb.Enabled != en) cb.Enabled = en;
                    }
                }
            }
            finally { updatingFields = false; }
        }

        private void OnNumber(int i)
        {
            if (updatingFields || fieldsShown == null || i >= fieldsShown.Length) return;
            Profile p = ctx.P;
            NumericUpDown nud = fieldCtl[i] as NumericUpDown;
            if (p == null || nud == null) return;
            TutorialField fd = fieldsShown[i];
            if (fd.Set != null) fd.Set(p, (double)nud.Value);
            if (fd.After != null) fd.After(p);
            AfterEdit(true);
        }

        private void OnCheck(int i)
        {
            if (updatingFields || fieldsShown == null || i >= fieldsShown.Length) return;
            Profile p = ctx.P;
            CheckBox cb = fieldCtl[i] as CheckBox;
            if (p == null || cb == null) return;
            TutorialField fd = fieldsShown[i];
            if (fd.SetCheck != null) fd.SetCheck(p, cb.Checked);
            if (fd.After != null) fd.After(p);
            AfterEdit(true);
        }

        /// <summary>A value changed: save soon, tell the app, let the step refresh its demo, re-read dependent fields.</summary>
        private void AfterEdit(bool fromField)
        {
            dirty = true;
            saveTimer.Stop();
            saveTimer.Start();
            Action h = ValuesChanged;
            if (h != null) { try { h(); } catch (Exception) { } }
            TutorialStep cur = frame.Current;
            if (fromField && cur != null) { try { cur.OnFieldChanged(ctx); } catch (Exception) { } }
            // texts with placeholders (e.g. 「当前：{当前上抬} px」) show the new value at once
            if (cur != null && HasPlaceholder(cur)) frame.RefreshText();
            RefreshFields();
        }

        private static bool HasPlaceholder(TutorialStep s)
        {
            if (Has(s.Title) || Has(s.Body) || Has(s.Note) || Has(s.DevNote) || Has(s.FieldNote) || Has(s.Hint)) return true;
            if (s.Prompts != null) foreach (string p in s.Prompts) if (Has(p)) return true;
            return false;
        }

        private static bool Has(string t) { return t != null && t.IndexOf('{') >= 0; }

        // ------------------------------------------------------------------ save / finish / close
        private void SaveNow()
        {
            string err = SettingsIO.Save(g, SettingsIO.DefaultPath());
            if (err == null) dirty = false;
            else ctx.Term.Push("> 保存失败：" + err);
        }

        private void Finish()
        {
            if (!g.TutorialDone) g.TutorialDone = true;
            finished = true;
            saveTimer.Stop();
            SaveNow();
            Action h = ValuesChanged;
            if (h != null) { try { h(); } catch (Exception) { } }
        }

        private void CloseAndOpen(string page)
        {
            Close();
            if (jumpToPage != null && !string.IsNullOrEmpty(page)) { try { jumpToPage(page); } catch (Exception) { } }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            if (e.Cancel) return;
            closing = true;
            timer.Stop();
            saveTimer.Stop();
            if (dirty) SaveNow();
            lastIndex = finished ? 0 : Math.Max(0, frame.Index);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                timer.Stop(); timer.Dispose();
                saveTimer.Stop(); saveTimer.Dispose();
                resizeTimer.Stop(); resizeTimer.Dispose();
                foreach (Control c in fieldCtl) c.Dispose();
                fieldCtl.Clear();
                frame.Dispose();
                gx.Dispose(); // disposes its current fonts
                if (ctlFont != null) ctlFont.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary>The canvas: one double-buffered, opaque, focusable surface.</summary>
        private sealed class Canvas : Control
        {
            public Canvas()
            {
                SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                         ControlStyles.Opaque | ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
                TabStop = true;
                DoubleBuffered = true;
            }

            protected override bool IsInputKey(Keys keyData)
            {
                Keys code = keyData & Keys.KeyCode;
                if (code == Keys.Up || code == Keys.Down || code == Keys.Left || code == Keys.Right) return true;
                return base.IsInputKey(keyData);
            }
        }
    }
}
