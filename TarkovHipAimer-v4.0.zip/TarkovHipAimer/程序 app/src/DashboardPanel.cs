// DashboardPanel.cs -- v4.0 首页 dashboard (WinForms, C# 5 / .NET Framework 4.8).
//
//   new DashboardPanel(new MotionEngine(), app.G)   -> Dock it into the 首页 page.
//
// Pass a MotionEngine that nobody else updates (NOT the overlay's: that one lives on the render thread). By default
// the panel drives it itself on the UI thread: while our window is in front it polls the same key bindings with
// GetAsyncKeyState (MotionEngine.ReadInput), runs the opposite-key filter and MotionEngine.Update in Live mode, and
// draws the engine's public outputs. DriveEngine = false + SetHostInput(...) lets a host drive the engine instead.
//
// Layout: DashLayout (DashboardLogic.cs) computes every rectangle from the client size, the DPI and the measured
// fonts; fonts grow with the window (Theme.UiScale.For, 1.0 .. 1.8) and are rebuilt on resize only. Wide pages: chart +
// 实时数据 card on top, terminal + 按键 card below. Narrow pages: the data card stacks under the chart.
//
// Cost: ~64 Hz tick while visible and in front (10 Hz in the background, 4 Hz hidden). A frame is painted only when
// something on screen changes (idle = only the cursor blink). Static parts (frames, grid, labels) are cached in one
// bitmap; pens, brushes, fonts, paths and strings are cached; steady values allocate nothing per frame.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Windows.Forms;

namespace TarkovCrosshair
{
    public sealed class DashboardPanel : UserControl
    {
        // ------------------------------------------------------------------ texts (zh-CN UI, ASCII log)
        private const string TitleText = "实时仪表盘 // DASHBOARD";
        private const string NoteBackground = "窗口不在前台：已暂停读取按键（回到本窗口即可继续）";
        private const string NoteRingOff = "游戏内准星当前是关闭的；这里的演示照常工作";
        private const string ChartTitle = "准星实时轨迹 · 象限图";
        private const string ChartTag = "// TRACE";
        private const string StatsTitle = "实时数据";
        private const string StatsTag = "// DATA";
        private const string CapsTitle = "按键";
        private const string CapsTag = "// INPUT";
        private const string TermTitle = "root@hip-aimer:~# tail -f motion.log";
        private const string CentreText = "屏幕中心";
        private const string MemLabel = "内存占用";
        private const string MemNote = "很小，不影响游戏";
        private const string LiveTag = "● LIVE";
        private const string PauseTag = "■ PAUSE";
        private static readonly string[] RowLabels = new string[] { "X 偏移", "Y 偏移", "上抬偏移量", "侧身", "持枪手", "方向", "状态" };
        private static readonly string[] StateTexts = BuildStateTexts();

        private const string LogPaused = "> 窗口不在前台：暂停读取按键";
        private const string LogResumed = "> 回到窗口：继续读取按键";
        private static readonly string[] ChartRight = new string[]
        {
            "绿圈 = 这一刻子弹的落点（惯性：向右走，落点偏左）", "绿圈 = 子弹落点（向右走，落点偏左）", "单位 px · Y 向上为正"
        };
        private const string HandRight = "右手";
        private const string HandLeft = "左手（已换手）";

        private static string[] BuildStateTexts()
        {
            // bit 1 = 跳跃中, 2 = 强化准星, 4 = 开镜中, 8 = 冲刺 (Shift + W)
            string[] r = new string[16];
            for (int i = 0; i < 16; i++)
            {
                List<string> parts = new List<string>();
                if ((i & 8) != 0) parts.Add("冲刺");
                if ((i & 1) != 0) parts.Add("跳跃中");
                if ((i & 2) != 0) parts.Add("强化准星");
                if ((i & 4) != 0) parts.Add("开镜中");
                r[i] = parts.Count == 0 ? "—" : string.Join(" · ", parts.ToArray());
            }
            return r;
        }

        // ------------------------------------------------------------------ model
        private readonly MotionEngine engine;
        private GlobalSettings settings;
        private bool driveEngine = true;
        private InputState hostInput;
        private LiveInputFilter filter = new LiveInputFilter();
        private readonly Func<int, bool> isDown = Native.IsDown; // cached delegate (no allocation per poll)

        // ------------------------------------------------------------------ timing
        private readonly System.Windows.Forms.Timer timer;
        private readonly Stopwatch clock = Stopwatch.StartNew();
        private long lastTicks;
        private double nowMs;
        private int interval;
        private bool wasLive;
        private bool foreground = true;
        private double lastFgMs = double.NegativeInfinity;
        private int errors;
        private bool failed;
        private bool disposedFlag;
        private bool booted;

        // ------------------------------------------------------------------ live state
        private readonly DashTrail trail = new DashTrail(160, 1200);
        private readonly DashLog log = new DashLog(48);
        private readonly DashScale scale = new DashScale();
        private double shownRange = 30;
        private double uiX, uiY, drawnX = double.NaN, drawnY = double.NaN;
        private readonly DashEvents events = new DashEvents();
        private readonly float[] glow = new float[DashKeys.Count];
        private readonly int[] glowBucket = new int[DashKeys.Count];
        private readonly float[] rowFlash = new float[DashLayout.RowCount];
        private readonly int[] rowBucket = new int[DashLayout.RowCount];
        private bool cursorOn;
        private int drawnLogVersion = -1;
        private string note = "";
        private string hintText = "";
        private int keySig;
        private bool keySigValid;
        private double lastKeyCheckMs = double.NegativeInfinity;
        private readonly string[] capLabels = new string[DashKeys.Count];
        private readonly bool[] capAscii = new bool[DashKeys.Count];
        private readonly bool[] capUseUi = new bool[DashKeys.Count];

        private readonly DashText txX = new DashText(), txY = new DashText(), txRise = new DashText(), txMem = new DashText();
        private string leanText = "居中";
        private long leanKey = long.MinValue;
        private string dirText = "静止", handText = HandRight, stateText = "—";
        private double lastTextMs = double.NegativeInfinity;

        private Process proc;
        private double lastMemMs = double.NegativeInfinity;

        private readonly char[] decodeBuf = new char[TitleText.Length];
        private string titleShown = TitleText;
        private double decodeStartMs = double.NaN;
        private int decodeFrame = -1;
        private const double DecodeMs = 900;

        // ------------------------------------------------------------------ layout (pixels)
        private float s = 1f;          // pixels per design unit (DPI scale x zoom)
        private double fontZoom = -1;
        private long lastResizeMs = long.MinValue / 2;
        private bool zoomPending;
        private bool layoutDirty = true;
        private readonly DashLayout lay = new DashLayout();
        private Rectangle rHeader, rTitle, rNote, rRight1, rRight2, rChart, rChartTitle, rChartInner, rStats, rStatsTitle;
        private Rectangle rTerm, rTermTitle, rTermInner, rCapsCard, rCapsTitle, rCombo;
        private readonly string[] comboTexts = new string[1 << DashKeys.Count]; // "> W+D" per key mask, built once per binding set
        private string[] logNames = DashKeys.Names;
        private int shownMask;
        private Rectangle rMemVal, rMemLab;
        private readonly Rectangle[] rRows = new Rectangle[DashLayout.RowCount];
        private int rowsShown;
        private readonly Rectangle[] rCaps = new Rectangle[DashKeys.Count];
        private readonly GraphicsPath[] capPaths = new GraphicsPath[DashKeys.Count];
        private readonly GraphicsPath[] glowPaths = new GraphicsPath[DashKeys.Count];
        private bool capsShown;
        private float charW;
        private float lineH;
        private float titleW;
        private float uiEm = 14f;
        private Rectangle rPlate;
        private bool plateShown;

        // ------------------------------------------------------------------ static layer
        private Bitmap staticBmp;
        private bool staticDirty = true;

        // ------------------------------------------------------------------ resources
        private static readonly Color ColGreen = Theme.ColRingInner;
        private static readonly Color ColTermBg = Color.FromArgb(0x07, 0x0A, 0x08);
        private static readonly Color ColChartBg = Theme.Blend(Theme.ColBackground, Color.Black, 0.35);
        private static readonly Color ColGreenDim = Theme.Blend(ColTermBg, Theme.ColRingInner, 0.64); // 4.8:1 on the terminal (SPEC: >= 4.5:1)
        private static readonly Color ColGreenMid = Theme.Blend(ColTermBg, Theme.ColRingInner, 0.70);
        private static readonly Color ColBright = Color.FromArgb(0x7C, 0xFF, 0x7C);
        private static readonly Color ColTag = Theme.Blend(Theme.ColSurface, Theme.ColRingInner, 0.75); // 6.1:1 on the cards, 6.6:1 on the chart (SPEC >= 4.5:1)

        private Font fTitle, fBody, fSmall, fMono, fMonoSmall, fValue, fCap, fCapUi, fTag, fTermUi;
        private SolidBrush bBack, bSurface, bChartBg, bText, bMuted, bAccent, bGreen, bGreenDim, bGreenMid, bTermBg, bWarn, bTag;
        private Pen pBorder, pGrid, pGridMinor, pAxis, pVector, pRingGlow, pRingOuter, pRingInner, pOrigin, pTermBorder, pHeaderLine;
        private Pen pBracket, pProj, pTick, pPlate;
        private readonly Pen[] trailPens = new Pen[12];
        private readonly SolidBrush[] capFill = new SolidBrush[4];
        private readonly SolidBrush[] capGlowFill = new SolidBrush[4];
        private readonly SolidBrush[] capTextB = new SolidBrush[4];
        private readonly SolidBrush[] valueB = new SolidBrush[4];
        private readonly SolidBrush[] riseB = new SolidBrush[4];
        private readonly Pen[] capBorder = new Pen[4];
        private TextureBrush scanBrush;
        private Bitmap scanBmp;
        private StringFormat sfTypo, sfCenter, sfRight, sfLeftMid, sfRightMid;
        private StringFormat sfLeftTop, sfRightTop, sfLeftBottom, sfRightBottom;
        private readonly Dictionary<int, string> gridLabels = new Dictionary<int, string>();

        // ================================================================== public API

        public DashboardPanel(MotionEngine engine, GlobalSettings g)
        {
            if (engine == null) throw new ArgumentNullException("engine");
            if (g == null) throw new ArgumentNullException("g");
            this.engine = engine;
            this.settings = g;

            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.ResizeRedraw | ControlStyles.Opaque, true);
            SetStyle(ControlStyles.Selectable, false);
            DoubleBuffered = true;
            TabStop = false;
            BackColor = Theme.ColBackground;
            ForeColor = Theme.ColText;

            CreateResources();
            RefreshKeyNames();
            try { proc = Process.GetCurrentProcess(); } catch { proc = null; }

            timer = new System.Windows.Forms.Timer();
            timer.Tick += OnTick;
            SetInterval(15);
            lastTicks = clock.ElapsedTicks;
        }

        /// <summary>The settings object read every tick (keys, profile, modes). Set it again if the host replaces its GlobalSettings.</summary>
        public GlobalSettings Settings
        {
            get { return settings; }
            set { if (value != null) { settings = value; keySigValid = false; lastKeyCheckMs = double.NegativeInfinity; } }
        }

        /// <summary>True (default): the panel reads keys and updates the engine itself. False: the host updates the engine and
        /// hands the raw key state in with SetHostInput (the key caps / log then show that state).</summary>
        public bool DriveEngine
        {
            get { return driveEngine; }
            set { driveEngine = value; }
        }

        /// <summary>Raw (unfiltered) key state from the host, used when DriveEngine is false.</summary>
        public void SetHostInput(InputState raw) { hostInput = raw; }

        /// <summary>Adds a line to the terminal box (ASCII recommended: the box uses a monospace Latin font).</summary>
        public void AppendLog(string line)
        {
            if (string.IsNullOrEmpty(line)) return;
            log.Add(line, nowMs);
        }

        /// <summary>Clears the trail and the log, resets the engine and plays the boot lines again.</summary>
        public void ResetView()
        {
            if (driveEngine) engine.Reset();
            trail.Clear();
            log.Clear();
            scale.Reset();
            filter = new LiveInputFilter();
            events.Reset();
            booted = false;
            staticDirty = true;
            Invalidate();
        }

        // ================================================================== lifecycle

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            if (!disposedFlag) timer.Start();
        }

        protected override void OnHandleDestroyed(EventArgs e)
        {
            timer.Stop();
            base.OnHandleDestroyed(e);
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            lastResizeMs = clock.ElapsedMilliseconds;
            layoutDirty = true;
            staticDirty = true;
        }

        protected override void OnDpiChangedAfterParent(EventArgs e)
        {
            base.OnDpiChangedAfterParent(e);
            layoutDirty = true;
            staticDirty = true;
            fontZoom = -1;
            Invalidate();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && !disposedFlag)
            {
                disposedFlag = true;
                try { timer.Stop(); timer.Tick -= OnTick; timer.Dispose(); } catch { }
                DisposeResources();
                if (staticBmp != null) { staticBmp.Dispose(); staticBmp = null; }
                for (int i = 0; i < DashKeys.Count; i++)
                {
                    if (capPaths[i] != null) { capPaths[i].Dispose(); capPaths[i] = null; }
                    if (glowPaths[i] != null) { glowPaths[i].Dispose(); glowPaths[i] = null; }
                }
                if (proc != null) { try { proc.Dispose(); } catch { } proc = null; }
            }
            base.Dispose(disposing);
        }

        private void SetInterval(int ms)
        {
            if (ms == interval) return;
            interval = ms;
            timer.Interval = ms;
        }

        private bool CanAnimate()
        {
            if (!Visible || Width < 8 || Height < 8 || !IsHandleCreated) return false;
            Form f = FindForm();
            if (f == null || !f.Visible || f.WindowState == FormWindowState.Minimized) return false;
            return true;
        }

        // ================================================================== tick (UI thread)

        private void OnTick(object sender, EventArgs e)
        {
            if (disposedFlag || failed) return;
            try { Tick(); }
            catch (Exception)
            {
                errors++;
                if (errors >= 50)
                {
                    failed = true;
                    timer.Stop();
                    Invalidate();
                }
            }
        }

        /// <summary>Hint line, key-cap labels: rebuilt only when a shown key is rebound (checked twice a second).</summary>
        private void RefreshKeyNames()
        {
            KeyBindings k = settings != null ? settings.Keys : null;
            keySig = DashKeyNames.Signature(k);
            keySigValid = true;
            hintText = DashKeyNames.HintLine(k);
            logNames = DashKeyNames.LogNames(k);
            events.Names = logNames;
            Array.Clear(comboTexts, 0, comboTexts.Length);
            for (int i = 0; i < DashKeys.Count; i++)
            {
                bool ascii;
                capLabels[i] = DashKeyNames.Cap(k, i, out ascii);
                capAscii[i] = ascii;
            }
            layoutDirty = true;   // cap labels are fitted to the caps in DoLayout
            staticDirty = true;
        }

        private void Tick()
        {
            long t = clock.ElapsedTicks;
            double dt = (t - lastTicks) / (double)Stopwatch.Frequency;
            lastTicks = t;
            nowMs = t * 1000.0 / Stopwatch.Frequency;

            if (!CanAnimate())
            {
                if (wasLive) { wasLive = false; filter = new LiveInputFilter(); }
                SetInterval(250);
                return;
            }
            bool becameLive = !wasLive;
            if (becameLive)
            {
                wasLive = true;
                dt = 0;
                decodeStartMs = nowMs; // the title decodes every time the dashboard comes into view
                decodeFrame = -1;
            }
            GlobalSettings g = settings;
            if (nowMs - lastKeyCheckMs >= 500)
            {
                lastKeyCheckMs = nowMs;
                if (!keySigValid || DashKeyNames.Signature(g.Keys) != keySig) RefreshKeyNames();
            }
            if (!booted) Boot();

            // Foreground (our process) polled at 4 Hz; keys are only read while our window is in front.
            if (nowMs - lastFgMs >= 250)
            {
                lastFgMs = nowMs;
                int fg = Native.ForegroundIsOurs();
                if (fg != -1)
                {
                    bool now = fg == 1;
                    if (now != foreground && !becameLive) log.Add(now ? LogResumed : LogPaused, nowMs);
                    foreground = now;
                }
            }
            SetInterval(foreground ? 15 : 100);

            InputState raw;
            int dirIdx;
            bool sprint;
            if (driveEngine)
            {
                raw = new InputState();
                if (foreground && g.Keys != null) raw = MotionEngine.ReadInput(g.Keys, isDown);
                InputState resolved = filter.Next(raw, true, true);
                sprint = resolved.Shift && resolved.Fwd;    // 冲刺 = Shift + resolved W (MotionEngine's rule)
                dirIdx = MotionEngine.DirIndex(resolved); // the same table MotionEngine.Update uses for this input
                Profile p = g.Active;
                if (p != null)
                {
                    engine.GameFocused = true;   // the dashboard is its own window: the 只在塔科夫前台 gate does not apply here
                    engine.OwnForeground = true;
                    engine.Update(dt, resolved, p, g, PreviewMode.Live, 1.0);
                }
            }
            else { raw = hostInput; dirIdx = MotionEngine.DirIndex(raw); sprint = raw.Shift && raw.Fwd; }

            bool paint = false;

            // ---- position + trail
            double x = engine.OffsetX, y = -engine.OffsetY; // UI coords: X right +, Y up +
            if (double.IsNaN(x) || double.IsInfinity(x)) x = 0;
            if (double.IsNaN(y) || double.IsInfinity(y)) y = 0;
            uiX = x; uiY = y;
            if (Math.Abs(x - drawnX) > 0.01 || Math.Abs(y - drawnY) > 0.01 || double.IsNaN(drawnX)) paint = true;
            trail.Add(nowMs, x, y, 0.2);
            trail.Trim(nowMs);
            if (trail.Count > 0) paint = true;

            // ---- chart range
            double peak = Math.Max(trail.AbsPeak(), Math.Max(Math.Abs(x), Math.Abs(y)));
            scale.Update(peak, nowMs);
            double target = scale.Range;
            if (shownRange != target)
            {
                double k = 1.0 - Math.Exp(-Math.Max(dt, 0.001) * 12.0);
                shownRange += (target - shownRange) * k;
                if (Math.Abs(shownRange - target) < target * 0.004) shownRange = target;
                staticDirty = true;
                paint = true;
            }

            // ---- keys, events
            int mask = DashKeys.FromInput(raw);
            if (mask != shownMask) { shownMask = mask; paint = true; }
            bool hand = engine.LiveSwitched, boost = engine.LiveBoost;
            bool ads = engine.AdsActive;
            if (events.Step(mask, hand, boost, ads, x, y, nowMs, log) > 0) paint = true;

            float fall = (float)(dt / 0.18);
            for (int i = 0; i < DashKeys.Count; i++)
            {
                bool down = (mask & DashKeys.Bits[i]) != 0;
                float gl = glow[i];
                if (down) gl = 1f;
                else if (gl > 0f) { gl -= fall; if (gl < 0f) gl = 0f; }
                glow[i] = gl;
                int b = (int)Math.Round(gl * 3f);
                if (b != glowBucket[i]) { glowBucket[i] = b; paint = true; }
            }

            // ---- texts (20 Hz); a changed value flashes bright and fades back ("decoded" feel)
            if (nowMs - lastTextMs >= 50)
            {
                lastTextMs = nowMs;
                if (txX.Signed1(x, "", " px")) Flash(0);
                if (txY.Signed1(y, "", " px")) Flash(1);
                if (txRise.Abs1(engine.Recoil * g.ResolutionScale, "", " px")) Flash(2);
                double ln = engine.Lean;
                if (double.IsNaN(ln)) ln = 0;
                long pct = (long)Math.Round(Math.Abs(ln) * 100.0);
                if (pct > 100) pct = 100;
                long lk = ln < 0 ? -pct : pct;
                if (lk != leanKey)
                {
                    leanKey = lk;
                    leanText = pct == 0 ? "居中" : (ln < 0 ? "左 " : "右 ") + pct.ToString() + "%";
                    Flash(3);
                }
                string hn = engine.Hand == 1 ? HandLeft : HandRight;
                if (!ReferenceEquals(hn, handText)) { handText = hn; Flash(4); }
                string dn = dirIdx >= 0 && dirIdx < Profile.DirNames.Length ? Profile.DirNames[dirIdx] : "静止";
                if (!ReferenceEquals(dn, dirText)) { dirText = dn; Flash(5); }
                string st = StateTexts[(engine.Jumping ? 1 : 0) | (engine.Boosted ? 2 : 0) | (ads ? 4 : 0) | (sprint ? 8 : 0)];
                if (!ReferenceEquals(st, stateText)) { stateText = st; Flash(6); }
                string nt = !foreground ? NoteBackground : (!g.Enabled ? NoteRingOff : hintText);
                if (!ReferenceEquals(nt, note)) { note = nt; paint = true; }
            }
            float fade = (float)(dt / 0.45);
            for (int i = 0; i < rowFlash.Length; i++)
            {
                float v = rowFlash[i];
                if (v > 0f) { v -= fade; if (v < 0f) v = 0f; rowFlash[i] = v; }
                int b = (int)Math.Ceiling(v * 3f - 0.001f);
                if (b < 0) b = 0;
                if (b != rowBucket[i]) { rowBucket[i] = b; paint = true; }
            }

            // ---- memory (1 s)
            if (nowMs - lastMemMs >= 1000)
            {
                lastMemMs = nowMs;
                if (ReadMemory()) paint = true;
            }

            // ---- terminal + title
            bool cur = log.Typing(nowMs) || ((long)(nowMs / 530.0) % 2) == 0;
            if (cur != cursorOn) { cursorOn = cur; paint = true; }
            if (log.Typing(nowMs) || log.Version != drawnLogVersion) paint = true;
            if (!double.IsNaN(decodeStartMs))
            {
                double prog = (nowMs - decodeStartMs) / DecodeMs;
                int frame = (int)((nowMs - decodeStartMs) / 40.0); // new scramble 25 times a second
                if (prog >= 1)
                {
                    titleShown = TitleText;
                    decodeStartMs = double.NaN;
                    paint = true;
                }
                else if (frame != decodeFrame)
                {
                    decodeFrame = frame;
                    DashDecode.Fill(decodeBuf, TitleText, prog, frame);
                    titleShown = new string(decodeBuf); // bounded: only during the 0.9 s decode
                    paint = true;
                }
            }
            if (zoomPending && clock.ElapsedMilliseconds - lastResizeMs >= 100) { zoomPending = false; layoutDirty = true; staticDirty = true; }
            if (staticDirty || layoutDirty) paint = true;

            if (paint) Invalidate();
        }

        private void Flash(int row)
        {
            if (row >= 0 && row < rowFlash.Length) rowFlash[row] = 1f;
        }

        private void Boot()
        {
            booted = true;
            log.Add("> hip-aimer " + Program.Version + " :: 仪表盘已启动", nowMs);
            log.Add("> 载入运动核心 ........ OK", nowMs);
            log.Add("> 只读取键盘鼠标按键，不读取、不修改游戏", nowMs);
            string[] tryLines = DashKeyNames.TryLines(settings != null ? settings.Keys : null);
            log.Add(tryLines[0], nowMs);
            log.Add(tryLines[1], nowMs);
        }

        private bool ReadMemory()
        {
            if (proc == null) return false;
            try
            {
                proc.Refresh();
                return txMem.Megabytes(proc.PrivateMemorySize64, "", "");
            }
            catch { return false; }
        }

        // ================================================================== layout

        private int S(float px) { return (int)Math.Round(px * s); }

        private static Rectangle R(DashRect r) { return new Rectangle(r.X, r.Y, r.W, r.H); }

        private void DoLayout(Graphics gr)
        {
            layoutDirty = false;
            int dpi = 96;
            try { dpi = DeviceDpi; } catch { }
            if (dpi <= 0) dpi = 96;
            float ds = dpi / 96f;
            int w = Math.Max(1, ClientSize.Width), h = Math.Max(1, ClientSize.Height);

            // SPEC "dynamic font size by window size": the scale follows the WINDOW's client size (same Theme.UiScale.For
            // as the settings pages), fonts are rebuilt only when the step changes and the resize has settled (~100 ms).
            Form host = FindForm();
            Size cs = host != null && host.ClientSize.Width > 0 ? host.ClientSize : new Size(w, h);
            double zoom = UiScale.For(cs.Width, cs.Height, dpi);
            if (zoom != fontZoom)
            {
                if (fontZoom > 0 && clock.ElapsedMilliseconds - lastResizeMs < 100) { zoom = fontZoom; zoomPending = true; }
                else { CreateFonts((float)zoom); fontZoom = zoom; zoomPending = false; }
            }
            s = (float)(ds * zoom);

            // measure the fonts (pixel heights at this Graphics' DPI) and the fixed-width header block
            DashMetrics m = new DashMetrics();
            m.Title = fTitle.GetHeight(gr); m.Body = fBody.GetHeight(gr); m.Small = fSmall.GetHeight(gr);
            m.Value = fValue.GetHeight(gr); m.Mono = Math.Max(fMono.GetHeight(gr), fTermUi.GetHeight(gr)); m.Cap = fCap.GetHeight(gr);
            float memValW = gr.MeasureString("0000.0 MB", fValue, PointF.Empty, sfTypo).Width + 2 * s;
            float memLabW = gr.MeasureString(MemLabel, fSmall, PointF.Empty, sfTypo).Width + 2 * s;
            float noteW = gr.MeasureString(MemNote, fSmall, PointF.Empty, sfTypo).Width + 2 * s;
            m.RightW = Math.Max(memValW + S(6) + memLabW, noteW);
            titleW = gr.MeasureString(TitleText, fTitle, PointF.Empty, sfTypo).Width;
            lay.Arrange(w, h, ds, zoom, m);

            rHeader = R(lay.Header); rTitle = R(lay.HeaderTitle); rNote = R(lay.HeaderNote);
            rRight1 = R(lay.HeaderRight1); rRight2 = R(lay.HeaderRight2);
            rMemVal = new Rectangle(rRight1.Right - (int)memValW, rRight1.Y, (int)memValW, rRight1.Height);
            rMemLab = new Rectangle(Math.Max(rRight1.X, rMemVal.X - S(6) - (int)memLabW), rRight1.Y,
                                    Math.Max(0, Math.Min((int)memLabW, rMemVal.X - S(6) - rRight1.X)), rRight1.Height);
            rChart = R(lay.Chart); rChartTitle = R(lay.ChartTitle); rChartInner = R(lay.ChartInner);
            rStats = R(lay.Data); rStatsTitle = R(lay.DataTitle);
            rTerm = R(lay.Term); rTermTitle = R(lay.TermTitle); rTermInner = R(lay.TermInner);
            rowsShown = lay.RowsShown;
            for (int i = 0; i < rRows.Length; i++) rRows[i] = R(lay.Rows[i]);
            capsShown = lay.CapsShown;
            rCapsCard = R(lay.Caps); rCapsTitle = R(lay.CapsTitle); rCombo = R(lay.CapsCombo);

            float rad = Math.Max(3f, lay.CapSize * 0.16f);
            for (int i = 0; i < DashKeys.Count; i++)
            {
                rCaps[i] = R(lay.CapRects[i]);
                if (capPaths[i] != null) { capPaths[i].Dispose(); capPaths[i] = null; }
                if (glowPaths[i] != null) { glowPaths[i].Dispose(); glowPaths[i] = null; }
                if (!capsShown || rCaps[i].Width < 2 || rCaps[i].Height < 2) continue;
                capPaths[i] = Rounded(rCaps[i], rad);
                Rectangle g2 = rCaps[i];
                g2.Inflate(S(3), S(3));
                glowPaths[i] = Rounded(g2, rad + S(3));
                // ASCII name in the monospace font when it fits, else the short Chinese action name (UI font)
                capUseUi[i] = !capAscii[i];
                if (capAscii[i])
                {
                    float aw = gr.MeasureString(capLabels[i], fCap, PointF.Empty, sfTypo).Width;
                    if (aw > rCaps[i].Width - S(4))
                    {   // too long for the cap: the short Chinese action name, if that is narrower
                        float cw = gr.MeasureString(DashKeyNames.CapFallback[i], fCapUi, PointF.Empty, sfTypo).Width;
                        if (cw < aw) { capLabels[i] = DashKeyNames.CapFallback[i]; capUseUi[i] = true; }
                    }
                }
            }

            ScaledPens();
            charW = 0;
        }

        private static GraphicsPath Rounded(Rectangle r, float rad)
        {
            GraphicsPath p = new GraphicsPath();
            float d = Math.Min(rad * 2, Math.Min(r.Width, r.Height));
            if (d < 1) { p.AddRectangle(r); return p; }
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d - 1, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d - 1, r.Bottom - d - 1, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d - 1, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        // ================================================================== painting

        protected override void OnPaintBackground(PaintEventArgs e) { /* everything is painted in OnPaint */ }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics gr = e.Graphics;
            try
            {
                if (layoutDirty) DoLayout(gr);
                EnsureStatic(gr.DpiX, gr.DpiY);
                int w = ClientSize.Width, h = ClientSize.Height;
                if (staticBmp != null)
                {
                    gr.CompositingMode = CompositingMode.SourceCopy;
                    gr.InterpolationMode = InterpolationMode.NearestNeighbor;
                    gr.DrawImage(staticBmp, new Rectangle(0, 0, w, h), 0, 0, w, h, GraphicsUnit.Pixel);
                    gr.CompositingMode = CompositingMode.SourceOver;
                }
                else gr.Clear(Theme.ColBackground);

                if (failed)
                {
                    gr.DrawString("仪表盘刷新出错，已停止（不影响游戏内准星）", fBody, bWarn, rChartInner, sfCenter);
                    return;
                }
                if (charW <= 0) MeasureMono(gr);

                gr.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
                DrawHeaderDynamic(gr);
                DrawStatsDynamic(gr);
                DrawTerminalDynamic(gr);
                DrawChartDynamic(gr);
                drawnX = uiX; drawnY = uiY;
                drawnLogVersion = log.Version;
            }
            catch (Exception)
            {
                errors++;
            }
        }

        private void MeasureMono(Graphics gr)
        {
            SizeF sz = gr.MeasureString("MMMMMMMMMMMMMMMMMMMM", fMono, PointF.Empty, sfTypo);
            charW = sz.Width / 20f;
            lineH = Math.Max(lay.LineH, 8f);
            uiEm = fTermUi.SizeInPoints * gr.DpiY / 72f;
            if (charW <= 0) charW = 7f * s;
        }

        private void EnsureStatic(float dpiX, float dpiY)
        {
            int w = ClientSize.Width, h = ClientSize.Height;
            if (w < 1 || h < 1) return;
            if (staticBmp == null || staticBmp.Width != w || staticBmp.Height != h)
            {
                if (staticBmp != null) staticBmp.Dispose();
                staticBmp = new Bitmap(w, h, PixelFormat.Format32bppPArgb);
                staticBmp.SetResolution(dpiX > 0 ? dpiX : 96f, dpiY > 0 ? dpiY : 96f); // point-sized fonts render at the screen size
                staticDirty = true;
            }
            if (!staticDirty) return;
            staticDirty = false;
            using (Graphics sg = Graphics.FromImage(staticBmp))
            {
                sg.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
                DrawStatic(sg, w, h);
            }
        }

        // ---------------------------------------------------------------- static layer

        /// <summary>Card title: a small accent bar, the Chinese title, then a dim monospace tag (「// DATA」).</summary>
        private void DrawCardTitle(Graphics sg, Rectangle r, string title, string tag)
        {
            if (r.Width < 4 || r.Height < 4) return;
            int bh = Math.Max(2, r.Height / 2 - S(2));
            sg.FillRectangle(bAccent, r.X, r.Y + (r.Height - bh) / 2, Math.Max(2, S(3)), bh);
            Rectangle t = new Rectangle(r.X + S(9), r.Y, Math.Max(0, r.Width - S(9)), r.Height);
            sg.DrawString(title, fBody, bAccent, t, sfLeftMid);
            if (tag == null) return;
            float tw = sg.MeasureString(title, fBody, PointF.Empty, sfTypo).Width;
            Rectangle g = new Rectangle(t.X + (int)tw + S(8), r.Y, Math.Max(0, t.Right - (t.X + (int)tw + S(8))), r.Height);
            if (g.Width > S(40)) sg.DrawString(tag, fTag, bTag, g, sfLeftMid);
        }

        /// <summary>HUD corner brackets on a card.</summary>
        private void DrawBrackets(Graphics sg, Rectangle r)
        {
            if (r.Width < S(30) || r.Height < S(30)) return;
            int L = S(10);
            int x0 = r.X, y0 = r.Y, x1 = r.Right - 1, y1 = r.Bottom - 1;
            sg.DrawLine(pBracket, x0, y0, x0 + L, y0); sg.DrawLine(pBracket, x0, y0, x0, y0 + L);
            sg.DrawLine(pBracket, x1, y0, x1 - L, y0); sg.DrawLine(pBracket, x1, y0, x1, y0 + L);
            sg.DrawLine(pBracket, x0, y1, x0 + L, y1); sg.DrawLine(pBracket, x0, y1, x0, y1 - L);
            sg.DrawLine(pBracket, x1, y1, x1 - L, y1); sg.DrawLine(pBracket, x1, y1, x1, y1 - L);
        }

        private void DrawStatic(Graphics sg, int w, int h)
        {
            sg.Clear(Theme.ColBackground);

            // header
            sg.FillRectangle(bSurface, rHeader);
            sg.DrawLine(pHeaderLine, 0, rHeader.Bottom - 1, w, rHeader.Bottom - 1);
            if (rMemLab.Width > 0) sg.DrawString(MemLabel, fSmall, bMuted, rMemLab, sfRightMid);
            if (rRight2.Height > 0) sg.DrawString(MemNote, fSmall, bMuted, rRight2, sfRightMid);

            // chart frame + title
            if (rChart.Width > 2 && rChart.Height > 2)
            {
                sg.FillRectangle(bChartBg, rChart);
                sg.DrawRectangle(pBorder, rChart.X, rChart.Y, rChart.Width - 1, rChart.Height - 1);
                sg.DrawLine(pBorder, rChart.X, rChartInner.Y - 1, rChart.Right - 1, rChartInner.Y - 1);
                Rectangle tr = new Rectangle(rChart.X + S(10), rChart.Y, rChart.Width - S(20), rChartTitle.Height);
                DrawCardTitle(sg, tr, ChartTitle, ChartTag);
                {   // right side of the title bar: what the green ring means (the longest text that fits), else the unit
                    float tw = sg.MeasureString(ChartTitle, fBody, PointF.Empty, sfTypo).Width
                             + sg.MeasureString(ChartTag, fTag, PointF.Empty, sfTypo).Width + S(40);
                    for (int i = 0; i < ChartRight.Length; i++)
                    {
                        if (lay.CompactHeader && i == ChartRight.Length - 1) break;   // short page: no unit text
                        float uw = sg.MeasureString(ChartRight[i], fSmall, PointF.Empty, sfTypo).Width;
                        if (tw + uw < tr.Width) { sg.DrawString(ChartRight[i], fSmall, bMuted, tr, sfRightMid); break; }
                    }
                }
                DrawGrid(sg);
                DrawBrackets(sg, rChart);
            }

            // stats card
            if (rStats.Width > 2 && rStats.Height > 2)
            {
                sg.FillRectangle(bSurface, rStats);
                sg.DrawRectangle(pBorder, rStats.X, rStats.Y, rStats.Width - 1, rStats.Height - 1);
                DrawCardTitle(sg, rStatsTitle, StatsTitle, StatsTag);
                int cols = lay.Columns;
                for (int i = 0; i < rowsShown; i++)
                {
                    sg.DrawString(RowLabels[i], fBody, bMuted, rRows[i], sfLeftMid);
                    bool lastInCol = i + cols >= rowsShown;
                    if (!lastInCol)
                        sg.DrawLine(pGridMinor, rRows[i].X, rRows[i].Bottom - 1, rRows[i].Right, rRows[i].Bottom - 1);
                }
                DrawBrackets(sg, rStats);
            }

            // key caps card
            if (capsShown)
            {
                sg.FillRectangle(bSurface, rCapsCard);
                sg.DrawRectangle(pBorder, rCapsCard.X, rCapsCard.Y, rCapsCard.Width - 1, rCapsCard.Height - 1);
                DrawCardTitle(sg, rCapsTitle, CapsTitle, CapsTag);
                DrawBrackets(sg, rCapsCard);
            }

            // terminal frame
            if (rTerm.Width > 2 && rTerm.Height > 2)
            {
                sg.FillRectangle(bTermBg, rTerm);
                int titleBottom = rTermTitle.Bottom;
                sg.DrawLine(pTermBorder, rTerm.X, titleBottom, rTerm.Right - 1, titleBottom);
                int dr = S(4);
                int dotsW = 3 * S(14);
                Rectangle tt = new Rectangle(rTermTitle.X, rTermTitle.Y, Math.Max(0, rTermTitle.Width - dotsW - S(6)), rTermTitle.Height);
                sg.DrawString(TermTitle, fMonoSmall, bGreenMid, tt, sfLeftMid);   // 5.9:1 (thin glyphs measure lower than the colour)
                // three window dots (decoration)
                for (int i = 0; i < 3; i++)
                    sg.FillEllipse(bGreenDim, rTermTitle.Right - (3 - i) * S(14), rTermTitle.Y + rTermTitle.Height / 2 - dr, dr * 2, dr * 2);
                if (scanBrush != null) sg.FillRectangle(scanBrush, rTerm);
                sg.DrawRectangle(pTermBorder, rTerm.X, rTerm.Y, rTerm.Width - 1, rTerm.Height - 1);
            }
        }

        private float Ppu()
        {
            float half = Math.Min(rChartInner.Width, rChartInner.Height) / 2f - S(14);
            if (half < 10) half = 10;
            return half / (float)(shownRange > 1 ? shownRange : 1);
        }

        private string GridLabel(int v)
        {
            string t;
            if (gridLabels.TryGetValue(v, out t)) return t;
            t = v == 0 ? "0" : (v > 0 ? "+" + v.ToString() : v.ToString());
            gridLabels[v] = t;
            return t;
        }

        private void DrawGrid(Graphics sg)
        {
            if (rChartInner.Width < 4 || rChartInner.Height < 4) return;
            sg.SetClip(rChartInner);
            float cx = rChartInner.X + rChartInner.Width / 2f, cy = rChartInner.Y + rChartInner.Height / 2f;
            float ppu = Ppu();
            double step = DashScale.Steps[scale.Rung];
            float halfW = rChartInner.Width / 2f, halfH = rChartInner.Height / 2f;
            float stepPx = (float)(step * ppu);
            float smallH = fSmall.GetHeight(sg);
            if (stepPx >= 4)
            {
                // minor lines at half steps, major at steps
                float minorPx = stepPx / 2f;
                if (minorPx >= 6)
                {
                    for (float d = minorPx; d <= halfW + 1; d += stepPx)
                    { sg.DrawLine(pGridMinor, cx + d, rChartInner.Y, cx + d, rChartInner.Bottom); sg.DrawLine(pGridMinor, cx - d, rChartInner.Y, cx - d, rChartInner.Bottom); }
                    for (float d = minorPx; d <= halfH + 1; d += stepPx)
                    { sg.DrawLine(pGridMinor, rChartInner.X, cy + d, rChartInner.Right, cy + d); sg.DrawLine(pGridMinor, rChartInner.X, cy - d, rChartInner.Right, cy - d); }
                }
                // X labels: every k-th grid line so neighbouring labels keep a gap of at least 20 % of a label
                int maxN = Math.Max(1, (int)Math.Floor((halfW + 1) / stepPx));
                float widest = sg.MeasureString(GridLabel(-(int)Math.Round(maxN * step)), fSmall, PointF.Empty, sfTypo).Width;
                int stride = Math.Max(1, (int)Math.Ceiling((widest * 1.2f + S(6)) / stepPx));
                int n = 1;
                for (float d = stepPx; d <= halfW + 1; d += stepPx, n++)
                {
                    sg.DrawLine(pGrid, cx + d, rChartInner.Y, cx + d, rChartInner.Bottom);
                    sg.DrawLine(pGrid, cx - d, rChartInner.Y, cx - d, rChartInner.Bottom);
                    if (n % stride != 0) continue;
                    int v = (int)Math.Round(n * step);
                    string lp = GridLabel(v), ln = GridLabel(-v);
                    float lwp = sg.MeasureString(lp, fSmall, PointF.Empty, sfTypo).Width;
                    float lwn = sg.MeasureString(ln, fSmall, PointF.Empty, sfTypo).Width;
                    if (cx + d + S(2) + lwp <= rChartInner.Right - S(2)) sg.DrawString(lp, fSmall, bMuted, cx + d + S(2), cy + S(2));
                    if (cx - d + S(2) + lwn <= cx - S(2)) sg.DrawString(ln, fSmall, bMuted, cx - d + S(2), cy + S(2));
                }
                n = 1;
                for (float d = stepPx; d <= halfH + 1; d += stepPx, n++)
                {
                    sg.DrawLine(pGrid, rChartInner.X, cy + d, rChartInner.Right, cy + d);
                    sg.DrawLine(pGrid, rChartInner.X, cy - d, rChartInner.Right, cy - d);
                    if (stepPx >= smallH + S(4))
                    {
                        int v = (int)Math.Round(n * step);
                        sg.DrawString(GridLabel(v), fSmall, bMuted, cx + S(6), cy - d - smallH);   // up = +
                        sg.DrawString(GridLabel(-v), fSmall, bMuted, cx + S(6), cy + d - smallH);
                    }
                }
            }
            sg.DrawLine(pAxis, rChartInner.X, cy, rChartInner.Right, cy);
            sg.DrawLine(pAxis, cx, rChartInner.Y, cx, rChartInner.Bottom);

            // quadrant tags
            int m = S(8);
            Rectangle q = new Rectangle(rChartInner.X + m, rChartInner.Y + m, rChartInner.Width - 2 * m, rChartInner.Height - 2 * m);
            sg.DrawString("Ⅱ 左上", fSmall, bMuted, q, sfLeftTop);
            sg.DrawString("Ⅰ 右上", fSmall, bMuted, q, sfRightTop);
            sg.DrawString("Ⅲ 左下", fSmall, bMuted, q, sfLeftBottom);
            sg.DrawString("Ⅳ 右下", fSmall, bMuted, q, sfRightBottom);

            // origin = screen centre (the game's own centre dot): a small reticle + a tag in quadrant III with a leader
            SmoothingMode sm = sg.SmoothingMode;
            sg.SmoothingMode = SmoothingMode.AntiAlias;
            float or = 3f * s;
            sg.DrawEllipse(pOrigin, cx - or, cy - or, or * 2, or * 2);
            // the 「屏幕中心」 tag itself is drawn in the dynamic layer, so it can step aside when the ring passes over it
            SizeF ts = sg.MeasureString(CentreText, fSmall, PointF.Empty, sfTypo);
            DashRect lr = lay.CentreLabel(cx, cy, (int)Math.Ceiling(ts.Width), (int)Math.Ceiling(smallH));
            rPlate = R(lr);
            plateShown = rChartInner.Contains(rPlate);
            sg.SmoothingMode = sm;

            sg.ResetClip();
        }

        // ---------------------------------------------------------------- dynamic parts

        private void DrawHeaderDynamic(Graphics gr)
        {
            gr.DrawString(titleShown, fTitle, bAccent, rTitle, sfLeftMid);
            if (double.IsNaN(decodeStartMs) && cursorOn && titleW + S(16) < rTitle.Width)
            {   // blinking block cursor after the decoded title
                int ch = Math.Max(2, (int)(fTitle.GetHeight(gr) * 0.62f));
                gr.FillRectangle(bGreen, rTitle.X + titleW + S(5), rTitle.Y + (rTitle.Height - ch) / 2 + S(1), Math.Max(2, S(7)), ch);
            }
            if (rNote.Height > 0) gr.DrawString(note, fSmall, ReferenceEquals(note, hintText) ? bMuted : bWarn, rNote, sfLeftMid);
            else if (!ReferenceEquals(note, hintText) && rChartTitle.Width > 0)
            {   // compact header (short page): warnings go into the chart's title bar instead
                Rectangle tr = new Rectangle(rChart.X + rChart.Width / 2, rChart.Y, rChart.Width / 2 - S(10), rChartTitle.Height);
                gr.DrawString(note, fSmall, bWarn, tr, sfRightMid);
            }
            gr.DrawString(txMem.Text, fValue, bGreen, rMemVal, sfRightMid);
        }

        private void DrawStatsDynamic(Graphics gr)
        {
            if (rStatsTitle.Width > S(60))
            {
                if (foreground) { if (cursorOn) gr.DrawString(LiveTag, fSmall, bGreen, rStatsTitle, sfRightMid); }
                else gr.DrawString(PauseTag, fSmall, bMuted, rStatsTitle, sfRightMid);
            }

            for (int i = 0; i < rowsShown; i++)
            {
                int b = rowBucket[i];
                if (b < 0) b = 0; if (b > 3) b = 3;
                switch (i)
                {
                    case 0: gr.DrawString(txX.Text, fValue, valueB[b], rRows[0], sfRightMid); break;
                    case 1: gr.DrawString(txY.Text, fValue, valueB[b], rRows[1], sfRightMid); break;
                    case 2: gr.DrawString(txRise.Text, fValue, riseB[b], rRows[2], sfRightMid); break;
                    case 3: gr.DrawString(leanText, fBody, valueB[b], rRows[3], sfRightMid); break;
                    case 4: gr.DrawString(handText, fBody, engine.Hand == 1 ? riseB[b] : valueB[b], rRows[4], sfRightMid); break;
                    case 5: gr.DrawString(dirText, fBody, valueB[b], rRows[5], sfRightMid); break;
                    case 6: gr.DrawString(stateText, fBody, valueB[b], rRows[6], sfRightMid); break;
                }
            }

            if (!capsShown) return;
            SmoothingMode sm = gr.SmoothingMode;
            gr.SmoothingMode = SmoothingMode.AntiAlias;
            for (int i = 0; i < DashKeys.Count; i++)
            {
                if (capPaths[i] == null) continue;
                int b = glowBucket[i];
                if (b < 0) b = 0; if (b > 3) b = 3;
                if (b > 0 && glowPaths[i] != null) gr.FillPath(capGlowFill[b], glowPaths[i]);
                gr.FillPath(capFill[b], capPaths[i]);
                gr.DrawPath(capBorder[b], capPaths[i]);
                gr.DrawString(capLabels[i], capUseUi[i] ? fCapUi : fCap, capTextB[b], rCaps[i], sfCenter);
            }
            gr.SmoothingMode = sm;
            if (rCombo.Height > 0)
            {
                int mk = shownMask & ((1 << DashKeys.Count) - 1);
                string ct = comboTexts[mk];
                if (ct == null) { ct = "> " + DashFormat.KeyCombo(mk, logNames) + (DashKeys.Sprinting(mk) ? " 冲刺" : ""); comboTexts[mk] = ct; } // once per mask, then cached
                gr.DrawString(ct, IsAscii(ct) ? fMono : fTermUi, mk != 0 ? bGreen : bTag, rCombo, sfCenter);
            }
        }

        private void DrawTerminalDynamic(Graphics gr)
        {
            if (lineH <= 0 || rTermInner.Height < 2 || rTermInner.Width < 2) return;
            int fit = Math.Max(1, (int)(rTermInner.Height / lineH));
            int count = log.Count;
            int first = Math.Max(0, count - fit);
            float y = rTermInner.Y;
            float x = rTermInner.X;
            float maxW = rTermInner.Width;
            gr.SetClip(rTermInner);
            for (int i = first; i < count; i++)
            {
                string line = log.Line(i);
                int vis = log.Visible(i, nowMs);
                bool newest = i == count - 1;
                SolidBrush br = newest ? bGreen : (i >= count - 3 ? bGreenMid : bGreenDim);
                bool ascii = IsAscii(line);
                float typedW = ascii ? vis * charW : TypedWidthUi(line, vis);
                if (vis > 0)
                {
                    float wv = vis >= line.Length ? maxW : Math.Min(maxW, typedW + 0.5f);
                    if (ascii) gr.DrawString(line, fMono, br, new RectangleF(x, y, wv, lineH + 2f), sfTypo); // clipped = typed-out part
                    else gr.DrawString(line, fTermUi, br, new RectangleF(x, y, wv, lineH + 2f), sfTypo);
                }
                if (newest && cursorOn)
                {
                    float cxp = x + Math.Min(maxW - charW, typedW + 1f);
                    gr.FillRectangle(bGreen, cxp, y + 1f, Math.Max(2f, charW * 0.9f), lineH - 2f);
                }
                y += lineH;
            }
            if (count == 0 && cursorOn) gr.FillRectangle(bGreen, x, y + 1f, Math.Max(2f, charW * 0.9f), lineH - 2f);
            gr.ResetClip();
        }

        /// <summary>True when every char is printable ASCII (drawn in the monospace font); Chinese lines use the UI font.</summary>
        private static bool IsAscii(string t)
        {
            if (t == null) return true;
            for (int i = 0; i < t.Length; i++) if (t[i] > 0x7E) return false;
            return true;
        }

        /// <summary>Approximate width of the first n chars of a UI-font terminal line (no allocation): CJK = 1 em, Latin = 0.55 em.</summary>
        private float TypedWidthUi(string t, int n)
        {
            float w = 0;
            if (n > t.Length) n = t.Length;
            for (int i = 0; i < n; i++) w += t[i] > 0x2E7F ? uiEm : uiEm * 0.55f;
            return w;
        }

        private void DrawChartDynamic(Graphics gr)
        {
            if (rChartInner.Width < 4 || rChartInner.Height < 4) return;
            gr.SetClip(rChartInner);
            SmoothingMode sm = gr.SmoothingMode;
            gr.SmoothingMode = SmoothingMode.AntiAlias;
            float cx = rChartInner.X + rChartInner.Width / 2f, cy = rChartInner.Y + rChartInner.Height / 2f;
            float ppu = Ppu();
            float lo = rChartInner.X + 2, hi = rChartInner.Right - 2, top = rChartInner.Y + 2, bot = rChartInner.Bottom - 2;

            float px = ClampF(cx + (float)(uiX * ppu), lo, hi);
            float py = ClampF(cy - (float)(uiY * ppu), top, bot);

            // 「屏幕中心」 tag + leader, hidden while the ring (or its glow) is over it
            if (plateShown)
            {
                float rr = 12f * s + S(6);
                float nx = ClampF(px, rPlate.X, rPlate.Right), ny = ClampF(py, rPlate.Y, rPlate.Bottom);
                bool covered = (nx - px) * (nx - px) + (ny - py) * (ny - py) < rr * rr;
                if (!covered)
                {
                    gr.DrawLine(pPlate, cx - S(5), cy + S(5), rPlate.Right, rPlate.Y);
                    gr.FillRectangle(bChartBg, rPlate);
                    gr.DrawRectangle(pPlate, rPlate.X, rPlate.Y, rPlate.Width - 1, rPlate.Height - 1);
                    gr.DrawString(CentreText, fSmall, bMuted, rPlate, sfCenter);
                }
            }

            // projection lines from the ring to both axes + ticks on the axes (HUD read-out)
            if (Math.Abs(px - cx) > S(6) || Math.Abs(py - cy) > S(6))
            {
                gr.DrawLine(pProj, px, py, px, cy);
                gr.DrawLine(pProj, px, py, cx, py);
                int tk = S(4);
                gr.DrawLine(pTick, px, cy - tk, px, cy + tk);
                gr.DrawLine(pTick, cx - tk, py, cx + tk, py);
            }

            // trail: oldest -> newest, fading with age
            int n = trail.Count;
            if (n > 0)
            {
                double maxAge = trail.MaxAgeMs;
                double x0, y0, t0;
                trail.Get(0, out x0, out y0, out t0);
                float ax = ClampF(cx + (float)(x0 * ppu), lo, hi), ay = ClampF(cy - (float)(y0 * ppu), top, bot);
                for (int i = 1; i <= n; i++)
                {
                    float bx, by; double tb;
                    if (i < n)
                    {
                        double x1, y1;
                        trail.Get(i, out x1, out y1, out tb);
                        bx = ClampF(cx + (float)(x1 * ppu), lo, hi); by = ClampF(cy - (float)(y1 * ppu), top, bot);
                    }
                    else { bx = px; by = py; tb = nowMs; }
                    double life = 1.0 - (nowMs - tb) / maxAge;
                    if (life > 0)
                    {
                        int k = (int)(life * trailPens.Length);
                        if (k >= trailPens.Length) k = trailPens.Length - 1;
                        if (k < 0) k = 0;
                        gr.DrawLine(trailPens[k], ax, ay, bx, by);
                    }
                    ax = bx; ay = by;
                }
            }

            // offset vector from the screen centre
            if (Math.Abs(px - cx) > 1 || Math.Abs(py - cy) > 1) gr.DrawLine(pVector, cx, cy, px, py);

            // the ring (two-tone like the overlay; the centre stays empty)
            float r = 8f * s;
            gr.DrawEllipse(pRingGlow, px - r, py - r, r * 2, r * 2);
            gr.DrawEllipse(pRingOuter, px - r, py - r, r * 2, r * 2);
            gr.DrawEllipse(pRingInner, px - r, py - r, r * 2, r * 2);

            gr.SmoothingMode = sm;
            gr.ResetClip();
        }

        private static float ClampF(float v, float lo, float hi)
        {
            if (float.IsNaN(v)) return lo;
            return v < lo ? lo : (v > hi ? hi : v);
        }

        // ================================================================== resources

        private static Font MakeFont(string[] families, float pt, FontStyle style)
        {
            for (int i = 0; i < families.Length; i++)
            {
                try
                {
                    Font f = new Font(families[i], pt, style, GraphicsUnit.Point);
                    if (string.Equals(f.Name, families[i], StringComparison.OrdinalIgnoreCase)) return f;
                    f.Dispose();
                }
                catch { }
            }
            return new Font(FontFamily.GenericSansSerif, pt, style, GraphicsUnit.Point);
        }

        private static Color A(Color c, int alpha) { return Color.FromArgb(alpha, c.R, c.G, c.B); }

        private static readonly string[] UiFamilies = new string[] { "Microsoft YaHei UI", "Microsoft YaHei", "SimHei", "Segoe UI" };
        private static readonly string[] MonoFamilies = new string[] { "Consolas", "Cascadia Mono", "Lucida Console", "Courier New" };

        /// <summary>Fonts in points (so they follow the Windows DPI) times the layout zoom; rebuilt only when the zoom step changes.</summary>
        private void CreateFonts(float z)
        {
            DisposeFonts();
            // SPEC (Leo, 16 Nov): at 100 % body >= 11 pt, labels >= 10.5 pt, page title >= 16 pt, numbers >= 11 pt,
            // terminal >= 10.5 pt. z = UiScale.For (1.0 .. 1.8) never shrinks them.
            fTitle = MakeFont(UiFamilies, UiScale.Pt(16f, z, 16f), FontStyle.Bold);
            fBody = MakeFont(UiFamilies, UiScale.Pt(11f, z, 11f), FontStyle.Regular);
            fSmall = MakeFont(UiFamilies, UiScale.Pt(10.5f, z, 10.5f), FontStyle.Regular);
            fCapUi = MakeFont(UiFamilies, UiScale.Pt(10.5f, z, 10.5f), FontStyle.Bold);
            fMono = MakeFont(MonoFamilies, UiScale.Pt(10.5f, z, 10.5f), FontStyle.Regular);
            fMonoSmall = MakeFont(MonoFamilies, UiScale.Pt(10.5f, z, 10.5f), FontStyle.Regular);
            fTermUi = MakeFont(UiFamilies, UiScale.Pt(10.5f, z, 10.5f), FontStyle.Regular);   // terminal lines with Chinese text
            fTag = MakeFont(MonoFamilies, UiScale.Pt(10.5f, z, 10.5f), FontStyle.Regular);
            fValue = MakeFont(MonoFamilies, UiScale.Pt(12f, z, 11f), FontStyle.Bold);
            fCap = MakeFont(MonoFamilies, UiScale.Pt(11f, z, 11f), FontStyle.Bold);
        }

        private void CreateResources()
        {
            CreateFonts(1f);
            fontZoom = -1;   // DoLayout picks the real zoom

            bBack = new SolidBrush(Theme.ColBackground);
            bSurface = new SolidBrush(Theme.ColSurface);
            bChartBg = new SolidBrush(ColChartBg);
            bText = new SolidBrush(Theme.ColText);
            bMuted = new SolidBrush(Theme.ColMuted);
            bAccent = new SolidBrush(Theme.ColAccent);
            bGreen = new SolidBrush(ColGreen);
            bGreenDim = new SolidBrush(ColGreenDim);
            bGreenMid = new SolidBrush(ColGreenMid);
            bTag = new SolidBrush(ColTag);
            bTermBg = new SolidBrush(ColTermBg);
            bWarn = new SolidBrush(Theme.Blend(Theme.ColAccent, Color.FromArgb(0xFF, 0x80, 0x40), 0.5));

            pBorder = new Pen(Theme.ColBorder);
            pGrid = new Pen(A(Theme.ColBorder, 200));
            pGridMinor = new Pen(A(Theme.ColBorder, 90));
            pAxis = new Pen(A(Theme.ColAccent, 150));
            pHeaderLine = new Pen(A(Theme.ColAccent, 120));
            pTermBorder = new Pen(Theme.Blend(ColTermBg, ColGreen, 0.30));
            pOrigin = new Pen(Theme.ColMuted);
            pPlate = new Pen(A(Theme.ColMuted, 110));

            for (int b = 0; b < 4; b++)
            {
                double t = b / 3.0;
                capFill[b] = new SolidBrush(Theme.Blend(Theme.ColInput, Color.FromArgb(0x0E, 0x3B, 0x12), t));
                capGlowFill[b] = new SolidBrush(A(ColGreen, (int)(70 * t)));
                capTextB[b] = new SolidBrush(Theme.Blend(Theme.ColMuted, ColBright, t));
                capBorder[b] = new Pen(Theme.Blend(Theme.ColBorder, ColGreen, t));
                valueB[b] = new SolidBrush(Theme.Blend(Theme.ColText, ColBright, t * 0.9));
                riseB[b] = new SolidBrush(Theme.Blend(Theme.ColAccent, ColBright, t * 0.9));
            }

            sfTypo = (StringFormat)StringFormat.GenericTypographic.Clone();
            sfTypo.FormatFlags = StringFormatFlags.NoWrap | StringFormatFlags.MeasureTrailingSpaces; // no NoClip: the layout box clips
            sfTypo.Trimming = StringTrimming.None;
            sfCenter = MakeSf(StringAlignment.Center, StringAlignment.Center);
            sfRight = MakeSf(StringAlignment.Far, StringAlignment.Near);
            sfLeftMid = MakeSf(StringAlignment.Near, StringAlignment.Center);
            sfRightMid = MakeSf(StringAlignment.Far, StringAlignment.Center);
            sfLeftTop = MakeSf(StringAlignment.Near, StringAlignment.Near);
            sfRightTop = MakeSf(StringAlignment.Far, StringAlignment.Near);
            sfLeftBottom = MakeSf(StringAlignment.Near, StringAlignment.Far);
            sfRightBottom = MakeSf(StringAlignment.Far, StringAlignment.Far);

            // scanlines: 1 dark line every 3 px over the terminal (cached texture)
            scanBmp = new Bitmap(1, 3, PixelFormat.Format32bppArgb);
            scanBmp.SetPixel(0, 0, Color.FromArgb(0, 0, 0, 0));
            scanBmp.SetPixel(0, 1, Color.FromArgb(0, 0, 0, 0));
            scanBmp.SetPixel(0, 2, Color.FromArgb(70, 0, 0, 0));
            scanBrush = new TextureBrush(scanBmp, WrapMode.Tile);

            ScaledPens();
        }

        private static StringFormat MakeSf(StringAlignment h, StringAlignment v)
        {
            StringFormat f = new StringFormat(StringFormatFlags.NoWrap);
            f.Alignment = h;
            f.LineAlignment = v;
            f.Trimming = StringTrimming.EllipsisCharacter;
            return f;
        }

        /// <summary>Pens whose width depends on the DPI scale / zoom (rebuilt on layout).</summary>
        private void ScaledPens()
        {
            DisposePen(ref pVector); DisposePen(ref pRingGlow); DisposePen(ref pRingOuter); DisposePen(ref pRingInner);
            DisposePen(ref pBracket); DisposePen(ref pProj); DisposePen(ref pTick);
            pVector = new Pen(A(Theme.ColAccent, 150), Math.Max(1f, 1.2f * s));
            pVector.DashStyle = DashStyle.Dash;
            pRingGlow = new Pen(A(ColGreen, 45), 8f * s);
            pRingOuter = new Pen(Color.Black, 4.5f * s);
            pRingInner = new Pen(ColGreen, 2.2f * s);
            pBracket = new Pen(A(Theme.ColAccent, 210), Math.Max(1f, 1.5f * s));
            pProj = new Pen(A(ColGreen, 70), Math.Max(1f, s));
            pProj.DashStyle = DashStyle.Dot;
            pTick = new Pen(A(ColGreen, 200), Math.Max(1f, 1.5f * s));
            for (int i = 0; i < trailPens.Length; i++)
            {
                if (trailPens[i] != null) trailPens[i].Dispose();
                double life = (i + 1) / (double)trailPens.Length;
                int alpha = (int)Math.Round(230 * life * life);
                Pen p = new Pen(A(ColGreen, Math.Max(12, alpha)), Math.Max(1f, (1f + 1.6f * (float)life) * s));
                p.StartCap = LineCap.Round;
                p.EndCap = LineCap.Round;
                trailPens[i] = p;
            }
        }

        private static void DisposePen(ref Pen p) { if (p != null) { p.Dispose(); p = null; } }
        private static void DisposeBrush(ref SolidBrush b) { if (b != null) { b.Dispose(); b = null; } }
        private static void DisposeFont(ref Font f) { if (f != null) { f.Dispose(); f = null; } }
        private static void DisposeSf(ref StringFormat f) { if (f != null) { f.Dispose(); f = null; } }

        private void DisposeFonts()
        {
            DisposeFont(ref fTitle); DisposeFont(ref fBody); DisposeFont(ref fSmall); DisposeFont(ref fMono);
            DisposeFont(ref fMonoSmall); DisposeFont(ref fValue); DisposeFont(ref fCap); DisposeFont(ref fCapUi); DisposeFont(ref fTag); DisposeFont(ref fTermUi);
        }

        private void DisposeResources()
        {
            DisposeFonts();
            DisposeBrush(ref bBack); DisposeBrush(ref bSurface); DisposeBrush(ref bChartBg); DisposeBrush(ref bText);
            DisposeBrush(ref bMuted); DisposeBrush(ref bAccent); DisposeBrush(ref bGreen); DisposeBrush(ref bGreenDim);
            DisposeBrush(ref bGreenMid); DisposeBrush(ref bTermBg); DisposeBrush(ref bWarn); DisposeBrush(ref bTag);
            DisposePen(ref pBorder); DisposePen(ref pGrid); DisposePen(ref pGridMinor); DisposePen(ref pAxis);
            DisposePen(ref pVector); DisposePen(ref pRingGlow); DisposePen(ref pRingOuter); DisposePen(ref pRingInner);
            DisposePen(ref pOrigin); DisposePen(ref pTermBorder); DisposePen(ref pHeaderLine);
            DisposePen(ref pBracket); DisposePen(ref pProj); DisposePen(ref pTick); DisposePen(ref pPlate);
            for (int i = 0; i < trailPens.Length; i++) DisposePen(ref trailPens[i]);
            for (int b = 0; b < 4; b++)
            {
                DisposeBrush(ref capFill[b]); DisposeBrush(ref capGlowFill[b]); DisposeBrush(ref capTextB[b]); DisposePen(ref capBorder[b]);
                DisposeBrush(ref valueB[b]); DisposeBrush(ref riseB[b]);
            }
            if (scanBrush != null) { scanBrush.Dispose(); scanBrush = null; }
            if (scanBmp != null) { scanBmp.Dispose(); scanBmp = null; }
            DisposeSf(ref sfTypo); DisposeSf(ref sfCenter); DisposeSf(ref sfRight); DisposeSf(ref sfLeftMid); DisposeSf(ref sfRightMid);
            DisposeSf(ref sfLeftTop); DisposeSf(ref sfRightTop); DisposeSf(ref sfLeftBottom); DisposeSf(ref sfRightBottom);
        }
    }
}
