﻿准星样式 Crosshairs

这里放你自己上传的准星图片（PNG）。在设置的「外观 / 准星样式」页点「上传图片」，程序会把图片复制到这里。
图片中心会自动留空，保证能看到游戏中间的小点。

Your own crosshair pictures (PNG) are stored here. Use Settings > 外观 / 准星样式 > upload.
The centre of every picture is kept empty so the game's centre dot stays visible.
